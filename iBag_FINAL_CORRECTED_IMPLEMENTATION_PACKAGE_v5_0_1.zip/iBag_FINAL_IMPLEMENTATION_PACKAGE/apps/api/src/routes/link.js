const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('../auth/auth');
const plaid = require('../providers/plaid/adapter');
router.use(authMiddleware);

// Products/optional_products per Section 0.1's closed decision.
router.post('/link/token/create', async (req, res) => {
  const data = await plaid.createLinkToken(req.userId);
  res.json({ status: 'ok', linkToken: data.link_token });
});

router.post('/link/token/exchange', async (req, res) => {
  const { publicToken } = req.body;
  if (!publicToken) return res.status(400).json({ status: 'error', code: 'MISSING_PUBLIC_TOKEN' });

  const connected = await plaid.connectItem(publicToken);

  await db.withUserContext(req.userId, async (client) => {
    const itemInsert = await client.query(
      `INSERT INTO plaid_items (user_id, plaid_item_id, plaid_access_token_encrypted, institution_id, institution_name, status)
       VALUES ($1,$2,$3,$4,$5,'active') RETURNING id`,
      [req.userId, connected.itemId, connected.accessTokenEncrypted, connected.institutionId, connected.institutionName]
    );
    const plaidItemRowId = itemInsert.rows[0].id;

    const accounts = await plaid.syncAccounts(connected.accessTokenEncrypted);
    for (const a of accounts) {
      await client.query(
        `INSERT INTO accounts
           (user_id, plaid_item_id, plaid_account_id, name, official_name, mask, type, subtype,
            current_balance_cents, available_balance_cents, balance_as_of, iso_currency_code)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now(),$11)
         ON CONFLICT (plaid_account_id) DO UPDATE SET
           current_balance_cents = $9, available_balance_cents = $10, balance_as_of = now(), updated_at = now()`,
        [req.userId, plaidItemRowId, a.plaidAccountId, a.name, a.officialName, a.mask, a.type,
         a.subtype, a.currentBalanceCents, a.availableBalanceCents, a.isoCurrencyCode]
      );
    }

    for (const domain of ['transactions', 'liabilities', 'investments', 'identity']) {
      await client.query(
        `INSERT INTO provider_capabilities (plaid_item_id, domain, requested, consented)
         VALUES ($1, $2, true, true)
         ON CONFLICT (plaid_item_id, domain) DO UPDATE SET consented = true`,
        [plaidItemRowId, domain]
      );
    }
  });

  res.json({ status: 'ok', itemId: connected.itemId });
});

module.exports = router;
