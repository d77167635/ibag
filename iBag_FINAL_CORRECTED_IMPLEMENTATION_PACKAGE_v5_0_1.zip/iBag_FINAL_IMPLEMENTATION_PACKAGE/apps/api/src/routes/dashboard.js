const express = require('express');
const db = require('../db');
const { authMiddleware } = require('./auth');
const router = express.Router();

router.get('/me/dashboard', async (req, res, next) => {
  try {
    const result = await db.withUserContext(req.userId, async (client) => {
      const [
        accounts,
        roundup,
        recentRoundups,
        income,
        recurring,
        cashFlow,
        netWorth,
        health,
        capabilities,
        quality
      ] = await Promise.all([
        client.query(`
          SELECT id, name, official_name, mask, type, subtype,
                 current_balance_cents, available_balance_cents,
                 iso_currency_code, balance_as_of, status
          FROM accounts
          WHERE user_id = $1
          ORDER BY created_at
        `, [req.userId]),

        client.query(`
          SELECT
            COUNT(*)::int AS event_count,
            COUNT(*) FILTER (
              WHERE eligibility_status = 'eligible' AND roundup_cents > 0
            )::int AS opportunity_count,
            COALESCE(SUM(roundup_cents) FILTER (
              WHERE eligibility_status = 'eligible'
            ), 0)::bigint AS opportunity_cents
          FROM roundup_events
          WHERE user_id = $1
        `, [req.userId]),

        client.query(`
          SELECT re.id, re.transaction_id, re.source_amount_cents,
                 re.roundup_cents, re.eligibility_status,
                 re.eligibility_reason, t.merchant_name,
                 t.posted_date, t.account_id
          FROM roundup_events re
          JOIN transactions t ON t.id = re.transaction_id
          WHERE re.user_id = $1
          ORDER BY re.created_at DESC
          LIMIT 25
        `, [req.userId]),

        client.query(`
          SELECT * FROM income_signals
          WHERE user_id = $1
          ORDER BY average_amount_cents DESC NULLS LAST
        `, [req.userId]),

        client.query(`
          SELECT * FROM recurring_streams
          WHERE user_id = $1
          ORDER BY next_expected_date NULLS LAST
        `, [req.userId]),

        client.query(`
          SELECT * FROM cash_flow_periods
          WHERE user_id = $1
          ORDER BY period_end DESC
          LIMIT 12
        `, [req.userId]),

        client.query(`
          SELECT * FROM net_worth_snapshots
          WHERE user_id = $1
          ORDER BY as_of_date DESC
          LIMIT 1
        `, [req.userId]),

        client.query(`
          SELECT * FROM financial_health_signals
          WHERE user_id = $1
          ORDER BY signal_type
        `, [req.userId]),

        client.query(`
          SELECT pc.domain, pc.requested, pc.consented,
                 pc.product_enabled, pc.observed,
                 pc.last_successful_sync_at,
                 pc.last_failed_sync_at, pc.last_error
          FROM provider_capabilities pc
          JOIN plaid_items pi ON pi.id = pc.plaid_item_id
          WHERE pi.user_id = $1
          ORDER BY pc.domain
        `, [req.userId]),

        client.query(`
          SELECT issue_type, entity_type, entity_id, details, created_at
          FROM data_quality_events
          WHERE user_id = $1 AND resolved_at IS NULL
          ORDER BY created_at DESC
          LIMIT 50
        `, [req.userId]),
      ]);

      const posted = await client.query(`
        SELECT MIN(COALESCE(posted_date, authorized_date)) AS start_date,
               MAX(COALESCE(posted_date, authorized_date)) AS end_date,
               COUNT(*)::int AS transaction_count
        FROM transactions
        WHERE user_id = $1 AND removed_at IS NULL
      `, [req.userId]);

      return {
        accounts: accounts.rows,
        roundUps: {
          eventCount: Number(roundup.rows[0].event_count),
          opportunityCount: Number(roundup.rows[0].opportunity_count),
          opportunityCents: Number(roundup.rows[0].opportunity_cents),
        },
        recentRoundups: recentRoundups.rows,
        income: income.rows,
        recurring: recurring.rows,
        cashFlow: cashFlow.rows,
        netWorth: netWorth.rows[0] || null,
        financialHealth: health.rows,
        capabilities: capabilities.rows,
        dataQuality: quality.rows,
        observationWindow: posted.rows[0],
      };
    });

    res.json({ status: 'ok', dashboard: result });
  } catch (err) {
    next(err);
  }
});


module.exports = router;
