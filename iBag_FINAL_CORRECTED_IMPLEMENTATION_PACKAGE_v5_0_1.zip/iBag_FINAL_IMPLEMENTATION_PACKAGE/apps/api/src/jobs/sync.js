const db = require('../db');
const plaid = require('../providers/plaid/adapter');
const { classify } = require('../classification/classify');
const { evaluateRoundup, applyRoundupEvent, applyRoundupCorrection } = require('../roundup/rules');
const { detectTransferPair } = require('../intelligence/transfer-detection'); // Section 9.6

async function runSync({ itemId, trigger }) {
  const itemResult = await db.withServiceRole((client) => client.query(
    'SELECT id, user_id, plaid_access_token_encrypted, cursor FROM plaid_items WHERE plaid_item_id = $1',
    [itemId]
  ));
  if (itemResult.rows.length === 0) {
    throw new Error(`SYNC_UNKNOWN_ITEM: no plaid_items row for item_id ${itemId}`);
  }
  const item = itemResult.rows[0];

  const runInsert = await db.withUserContext(item.user_id, (client) => client.query(
    `INSERT INTO sync_runs (user_id, plaid_item_id, trigger, status)
     VALUES ($1, $2, $3, 'running') RETURNING id`,
    [item.user_id, item.id, trigger]
  ));
  const syncRunId = runInsert.rows[0].id;

  try {
    const { added, modified, removed, nextCursor } =
      await plaid.syncTransactions(item.plaid_access_token_encrypted, item.cursor);

    const pendingDataQualityFlags = [];

    await db.withUserContext(item.user_id, async (client) => {
      // Added + modified share an upsert path â€” Plaid's `modified` entries
      // carry the full current transaction object, same shape as `added`.
      for (const tx of [...added, ...modified]) {
        const amountCents = Math.round(tx.amount * 100); // Plaid: positive = debit, matches Section 5.5 convention

        // v4.3 fix (gap 1): the account row is now looked up BEFORE the
        // transaction upsert, specifically so its `type` is available to
        // pass into classify() below. Previously account_type was hardcoded
        // to null, which silently made classify.js rules 4-6 (LOAN_PAYMENT,
        // CREDIT_CARD_PAYMENT, INVESTMENT_ACTIVITY) dead code â€” they all
        // branch on account_type and it was never supplied.
        const accountLookup = await client.query(
          `SELECT id, type FROM accounts WHERE plaid_account_id = $1 AND user_id = $2`,
          [tx.account_id, item.user_id]
        );
        if (accountLookup.rows.length === 0) continue; // account not yet synced this pass â€” picked up on next sync
        const account = accountLookup.rows[0];

        // v4.3: `(xmax = 0) AS was_inserted` is the standard Postgres idiom
        // for distinguishing an actual INSERT from an ON CONFLICT DO UPDATE
        // in a single round-trip. This replaces relying on which of Plaid's
        // `added`/`modified` arrays a transaction came from â€” Plaid's own
        // partitioning is a reasonable signal but the database's own view of
        // whether this plaid_transaction_id already existed is the ground
        // truth this pipeline actually needs for the Round-Up correction
        // decision below, and is correct even if a transaction Plaid calls
        // "added" happens to already exist locally (e.g. a re-delivered
        // webhook after a partial prior failure).
        const inserted = await client.query(
          `INSERT INTO transactions
             (user_id, account_id, plaid_transaction_id, amount_cents, iso_currency_code,
              merchant_name, provider_category, pending, pending_transaction_id,
              authorized_date, posted_date, raw)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
           ON CONFLICT (plaid_transaction_id) DO UPDATE SET
             amount_cents = $4, merchant_name = $6, provider_category = $7,
             pending = $8, pending_transaction_id = $9, posted_date = $11,
             raw = $12, updated_at = now()
           RETURNING id, amount_cents, pending, account_id, (xmax = 0) AS was_inserted`,
          [item.user_id, account.id, tx.transaction_id, amountCents, tx.iso_currency_code || null,
           tx.merchant_name, tx.personal_finance_category?.primary || tx.category?.[0] || null,
           tx.pending, tx.pending_transaction_id, tx.authorized_date, tx.date, JSON.stringify(tx)]
        );
        const row = inserted.rows[0];

        // Two-pass classification per Section 8.6: pass 1 here (incomePhase:
        // 'initial'). Income-signal resolution (pass 2) runs as a separate
        // scheduled step (jobs/incomeReview.js, Section 8.14) against
        // PENDING_INCOME_REVIEW rows, not inline in the webhook-latency path.
        const priorPurchaseMatch = false; // resolved by a dedicated refund-matching pass, out of scope for this loop
        const transferMatch = await detectTransferPair(client, item.user_id, {
          id: row.id, amount_cents: row.amount_cents, posted_date: tx.date,
        });
        const classification = classify(
          { amount_cents: row.amount_cents, provider_category: tx.personal_finance_category?.primary,
            merchant_name: tx.merchant_name, account_type: account.type },
          { priorPurchaseMatch, transferMatch: !!transferMatch, transferConfidence: 0.75,
            // isPaymentNotPurchase is still not computed from real data â€” see
            // Section 13.3's "still genuinely unresolved" list. Rule 5
            // (CREDIT_CARD_PAYMENT) therefore still cannot fire even though
            // account_type is now correctly supplied.
            isPaymentNotPurchase: false, incomeSignalMatch: false, incomeConfidence: 0,
            incomePhase: 'initial' }
        );
        await client.query(
          `INSERT INTO transaction_classifications (transaction_id, classification, classification_version, confidence, evidence)
           VALUES ($1,$2,$3,$4,$5)
           ON CONFLICT (transaction_id, classification_version) DO UPDATE
             SET classification = $2, confidence = $4, evidence = $5`,
          [row.id, classification.classification, classification.classification_version,
           classification.confidence, classification.evidence]
        );

        const roundupEval = evaluateRoundup(
          { amount_cents: row.amount_cents, pending: row.pending }, classification.classification
        );

        if (row.was_inserted) {
          await applyRoundupEvent(client, item.user_id, row.account_id, row.id, roundupEval);
        } else {
          // v4.3 fix (gap 3): row.was_inserted === false means this
          // plaid_transaction_id already had a roundup_events row from a
          // prior sync. applyRoundupEvent's ON CONFLICT DO NOTHING would
          // silently no-op here, leaving a stale roundup_cents even though
          // the transaction's real amount (and therefore the correct
          // roundup) may have changed â€” this was the "modified transactions
          // don't trigger corrections" gap. Route through the correction
          // path instead.
          const priorEvent = await client.query(
            `SELECT id, roundup_cents, eligibility_status FROM roundup_events
             WHERE transaction_id = $1 AND rule_version = $2`,
            [row.id, roundupEval.rule_version]
          );
          if (priorEvent.rows.length === 0) {
            // No prior roundup_events row exists for this transaction yet
            // (e.g. synced once before Round-Up rules existed, or a prior
            // sync's write failed) â€” treat as a first-time evaluation.
            await applyRoundupEvent(client, item.user_id, row.account_id, row.id, roundupEval);
          } else {
            const prior = priorEvent.rows[0];
            if (prior.roundup_cents !== roundupEval.roundup_cents ||
                prior.eligibility_status !== roundupEval.eligibility_status) {
              const { dataQualityFlag } = await applyRoundupCorrection(
                client, item.user_id, prior.id, row.account_id,
                prior.source_amount_cents, roundupEval.source_amount_cents,
                prior.roundup_cents, roundupEval.roundup_cents,
                roundupEval.eligibility_status, roundupEval.eligibility_reason,
                'transaction_modified'
              );
              if (dataQualityFlag) pendingDataQualityFlags.push(dataQualityFlag);
            }
            // else: the modified transaction's change didn't affect the
            // Round-Up outcome (e.g. merchant name changed, amount didn't) â€”
            // nothing to correct.
          }
        }
      }

      // Removed: Plaid sends transaction_id references for deletions.
      for (const rem of removed) {
        await client.query(
          `UPDATE transactions SET removed_at = now(), removal_reason = 'plaid_removed'
           WHERE plaid_transaction_id = $1 AND user_id = $2`,
          [rem.transaction_id, item.user_id]
        );
      }

      await client.query(
        `UPDATE plaid_items SET cursor = $1, last_synced_at = now(), updated_at = now() WHERE id = $2`,
        [nextCursor, item.id]
      );
    });

    await db.withUserContext(item.user_id, (client) => client.query(
      `UPDATE sync_runs SET status='completed', added_count=$1, modified_count=$2,
         removed_count=$3, finished_at=now() WHERE id=$4`,
      [added.length, modified.length, removed.length, syncRunId]
    ));

    // v4.3: any dataQualityFlag returned by applyRoundupCorrection above must
    // be written under withServiceRole(), not the withUserContext connection
    // it was produced on â€” data_quality_events is service-role-gated
    // (Section 5.10/13.1.15). Writing it inside the withUserContext
    // transaction would silently fail the same way the webhook pipeline did
    // before that fix.
    for (const flag of pendingDataQualityFlags) {
      await db.withServiceRole((sysClient) => sysClient.query(
        `INSERT INTO data_quality_events (user_id, issue_type, entity_type, entity_id, details)
         VALUES ($1, $2, $3, $4, $5)`,
        [item.user_id, flag.issueType, flag.entityType, flag.entityId, JSON.stringify(flag.details)]
      ));
    }

    return { added: added.length, modified: modified.length, removed: removed.length };
  } catch (err) {
    await db.withUserContext(item.user_id, (client) => client.query(
      `UPDATE sync_runs SET status='failed', error_message=$1, finished_at=now() WHERE id=$2`,
      [String(err.message || err), syncRunId]
    ));
    throw err;
  }
}

module.exports = { runSync };
