const db = require('../db');
const { classify } = require('../classification/classify');
const { detectIncomeSignals } = require('../intelligence/income');

async function resolveIncomeMatch(client, userId, merchantName) {
  const { rows } = await client.query(
    `SELECT confidence FROM income_signals
     WHERE user_id = $1
       AND (source_merchant = $2 OR ($2::text IS NULL AND source_merchant IS NULL))
       AND cadence != 'irregular'`,
    [userId, merchantName]
  );
  if (rows.length === 0) return { matched: false, confidence: 0 };
  return { matched: true, confidence: Number(rows[0].confidence) };
}

async function runIncomeReview(userId) {
  return db.withUserContext(userId, async (client) => {
    // Recompute income_signals against current posted history first, so this
    // pass's lookups reflect anything synced since the last review.
    await detectIncomeSignals(client, userId);

    const { rows: pending } = await client.query(
      `SELECT t.id, t.amount_cents, t.merchant_name, t.provider_category, t.account_id, a.type AS account_type
       FROM transactions t
       JOIN transaction_classifications tc ON tc.transaction_id = t.id
         AND tc.classification_version = 'classification_v1'
       JOIN accounts a ON a.id = t.account_id
       WHERE t.user_id = $1 AND tc.classification = 'PENDING_INCOME_REVIEW' AND t.removed_at IS NULL`,
      [userId]
    );

    let resolvedToIncome = 0, resolvedToUnknown = 0;
    for (const tx of pending) {
      const signalMatch = await resolveIncomeMatch(client, userId, tx.merchant_name);
      const classification = classify(
        { amount_cents: tx.amount_cents, provider_category: tx.provider_category,
          merchant_name: tx.merchant_name, account_type: tx.account_type },
        { priorPurchaseMatch: false, transferMatch: false, transferConfidence: 0,
          isPaymentNotPurchase: false, incomeSignalMatch: signalMatch.matched,
          incomeConfidence: signalMatch.confidence, incomePhase: 'resolved' }
      );
      await client.query(
        `UPDATE transaction_classifications SET classification = $2, confidence = $3, evidence = $4
         WHERE transaction_id = $1 AND classification_version = $5`,
        [tx.id, classification.classification, classification.confidence,
         classification.evidence, classification.classification_version]
      );
      if (classification.classification === 'INCOME') resolvedToIncome++;
      else resolvedToUnknown++;
      // Not re-evaluating Round-Up here deliberately: both PENDING_INCOME_REVIEW
      // and its two possible resolutions (INCOME, UNKNOWN) are in
      // INELIGIBLE_CLASSIFICATIONS (8.7), and the underlying amount_cents is
      // negative in every case, which evaluateRoundup already excludes on its
      // own (`amount_cents <= 0`). There is no Round-Up eligibility change this
      // resolution step could produce.
    }
    return { reviewed: pending.length, resolvedToIncome, resolvedToUnknown };
  });
}

// Convenience wrapper for a scheduled job running across all users with at
// least one PENDING_INCOME_REVIEW row, rather than requiring the caller to
// enumerate users itself.
async function runIncomeReviewForAllPendingUsers() {
  const { rows: userIds } = await db.query(
    `SELECT DISTINCT t.user_id FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE tc.classification = 'PENDING_INCOME_REVIEW' AND t.removed_at IS NULL`
  );
  const results = [];
  for (const { user_id } of userIds) {
    results.push({ userId: user_id, ...(await runIncomeReview(user_id)) });
  }
  return results;
}

module.exports = { runIncomeReview, runIncomeReviewForAllPendingUsers, resolveIncomeMatch };
