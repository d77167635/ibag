const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');

const BCRYPT_COST = 12;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) { console.error('FATAL: JWT_SECRET is not defined.'); process.exit(1); }

// Precomputed dummy hash so login timing doesn't leak whether an email exists.
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing-safety', BCRYPT_COST);

async function signup(email, password) {
  const existing = await db.query('SELECT id FROM users WHERE email = $1', [email]);
  if (existing.rows.length > 0) {
    const err = new Error('EMAIL_ALREADY_REGISTERED');
    err.code = 'EMAIL_ALREADY_REGISTERED';
    throw err;
  }
  const passwordHash = await bcrypt.hash(password, BCRYPT_COST);
  const result = await db.query(
    'INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id, email',
    [email, passwordHash]
  );
  const user = result.rows[0];
  const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
  return { user, token };
}

async function login(email, password) {
  const result = await db.query('SELECT id, password_hash FROM users WHERE email = $1', [email]);
  const user = result.rows[0];
  // Always run a bcrypt.compare, even when the user doesn't exist, so response
  // timing doesn't distinguish "no such email" from "wrong password."
  const hashToCompare = user ? user.password_hash : DUMMY_HASH;
  const valid = await bcrypt.compare(password, hashToCompare);
  if (!user || !valid) {
    const err = new Error('INVALID_CREDENTIALS');
    err.code = 'INVALID_CREDENTIALS';
    throw err;
  }
  const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
  return { user: { id: user.id, email }, token };
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ status: 'error', code: 'MISSING_TOKEN', message: 'Authorization required.' });
  }
  try {
    const payload = jwt.verify(header.slice(7), JWT_SECRET, { algorithms: ['HS256'], issuer: 'ibag-api', audience: 'ibag-client' });
    req.userId = payload.sub;
    next();
  } catch (err) {
    return res.status(401).json({ status: 'error', code: 'INVALID_TOKEN', message: 'Invalid or expired token.' });
  }
}

module.exports = { signup, login, authMiddleware };
