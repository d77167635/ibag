# iBag Implementation Package — Closure Pass v5.0.3

This package is v5.0.2 after a further audit specifically targeting
**GitHub → Render → Supabase → Plaid Sandbox** wiring — i.e. "why would the
dashboard stay empty even after everything else was fixed." It is still
**SPECIFIED + IMPLEMENTED**, not **STAGING_VALIDATED** — nothing in this pass
was run against a real Render deployment, a real Supabase project, or real
Plaid Sandbox traffic, for the same reason as before: this environment has no
network access to any of those three services and no credentials for your
accounts. Everything below is a static-analysis + current-documentation
audit, verified by actually requiring/wiring the code, not a live test.

## v5.0.3 — deployment-path findings

1. **The mandatory first `/transactions/sync` call was never made.** Per
   Plaid's current Transactions Sync docs (confirmed via search during this
   pass, not assumed from training data): `SYNC_UPDATES_AVAILABLE` is never
   sent for an Item until `/transactions/sync` has been called at least once
   on it. `link.js` created Items and fetched account balances, but never
   called `runSync`. Result: in Sandbox, no webhook would ever fire for a
   newly linked Item, `webhookWorker.js` would have nothing to process, and
   the dashboard would stay empty indefinitely — regardless of how correctly
   everything downstream was wired. This was the actual root cause behind
   "why isn't real Plaid data showing up," more than any of the v5.0.2 fixes.
   **Fixed**: `link.js` now calls `runSync` once immediately after item
   creation; a failure here is logged, not fatal, since it's normal for this
   first call to return zero transactions and the item is already valid.
2. **No SSL config on either `pg.Pool`.** Supabase requires SSL; node-postgres
   does not enable it by default. Unconfigured, this fails to connect from
   Render to Supabase at all. **Fixed** in `db.js`, with an explicit note not
   to also put `sslmode=` in the connection string (confirmed current
   node-postgres behavior: doing both causes the `ssl` object to be silently
   ignored), and a note on tightening to `verify-full` with Supabase's CA
   cert before production (not fabricated here — it's per-project).
3. **No guidance against Supabase's direct-connection host.** Confirmed
   current Supabase behavior: the direct-connection host is IPv6-only unless
   the paid IPv4 add-on is purchased; Render's outbound networking is IPv4.
   Using the direct-connection string from Render would simply fail to
   connect. **Documented** in `.env.example`: use the Session/Shared Pooler
   string, with the `postgres.<project-ref>` username format it requires.
4. **No `redirect_uri` support for Plaid Link's OAuth flow.** Several Plaid
   Sandbox test institutions (and most real institutions) require it.
   **Fixed**: `createLinkToken` now includes it when
   `PLAID_OAUTH_REDIRECT_URI` is set — but this package still ships no
   frontend to receive that redirect, so OAuth institutions remain untestable
   until a frontend exists. Documented, not silently dropped.
5. **No `.gitignore`.** Pushing this to GitHub as-is risks committing a real
   `.env` with live secrets. **Fixed**: added, excluding `node_modules/` and
   `.env`.

### Checked and confirmed NOT a bug (ruled out during this pass, not assumed)

- **Webhook raw-body ordering in `index.js`**: `/plaid/webhook`'s
  `express.raw()` + router are registered before the global `express.json()`,
  and the webhook route sends a response without calling `next()` — so the
  global JSON parser never runs for that path. Verified by reading Express's
  middleware dispatch order, not assumed safe.
- **Webhook verification logic itself** (`plaidWebhookVerify.js`): checked
  header name, ES256 algorithm pinning, JWK fetch endpoint, `iat` freshness
  window, and `request_body_sha256` comparison against Plaid's current
  webhook-verification docs (confirmed via search this pass) — all correct
  as shipped.
- **Render's Node version pin** (`>=24.0.0 <25`): confirmed current — Render's
  own default Node version for new services is 24.x as of this pass.
- **`syncAccounts`/`syncTransactions`/etc. decrypt-before-calling-Plaid**:
  each correctly decrypts the stored token before using it against the Plaid
  API; nowhere sends the encrypted-at-rest value to Plaid by mistake.

---

# Prior pass (v5.0.2)



An independent audit found 14 concrete, verified issues in the shipped
v5.0.1 code — 13 from a structural read-through, plus a 14th
(`routes/link.js` importing the deleted dead auth module) caught only while
fixing the others and re-verified by actually `require()`-ing every
route/job/intelligence module against a fake environment. All 22
non-entrypoint modules and the real `index.js` entrypoint now load and wire
together without a `require` error (verified in this pass; this checks
wiring, not runtime correctness against a real database).

### Critical (broke core flows)

1. **`db.js` `withServiceRole()` never called `set_config('app.is_service_role', ...)`.**
   Every write to `plaid_webhook_events`, `reconciliation_runs`,
   `data_quality_events`, and `audit_trail` — all RLS-gated on that setting —
   was being silently rejected. This is the single most severe bug found: it
   broke webhook ingestion, reconciliation, and audit logging, despite an
   inline code comment in `routes/webhook.js` explicitly (and incorrectly)
   claiming it was already fixed. **Fixed** in `db.js`.
2. **`routes/dashboard.js` was never mounted** in `index.js`. The `/me/dashboard`
   endpoint didn't exist in the running app. **Fixed**: mounted in `index.js`.
3. **`routes/dashboard.js` imported a nonexistent export** (`require('./auth').authMiddleware`,
   but `routes/auth.js` only exported the router) — would have thrown at
   startup the moment it was mounted. **Fixed**: `routes/auth.js` now exports
   `{ router, authMiddleware }`.
4. **`routes/dashboard.js` imported `authMiddleware` but never applied it**
   as route middleware — found while fixing #3. The dashboard route would
   have run fully unauthenticated (`req.userId` undefined). **Fixed**: added
   `router.use(authMiddleware)`.
5. **Two parallel, unreconciled auth implementations.** `src/auth/auth.js`
   (dead: single 7-day JWT, no refresh rotation, no email normalization/password
   policy) vs. the real, mounted `routes/auth.js` (refresh-token rotation,
   family revocation, 15-minute access tokens). `routes/me.js` **and**
   `routes/link.js` (the latter found only during the fix-verification pass,
   not the original audit) imported the dead module's `authMiddleware`.
   **Fixed**: `src/auth/auth.js` deleted; `me.js` and `link.js` now import
   `authMiddleware` from `routes/auth.js`, the single real implementation.
6. **No background worker/scheduler existed at all.** `processWebhookEvents`,
   `reconcileRoundupAccumulators`, `runIncomeReviewForAllPendingUsers`,
   `closeBatch`, and every intelligence engine (`computeCashFlowPeriod`,
   `computeNetWorthSnapshot`, `computeLiquiditySignal`, `computeFeeSignal`,
   `detectRecurringStreams`) were fully implemented but never invoked by
   anything. **Fixed**: added `apps/api/src/worker.js`, a documented
   minimum-viable poll loop, and a `npm run worker` script. This is
   explicitly NOT a production task queue — see the comment at the top of
   `worker.js` for what to evaluate before `PRODUCTION_VALIDATED`.
7. **`applyRoundupForTransaction` (`pendingPosted.js`) was never called**,
   including not from `sync.js` — the pending→posted Round-Up migration path
   the spec calls mandatory was dead code. **Fixed**: `sync.js` now routes
   newly-inserted transactions through it.

### Functional gaps (features implied/required, absent)

8. **No password-reset route existed**, despite the `password_reset_tokens`
   table, `FRONTEND_RESET_URL`/`SMTP_*` env vars, and `nodemailer` dependency
   all being present. **Fixed**: added `POST /auth/request-reset` and
   `POST /auth/reset` — single-use token, 30-minute expiry, no
   user-existence leak, revokes all existing sessions on successful reset.
9. **No email-verification route exists.** `FRONTEND_EMAIL_VERIFY_URL` is
   still defined in `.env.example` but nothing consumes it. **Not fixed** —
   flagged as `IMPLEMENTATION_REQUIRED`, not silently dropped or falsely
   claimed as done. No `email_verified` column exists in the `users` table
   either, so this needs a schema decision before a route can be written;
   inventing one without that decision would just be more
   unsupported-certainty of the kind this audit exists to catch.
10. **`isPaymentNotPurchase` was hardcoded `false`** in `sync.js`, permanently
    disabling the `CREDIT_CARD_PAYMENT` classification rule. **Fixed**: now
    computed as `account.type === 'credit' && amount_cents < 0 && transferMatch`,
    per the spec's own §29.9 predicate (negative-amount transaction on a
    credit account, corroborated by a confirmed transfer relationship — not
    amount sign or account type alone).

### Consistency / hygiene

11. **`JWT_EXPIRES_IN=7d` in `.env.example` had zero effect** — only the now-deleted
    dead auth module read it. **Fixed**: removed, replaced with a comment
    explaining access/refresh TTLs are fixed constants in `routes/auth.js` by
    design.
12. **`users`, `auth_refresh_sessions`, `password_reset_tokens` shipped with no
    RLS policy at all** (not even a documented service-role-only gate) —
    `merchants`/`merchant_aliases` correctly have none since they're global
    reference data with no `user_id` column. **Fixed**: added
    `database/migrations/003_rls_closure.sql` — `users` gets an
    owner-or-service-role policy (it's read via both `withUserContext` in
    `GET /me` and `withServiceRole` in signup/login/reset); the other two get
    service-role-only, matching the pattern already used for
    `plaid_webhook_events` etc.
13. **`002_closure_corrections.sql` contained no-op statements** (dropping
    `NOT NULL`/`DEFAULT` from a column `001` already defines without them).
    **Annotated, not deleted** — added a comment explaining why, so a future
    maintainer doesn't assume it's a mistake.

## Found during the fix pass itself (beyond the original 13)

14. **`routes/link.js` also imported the dead auth module** — missed in the
    initial audit, caught only by actually requiring every wired module
    against a fake environment after the other fixes. Fixed the same way as #5.
15. **`runIncomeReviewForAllPendingUsers()` used a plain, no-context DB
    connection** to query the RLS-protected `transactions` table, which would
    have silently returned zero rows every time — making the "run across all
    users" wrapper permanently a no-op. **Fixed**: switched to
    `db.withServiceRole()`, same fix class as #1.

## What was checked and found NOT to need fixing

`classify.js`'s rule ordering and the two-pass income resolution;
`roundup/rules.js`'s accumulator delta logic, batch open/close/recompute, and
closed-batch data-quality-flag path — all read in full and internally
consistent.

## Explicit ledger — remaining items

| Item | Status |
|---|---|
| Email verification route + `users.email_verified` column | `IMPLEMENTATION_REQUIRED` |
| Frontend to receive Plaid's OAuth redirect | `IMPLEMENTATION_REQUIRED` — `PLAID_OAUTH_REDIRECT_URI` is wired on the backend but has nowhere to send the user; non-OAuth Sandbox institutions (e.g. "First Platypus Bank") are unaffected and testable now |
| `worker.js`'s in-process `setInterval` model vs. a real job queue for multi-instance deployment | `RUNTIME_VALIDATION_REQUIRED` — fine for a single instance; re-evaluate before scaling out |
| Every SQL migration in this package | `RUNTIME_VALIDATION_REQUIRED` — never executed against a real Postgres instance in this pass (no database available in the environment this fix was produced in); reviewed by hand for column/table-name correctness against `001`'s actual DDL, not executed |
| The actual Render deploy (build command, start command, worker as a second service, health checks) | `RUNTIME_VALIDATION_REQUIRED` — this pass fixed what code-level static analysis could find (PORT binding, SSL, engines, .gitignore); it has not been through Render's actual build/deploy pipeline, because this environment cannot reach Render |
| The actual Supabase connection (pooler reachability, RLS behavior under load, migration execution) | `RUNTIME_VALIDATION_REQUIRED` — same reason; SSL/host guidance here is based on Supabase's current published docs, not a live connection test |
| Live Plaid Sandbox integration end-to-end (Link → webhook → sync → dashboard), OAuth consent flows, concurrent-load/failure-injection testing | `RUNTIME_VALIDATION_REQUIRED` — the specific blocker that would have prevented this (missing first `/transactions/sync` call) is now fixed, but "fixed in code" and "confirmed working against live Plaid Sandbox" are different claims; only the latter is real validation |
| Frontend beyond the OAuth-redirect page | `INTENTIONALLY_OUT_OF_SCOPE` — no frontend implementation was supplied in any source artifact; none is fabricated here |

This ledger is deliberately not "0 remaining items." A static audit, however
careful, cannot certify what only executing the code against real
infrastructure can. Run the migrations against a real (ideally disposable)
Postgres instance, deploy to Render, connect to Supabase, and link a Sandbox
Item end-to-end before treating this as anything past **IMPLEMENTED**.
