BEGIN;

-- SOURCE: 5.2 Identity (custom auth â€” final, per 0.1)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ibag_app') THEN
    CREATE ROLE ibag_app NOLOGIN NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ibag_service') THEN
    CREATE ROLE ibag_service NOLOGIN NOINHERIT BYPASSRLS;
  END IF;
END $$;

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- SOURCE: 5.3 Provider connection layer
CREATE TABLE plaid_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plaid_item_id TEXT NOT NULL UNIQUE,
  plaid_access_token_encrypted TEXT NOT NULL,
  institution_id TEXT,
  institution_name TEXT,
  cursor TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  last_synced_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE provider_capabilities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plaid_item_id UUID NOT NULL REFERENCES plaid_items(id) ON DELETE CASCADE,
  domain TEXT NOT NULL,
  requested BOOLEAN NOT NULL DEFAULT false,
  consented BOOLEAN NOT NULL DEFAULT false,
  supported_by_institution BOOLEAN,
  last_successful_sync_at TIMESTAMPTZ,
  last_failed_sync_at TIMESTAMPTZ,
  last_error TEXT,
  UNIQUE (plaid_item_id, domain)
);

CREATE TABLE accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plaid_item_id UUID NOT NULL REFERENCES plaid_items(id) ON DELETE CASCADE,
  plaid_account_id TEXT NOT NULL UNIQUE,
  name TEXT,
  official_name TEXT,
  mask TEXT,
  type TEXT,
  subtype TEXT,
  current_balance_cents BIGINT,
  available_balance_cents BIGINT,
  balance_as_of TIMESTAMPTZ,
  iso_currency_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- SOURCE: 5.4 Raw observation lineage
CREATE TABLE source_observations (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL DEFAULT 'plaid',
  provider_endpoint TEXT NOT NULL,
  provider_request_id TEXT,
  provider_item_id TEXT,
  provider_entity_id TEXT,
  payload_hash TEXT NOT NULL,
  raw_payload JSONB NOT NULL,
  schema_version TEXT NOT NULL,
  environment TEXT NOT NULL,
  retrieved_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_source_obs_entity ON source_observations (provider_entity_id);

-- SOURCE: 5.5 Transactions and classification
CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  plaid_transaction_id TEXT NOT NULL UNIQUE,
  amount_cents BIGINT NOT NULL,               -- Plaid convention: positive = money out (debit)
  iso_currency_code TEXT,
  merchant_name TEXT,
  provider_category TEXT,
  pending BOOLEAN NOT NULL DEFAULT false,
  pending_transaction_id TEXT,
  authorized_date DATE,
  posted_date DATE,
  removed_at TIMESTAMPTZ,
  removal_reason TEXT,
  raw JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_transactions_user_date ON transactions (user_id, posted_date DESC);
CREATE INDEX idx_transactions_account ON transactions (account_id);
CREATE INDEX idx_transactions_pending_link ON transactions (pending_transaction_id);

CREATE TABLE transaction_classifications (
  id BIGSERIAL PRIMARY KEY,
  transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  classification TEXT NOT NULL,
  classification_version TEXT NOT NULL,
  confidence NUMERIC(4,3),
  evidence JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (transaction_id, classification_version)
);

CREATE TABLE merchants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  canonical_name TEXT NOT NULL UNIQUE
);

CREATE TABLE merchant_aliases (
  id BIGSERIAL PRIMARY KEY,
  merchant_id UUID NOT NULL REFERENCES merchants(id) ON DELETE CASCADE,
  provider_merchant_name TEXT NOT NULL UNIQUE
);

CREATE TABLE transaction_relationships (
  id BIGSERIAL PRIMARY KEY,
  transaction_id_a UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  transaction_id_b UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  relationship_type TEXT NOT NULL,
  confidence NUMERIC(4,3),
  detected_by TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- v4.2 fix: without this CHECK, (A,B) and (B,A) are distinct rows to Postgres,
  -- so the UNIQUE constraint below doesn't actually stop the same pair being
  -- inserted twice in opposite order. The canonical rule is: the lexicographically
  -- smaller UUID always goes in transaction_id_a. Enforce it at the DB level, not
  -- just by convention in application code, so a bug in the detector can't violate it.
  CONSTRAINT transaction_relationships_canonical_order CHECK (transaction_id_a < transaction_id_b),
  UNIQUE (transaction_id_a, transaction_id_b, relationship_type)
);

-- SOURCE: 5.6 Round-Up engine
CREATE TABLE roundup_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  rule_version TEXT NOT NULL,
  source_amount_cents BIGINT NOT NULL,
  roundup_cents BIGINT NOT NULL,
  eligibility_status TEXT NOT NULL,
  eligibility_reason TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (transaction_id, rule_version)
);

CREATE TABLE roundup_corrections (
  id BIGSERIAL PRIMARY KEY,
  original_event_id UUID NOT NULL REFERENCES roundup_events(id),
  reason TEXT NOT NULL,
  old_source_amount_cents BIGINT NOT NULL,
  new_source_amount_cents BIGINT NOT NULL,
  old_roundup_cents BIGINT NOT NULL,
  new_roundup_cents BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE roundup_accumulators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  total_cents BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (account_id)
);

CREATE TABLE roundup_batches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  accumulator_id UUID NOT NULL REFERENCES roundup_accumulators(id),
  total_cents BIGINT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at TIMESTAMPTZ
);

CREATE TABLE roundup_line_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES roundup_batches(id) ON DELETE CASCADE,
  roundup_event_id UUID NOT NULL REFERENCES roundup_events(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (batch_id, roundup_event_id)
);

-- SOURCE: 5.7 Liabilities, investments, identity
CREATE TABLE liabilities_credit (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  is_overdue BOOLEAN,
  last_payment_amount_cents BIGINT,
  last_payment_date DATE,
  minimum_payment_amount_cents BIGINT,
  next_payment_due_date DATE,
  apr_percentage NUMERIC(5,2),
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE liabilities_student (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  loan_name TEXT,
  outstanding_interest_cents BIGINT,
  origination_principal_cents BIGINT,
  disbursement_dates JSONB,
  interest_rate_percentage NUMERIC(6,3),
  is_overdue BOOLEAN,
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
  -- No servicer_address column â€” not part of Plaid's documented student loan liability
  -- object. Do not reintroduce without a confirmed source.
);

CREATE TABLE liabilities_mortgage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  loan_type_description TEXT,
  interest_rate_percentage NUMERIC(6,3),
  maturity_date DATE,
  next_payment_due_date DATE,
  next_monthly_payment_cents BIGINT,
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE investment_holdings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  security_id TEXT,
  security_name TEXT,
  ticker_symbol TEXT,
  quantity NUMERIC(20,8),
  institution_price_cents BIGINT,
  institution_value_cents BIGINT,
  cost_basis_cents BIGINT,
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE investment_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  plaid_investment_transaction_id TEXT NOT NULL UNIQUE,
  security_id TEXT,
  type TEXT,
  amount_cents BIGINT,
  quantity NUMERIC(20,8),
  price_cents BIGINT,
  date DATE,
  raw JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE identity_data (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  legal_name TEXT,
  emails JSONB,
  phone_numbers JSONB,
  addresses JSONB,
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- SOURCE: 5.8 Intelligence tables
CREATE TABLE income_signals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_merchant TEXT,
  cadence TEXT,
  average_amount_cents BIGINT,
  last_detected_date DATE,
  next_expected_date DATE,          -- NULL whenever cadence = 'irregular', enforced in application code (9.2)
  confidence NUMERIC(4,3),
  evidence_state TEXT NOT NULL DEFAULT 'insufficient_evidence',
  calculation_version TEXT NOT NULL DEFAULT 'income_v1'
  -- v4.2 fix: a plain UNIQUE(user_id, source_merchant) does NOT stop duplicate
  -- rows when source_merchant IS NULL, because Postgres treats every NULL as
  -- distinct from every other NULL in a UNIQUE constraint. A user with two
  -- unattributed income sources could silently get two rows. Replaced below
  -- with two partial unique indexes: one for the common named-merchant case,
  -- one that treats "no merchant" as a single well-known key per user.
  ,updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX idx_income_signals_user_merchant
  ON income_signals (user_id, source_merchant) WHERE source_merchant IS NOT NULL;
CREATE UNIQUE INDEX idx_income_signals_user_no_merchant
  ON income_signals (user_id) WHERE source_merchant IS NULL;

CREATE TABLE recurring_streams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  merchant_id UUID REFERENCES merchants(id),
  stream_type TEXT NOT NULL,
  cadence TEXT NOT NULL,
  average_amount_cents BIGINT NOT NULL,
  amount_variance_cents BIGINT,
  last_observed_date DATE,
  next_expected_date DATE,
  confidence NUMERIC(4,3),
  calculation_version TEXT NOT NULL DEFAULT 'recurring_v1',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, merchant_id, stream_type)
);

CREATE TABLE cash_flow_periods (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  income_cents BIGINT NOT NULL DEFAULT 0,
  spending_cents BIGINT NOT NULL DEFAULT 0,
  transfer_cents BIGINT NOT NULL DEFAULT 0,
  fee_cents BIGINT NOT NULL DEFAULT 0,
  calculation_version TEXT NOT NULL DEFAULT 'cash_flow_v1',
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, period_start, period_end, calculation_version)
);

CREATE TABLE net_worth_snapshots (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  as_of_date DATE NOT NULL,
  assets_cents BIGINT,
  liabilities_cents BIGINT,
  net_worth_cents BIGINT,
  included_domains TEXT[] NOT NULL,
  missing_domains TEXT[] NOT NULL DEFAULT '{}',
  evidence_state TEXT NOT NULL,
  calculation_version TEXT NOT NULL DEFAULT 'net_worth_v1',
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, as_of_date, calculation_version)
);

CREATE TABLE financial_health_signals (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  signal_type TEXT NOT NULL,
  value NUMERIC,
  evidence_state TEXT NOT NULL,
  confidence NUMERIC(4,3),
  calculation_version TEXT NOT NULL,
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, signal_type, calculation_version)
);

-- SOURCE: 5.9 Webhook, sync, audit, quality infrastructure
CREATE TABLE plaid_webhook_events (
  id BIGSERIAL PRIMARY KEY,
  idempotency_key TEXT NOT NULL UNIQUE,
  item_id TEXT,
  webhook_type TEXT,
  webhook_code TEXT,
  request_id TEXT,
  body_sha256 TEXT NOT NULL,
  raw_body BYTEA,
  verification_status TEXT NOT NULL,
  processing_status TEXT NOT NULL DEFAULT 'received',
  processing_error TEXT,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ
);

CREATE TABLE sync_runs (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plaid_item_id UUID NOT NULL REFERENCES plaid_items(id) ON DELETE CASCADE,
  trigger TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'running',
  added_count INT DEFAULT 0,
  modified_count INT DEFAULT 0,
  removed_count INT DEFAULT 0,
  error_message TEXT,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);

CREATE TABLE reconciliation_runs (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  scope TEXT NOT NULL,
  status TEXT NOT NULL,
  expected_value_cents BIGINT,
  actual_value_cents BIGINT,
  details JSONB,
  run_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE data_quality_events (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  issue_type TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  details JSONB,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE audit_trail (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  event_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  payload JSONB,
  created_by TEXT,
  record_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- SOURCE: 5.10 Row-Level Security â€” every user-owned table, in full
-- Run once per table. Pattern: enable RLS, then a single owner policy.
-- App code must call: SELECT set_config('app.current_user_id', $1, true);
-- inside the same transaction/connection as every query below, using the
-- user id extracted from a verified JWT (see Section 8.1's authMiddleware).

-- v4.2: `users` deliberately has NO RLS policy in this section, and that is a
-- stated decision, not an oversight. Signup and login run BEFORE any verified
-- JWT exists, so there is no `app.current_user_id` to gate on yet at the moment
-- these queries run (Section 8.2 `signup`/`login` use the plain pool, not
-- `withUserContext`). The `users` table is instead protected by query-shape
-- discipline: application code only ever selects a single row by `id` or
-- `email`, and application code is the only thing that talks to Postgres â€”
-- there is no untrusted client path that can issue an arbitrary SELECT against
-- it. If a future endpoint ever needs to list or filter `users` directly,
-- RLS must be added at that time; this exception applies only to the
-- signup/login/lookup-by-id access pattern specified here.

ALTER TABLE plaid_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON plaid_items USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON accounts USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE source_observations ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON source_observations USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON transactions USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE roundup_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_events USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE roundup_accumulators ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_accumulators USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE roundup_batches ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_batches USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE liabilities_credit ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON liabilities_credit USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE liabilities_student ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON liabilities_student USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE liabilities_mortgage ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON liabilities_mortgage USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE investment_holdings ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON investment_holdings USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE investment_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON investment_transactions USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE identity_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON identity_data USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE income_signals ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON income_signals USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE recurring_streams ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON recurring_streams USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE cash_flow_periods ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON cash_flow_periods USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE net_worth_snapshots ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON net_worth_snapshots USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE financial_health_signals ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON financial_health_signals USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE sync_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON sync_runs USING (user_id = current_setting('app.current_user_id', true)::uuid);

-- Indirectly user-scoped (no direct user_id column) â€” restrict via join-based policy
ALTER TABLE roundup_line_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_line_items USING (
  batch_id IN (SELECT id FROM roundup_batches WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

-- Not user-owned â€” global reference data, no RLS needed
-- merchants, merchant_aliases

-- Admin/system-only, never exposed to the app_role used by ordinary requests
ALTER TABLE plaid_webhook_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON plaid_webhook_events USING (current_setting('app.is_service_role', true)::boolean = true);

ALTER TABLE reconciliation_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON reconciliation_runs USING (current_setting('app.is_service_role', true)::boolean = true);

ALTER TABLE data_quality_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON data_quality_events USING (current_setting('app.is_service_role', true)::boolean = true);

ALTER TABLE audit_trail ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON audit_trail USING (current_setting('app.is_service_role', true)::boolean = true);
REVOKE UPDATE, DELETE ON audit_trail FROM ibag_app;   -- append-only enforced at the grant level, not just policy

ALTER TABLE provider_capabilities ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON provider_capabilities USING (
  plaid_item_id IN (SELECT id FROM plaid_items WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

ALTER TABLE transaction_classifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON transaction_classifications USING (
  transaction_id IN (SELECT id FROM transactions WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

ALTER TABLE transaction_relationships ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON transaction_relationships USING (
  transaction_id_a IN (SELECT id FROM transactions WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

ALTER TABLE roundup_corrections ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_corrections USING (
  original_event_id IN (SELECT id FROM roundup_events WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

-- Restrict ordinary application policies to the dedicated app role.
ALTER POLICY owner_only ON plaid_items TO ibag_app;
ALTER POLICY owner_only ON accounts TO ibag_app;
ALTER POLICY owner_only ON source_observations TO ibag_app;
ALTER POLICY owner_only ON transactions TO ibag_app;
ALTER POLICY owner_only ON roundup_events TO ibag_app;
ALTER POLICY owner_only ON roundup_accumulators TO ibag_app;
ALTER POLICY owner_only ON roundup_batches TO ibag_app;
ALTER POLICY owner_only ON liabilities_credit TO ibag_app;
ALTER POLICY owner_only ON liabilities_student TO ibag_app;
ALTER POLICY owner_only ON liabilities_mortgage TO ibag_app;
ALTER POLICY owner_only ON investment_holdings TO ibag_app;
ALTER POLICY owner_only ON investment_transactions TO ibag_app;
ALTER POLICY owner_only ON identity_data TO ibag_app;
ALTER POLICY owner_only ON income_signals TO ibag_app;
ALTER POLICY owner_only ON recurring_streams TO ibag_app;
ALTER POLICY owner_only ON cash_flow_periods TO ibag_app;
ALTER POLICY owner_only ON net_worth_snapshots TO ibag_app;
ALTER POLICY owner_only ON financial_health_signals TO ibag_app;
ALTER POLICY owner_only ON sync_runs TO ibag_app;
ALTER POLICY owner_only ON roundup_line_items TO ibag_app;
ALTER POLICY owner_only ON provider_capabilities TO ibag_app;
ALTER POLICY owner_only ON transaction_classifications TO ibag_app;
ALTER POLICY owner_only ON transaction_relationships TO ibag_app;
ALTER POLICY owner_only ON roundup_corrections TO ibag_app;

-- Explicit grants for the dedicated direct-Postgres roles.
GRANT USAGE ON SCHEMA public TO ibag_app, ibag_service;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO ibag_app;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ibag_service;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ibag_app, ibag_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ibag_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT ALL PRIVILEGES ON TABLES TO ibag_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO ibag_app, ibag_service;

ALTER POLICY service_role_only ON plaid_webhook_events TO ibag_service;
ALTER POLICY service_role_only ON reconciliation_runs TO ibag_service;
ALTER POLICY service_role_only ON data_quality_events TO ibag_service;
ALTER POLICY service_role_only ON audit_trail TO ibag_service;

CREATE POLICY data_quality_user_select
ON data_quality_events
FOR SELECT TO ibag_app
USING (user_id = current_setting('app.current_user_id', true)::uuid);

-- SOURCE: 14.2 Composite parent/child integrity
ALTER TABLE plaid_items
  ADD CONSTRAINT uq_plaid_items_id_user UNIQUE(id,user_id);

ALTER TABLE accounts
  ADD CONSTRAINT uq_accounts_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_accounts_item_user
    FOREIGN KEY(plaid_item_id,user_id)
    REFERENCES plaid_items(id,user_id);

ALTER TABLE transactions
  ADD CONSTRAINT uq_transactions_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_transactions_account_user
    FOREIGN KEY(account_id,user_id)
    REFERENCES accounts(id,user_id);

ALTER TABLE roundup_events
  ADD CONSTRAINT uq_roundup_events_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_roundup_events_transaction_user
    FOREIGN KEY(transaction_id,user_id)
    REFERENCES transactions(id,user_id);

ALTER TABLE roundup_accumulators
  ADD CONSTRAINT uq_roundup_accumulators_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_roundup_accumulators_account_user
    FOREIGN KEY(account_id,user_id)
    REFERENCES accounts(id,user_id);

ALTER TABLE roundup_batches
  ADD CONSTRAINT uq_roundup_batches_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_roundup_batches_accumulator_user
    FOREIGN KEY(accumulator_id,user_id)
    REFERENCES roundup_accumulators(id,user_id);

ALTER TABLE roundup_line_items
  ADD COLUMN user_id UUID;

UPDATE roundup_line_items rli
SET user_id = rb.user_id
FROM roundup_batches rb
WHERE rb.id = rli.batch_id;

ALTER TABLE roundup_line_items
  ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE roundup_line_items
  ADD CONSTRAINT fk_roundup_line_batch_user
    FOREIGN KEY(batch_id,user_id)
    REFERENCES roundup_batches(id,user_id),
  ADD CONSTRAINT fk_roundup_line_event_user
    FOREIGN KEY(roundup_event_id,user_id)
    REFERENCES roundup_events(id,user_id);

ALTER TABLE liabilities_credit
  ADD CONSTRAINT fk_liabilities_credit_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE liabilities_student
  ADD CONSTRAINT fk_liabilities_student_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE liabilities_mortgage
  ADD CONSTRAINT fk_liabilities_mortgage_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE investment_holdings
  ADD CONSTRAINT fk_investment_holdings_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE investment_transactions
  ADD CONSTRAINT fk_investment_transactions_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE identity_data
  ADD CONSTRAINT fk_identity_data_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE sync_runs
  ADD CONSTRAINT fk_sync_runs_item_user
    FOREIGN KEY(plaid_item_id,user_id) REFERENCES plaid_items(id,user_id);

-- SOURCE: 28.3 Authentication session schema
CREATE TABLE auth_refresh_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  family_id UUID NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  issued_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  replaced_by UUID REFERENCES auth_refresh_sessions(id),
  user_agent TEXT,
  ip_hash TEXT
);

CREATE INDEX idx_auth_refresh_user ON auth_refresh_sessions(user_id);
CREATE INDEX idx_auth_refresh_family ON auth_refresh_sessions(family_id);

CREATE TABLE password_reset_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  consumed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_password_reset_user ON password_reset_tokens(user_id);

ALTER TABLE plaid_webhook_events ADD COLUMN IF NOT EXISTS attempt_count INT NOT NULL DEFAULT 0;
ALTER TABLE plaid_webhook_events ADD COLUMN IF NOT EXISTS max_attempts INT NOT NULL DEFAULT 8;
ALTER TABLE plaid_webhook_events ADD COLUMN IF NOT EXISTS last_attempt_at TIMESTAMPTZ;
ALTER TABLE plaid_webhook_events ADD COLUMN IF NOT EXISTS next_attempt_at TIMESTAMPTZ;

COMMIT;
