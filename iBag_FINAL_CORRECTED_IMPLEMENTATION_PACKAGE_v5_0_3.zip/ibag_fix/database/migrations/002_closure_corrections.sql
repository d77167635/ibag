BEGIN;
-- NOTE (closure audit): the four ALTERs below are verified no-ops against
-- this package's 001_initial_schema.sql — accounts.iso_currency_code and
-- transactions.iso_currency_code are already defined there as nullable with
-- no default (Section 29.5's "no silent USD" rule). They're left in place
-- rather than deleted, because this migration is written to also be safe to
-- run against an *older* schema generation that did define
-- `iso_currency_code TEXT NOT NULL DEFAULT 'USD'` (an earlier draft of this
-- spec had that bug) — DROP NOT NULL / DROP DEFAULT are themselves no-ops if
-- the column is already nullable/default-less, so this migration is
-- idempotent either way and there's no reason to special-case it.
ALTER TABLE accounts ALTER COLUMN iso_currency_code DROP NOT NULL;
ALTER TABLE accounts ALTER COLUMN iso_currency_code DROP DEFAULT;
ALTER TABLE transactions ALTER COLUMN iso_currency_code DROP NOT NULL;
ALTER TABLE transactions ALTER COLUMN iso_currency_code DROP DEFAULT;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'active';
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS closed_at TIMESTAMPTZ;
ALTER TABLE provider_capabilities ADD COLUMN IF NOT EXISTS product_enabled BOOLEAN;
ALTER TABLE provider_capabilities ADD COLUMN IF NOT EXISTS observed BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE provider_capabilities ADD COLUMN IF NOT EXISTS last_observation_id BIGINT;
ALTER TABLE roundup_line_items ADD COLUMN IF NOT EXISTS roundup_cents_snapshot BIGINT;
ALTER TABLE roundup_corrections ADD COLUMN IF NOT EXISTS old_source_amount_cents BIGINT;
ALTER TABLE roundup_corrections ADD COLUMN IF NOT EXISTS new_source_amount_cents BIGINT;
UPDATE roundup_line_items rli SET roundup_cents_snapshot = re.roundup_cents FROM roundup_events re WHERE re.id = rli.roundup_event_id AND rli.roundup_cents_snapshot IS NULL;
COMMIT;
