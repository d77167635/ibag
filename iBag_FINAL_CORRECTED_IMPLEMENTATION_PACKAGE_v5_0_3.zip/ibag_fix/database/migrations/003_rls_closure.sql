BEGIN;

-- CLOSURE FIX (#11): users, auth_refresh_sessions, and password_reset_tokens
-- shipped with RLS not enabled at all — no policy of any kind, not even a
-- documented service_role_only gate. 001's comment on `users` said this was
-- intentional because "signup/login use the plain pool" (no verified
-- app.current_user_id exists yet at that point) — that reasoning was correct
-- for signup/login, but incomplete: it never accounted for GET /me
-- (routes/me.js), which reads `users` through withUserContext, and it
-- predates 002/db.js's fix making withServiceRole() actually set
-- app.is_service_role. Both settings are now reliably true when they should
-- be, so all three tables can get a real, enforced policy instead of relying
-- on "application code only ever queries by id" as the sole protection.
--
-- users: readable/writable by its own owner (GET /me) OR by the service role
-- (signup, login, refresh, password reset — all of which run before a
-- verified user JWT exists for the request, or need to look a user up by
-- email rather than id).
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_or_service_role ON users USING (
  id = current_setting('app.current_user_id', true)::uuid
  OR current_setting('app.is_service_role', true)::boolean = true
);

-- auth_refresh_sessions and password_reset_tokens are never read through a
-- user-context connection anywhere in the codebase (routes/auth.js exclusively
-- uses withServiceRole for all of signup/login/refresh/logout/reset) — a
-- refresh or reset token is looked up by its own opaque hash, never by
-- user_id from a request already carrying a verified access token. So these
-- two are correctly service_role_only, matching the pattern already used for
-- plaid_webhook_events/reconciliation_runs/data_quality_events/audit_trail.
ALTER TABLE auth_refresh_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON auth_refresh_sessions USING (
  current_setting('app.is_service_role', true)::boolean = true
);

ALTER TABLE password_reset_tokens ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON password_reset_tokens USING (
  current_setting('app.is_service_role', true)::boolean = true
);

-- merchants and merchant_aliases intentionally remain without RLS: they carry
-- no user_id column and are global reference data (canonical merchant names
-- and provider-name aliases), not user-owned rows. Recorded here explicitly
-- so this is a documented disposition, not a silent omission.

COMMIT;
