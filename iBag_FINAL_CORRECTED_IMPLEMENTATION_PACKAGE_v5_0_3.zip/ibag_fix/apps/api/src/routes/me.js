const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('./auth');

router.use(authMiddleware);

router.get('/me', async (req, res) => {
  const result = await db.withUserContext(req.userId, (client) =>
    client.query('SELECT id, email, created_at FROM users WHERE id = $1', [req.userId])
  );
  if (result.rows.length === 0) return res.status(404).json({ status: 'error', code: 'USER_NOT_FOUND' });
  res.json({ status: 'ok', user: result.rows[0] });
});

router.get('/me/accounts', async (req, res) => {
  const result = await db.withUserContext(req.userId, (client) =>
    client.query(
      `SELECT id, name, official_name, mask, type, subtype, current_balance_cents,
              available_balance_cents, iso_currency_code
       FROM accounts WHERE user_id = $1 ORDER BY created_at ASC`,
      [req.userId]
    )
  );
  res.json({ status: 'ok', accounts: result.rows });
});

router.get('/me/net-worth', async (req, res) => {
  const result = await db.withUserContext(req.userId, (client) =>
    client.query(
      `SELECT * FROM net_worth_snapshots WHERE user_id = $1 ORDER BY as_of_date DESC LIMIT 1`,
      [req.userId]
    )
  );
  res.json({ status: 'ok', netWorth: result.rows[0] || null });
});

router.get('/me/roundups', async (req, res) => {
  const result = await db.withUserContext(req.userId, (client) =>
    client.query(
      `SELECT ra.account_id, ra.total_cents, ra.updated_at
       FROM roundup_accumulators ra WHERE ra.user_id = $1`,
      [req.userId]
    )
  );
  res.json({ status: 'ok', accumulators: result.rows });
});

module.exports = router;
