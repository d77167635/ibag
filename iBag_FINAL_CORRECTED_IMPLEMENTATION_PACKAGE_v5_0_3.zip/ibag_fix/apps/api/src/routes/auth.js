const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const router = express.Router();
const db = require('../db');

const BCRYPT_COST = 12;
const ACCESS_TTL = '15m';
const REFRESH_TTL_DAYS = 30;
const ISSUER = 'ibag-api';
const AUDIENCE = 'ibag-client';
const DUMMY_HASH = bcrypt.hashSync('ibag-dummy-password', BCRYPT_COST);

function normalizeEmail(value) {
  if (typeof value !== 'string') throw new Error('INVALID_EMAIL');
  const email = value.trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('INVALID_EMAIL');
  return email;
}

function assertPassword(password) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 200) {
    const err = new Error('INVALID_PASSWORD');
    err.code = 'INVALID_PASSWORD';
    throw err;
  }
}

function issueAccessToken(userId) {
  return jwt.sign(
    { sub: userId },
    process.env.JWT_SECRET,
    {
      algorithm: 'HS256',
      expiresIn: ACCESS_TTL,
      issuer: ISSUER,
      audience: AUDIENCE,
    }
  );
}

// CLOSURE FIX: this is now the ONLY authMiddleware in the codebase. Previously
// two parallel, unreconciled auth implementations existed — this file
// (refresh-rotation, mounted at /auth) and src/auth/auth.js (a dead, weaker,
// single-long-lived-JWT implementation with no refresh rotation, no email
// normalization, no password policy) whose authMiddleware routes/me.js was
// importing. They only happened to interoperate because they coincidentally
// shared JWT_SECRET/issuer/audience — not because anyone designed it that way.
// src/auth/auth.js has been deleted; every route now imports authMiddleware
// from here.
function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ status: 'error', code: 'MISSING_TOKEN', message: 'Authorization required.' });
  }
  try {
    const payload = jwt.verify(header.slice(7), process.env.JWT_SECRET, {
      algorithms: ['HS256'],
      issuer: ISSUER,
      audience: AUDIENCE,
    });
    req.userId = payload.sub;
    next();
  } catch (err) {
    return res.status(401).json({ status: 'error', code: 'INVALID_TOKEN', message: 'Invalid or expired token.' });
  }
}

function hashOpaqueToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function createRefreshToken() {
  return crypto.randomBytes(48).toString('base64url');
}

function refreshExpiry() {
  return new Date(Date.now() + REFRESH_TTL_DAYS * 86400000);
}

async function createRefreshSession(client, userId, familyId = crypto.randomUUID()) {
  const token = createRefreshToken();
  const hash = hashOpaqueToken(token);

  const result = await client.query(
    `INSERT INTO auth_refresh_sessions
       (user_id, family_id, token_hash, expires_at)
     VALUES ($1,$2,$3,$4)
     RETURNING id`,
    [userId, familyId, hash, refreshExpiry()]
  );

  return { token, sessionId: result.rows[0].id, familyId };
}

router.post('/signup', async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    assertPassword(req.body.password);

    const passwordHash = await bcrypt.hash(req.body.password, BCRYPT_COST);

    const result = await db.withServiceRole(async (client) => {
      const inserted = await client.query(
        `INSERT INTO users (email, password_hash)
         VALUES ($1,$2)
         ON CONFLICT (email) DO NOTHING
         RETURNING id, email, created_at`,
        [email, passwordHash]
      );

      if (inserted.rows.length === 0) {
        const err = new Error('EMAIL_ALREADY_REGISTERED');
        err.code = 'EMAIL_ALREADY_REGISTERED';
        throw err;
      }

      const user = inserted.rows[0];
      const refresh = await createRefreshSession(client, user.id);
      return {
        user,
        accessToken: issueAccessToken(user.id),
        refreshToken: refresh.token,
      };
    });

    res.status(201).json({ status: 'ok', ...result });
  } catch (err) {
    next(err);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const password = req.body.password;

    const result = await db.withServiceRole(async (client) => {
      const found = await client.query(
        `SELECT id, email, password_hash, created_at
         FROM users WHERE email = $1`,
        [email]
      );

      const user = found.rows[0];
      const valid = await bcrypt.compare(
        typeof password === 'string' ? password : '',
        user ? user.password_hash : DUMMY_HASH
      );

      if (!user || !valid) {
        const err = new Error('INVALID_CREDENTIALS');
        err.code = 'INVALID_CREDENTIALS';
        throw err;
      }

      const refresh = await createRefreshSession(client, user.id);

      return {
        user: {
          id: user.id,
          email: user.email,
          created_at: user.created_at,
        },
        accessToken: issueAccessToken(user.id),
        refreshToken: refresh.token,
      };
    });

    res.json({ status: 'ok', ...result });
  } catch (err) {
    next(err);
  }
});

router.post('/refresh', async (req, res, next) => {
  try {
    const presented = req.body.refreshToken;
    if (typeof presented !== 'string' || presented.length < 32) {
      return res.status(401).json({ status: 'error', code: 'INVALID_REFRESH_TOKEN' });
    }

    const result = await db.withServiceRole(async (client) => {
      const hash = hashOpaqueToken(presented);
      const found = await client.query(
        `SELECT id, user_id, family_id, expires_at, revoked_at
         FROM auth_refresh_sessions
         WHERE token_hash = $1
         FOR UPDATE`,
        [hash]
      );

      if (found.rows.length === 0) {
        const err = new Error('INVALID_REFRESH_TOKEN');
        err.code = 'INVALID_REFRESH_TOKEN';
        throw err;
      }

      const old = found.rows[0];

      if (old.revoked_at || new Date(old.expires_at) <= new Date()) {
        // Reuse of a rotated/revoked token invalidates the whole family.
        await client.query(
          `UPDATE auth_refresh_sessions
           SET revoked_at = COALESCE(revoked_at, now())
           WHERE family_id = $1 AND revoked_at IS NULL`,
          [old.family_id]
        );
        const err = new Error('REFRESH_TOKEN_REVOKED');
        err.code = 'REFRESH_TOKEN_REVOKED';
        throw err;
      }

      const nextRefresh = await createRefreshSession(client, old.user_id, old.family_id);

      await client.query(
        `UPDATE auth_refresh_sessions
         SET revoked_at = now(), replaced_by = $2
         WHERE id = $1`,
        [old.id, nextRefresh.sessionId]
      );

      return {
        accessToken: issueAccessToken(old.user_id),
        refreshToken: nextRefresh.token,
      };
    });

    res.json({ status: 'ok', ...result });
  } catch (err) {
    next(err);
  }
});

router.post('/logout', async (req, res, next) => {
  try {
    const presented = req.body.refreshToken;
    if (typeof presented === 'string') {
      await db.withServiceRole((client) =>
        client.query(
          `UPDATE auth_refresh_sessions
           SET revoked_at = COALESCE(revoked_at, now())
           WHERE token_hash = $1`,
          [hashOpaqueToken(presented)]
        )
      );
    }
    res.json({ status: 'ok' });
  } catch (err) {
    next(err);
  }
});

// CLOSURE FIX: password_reset_tokens (DDL), FRONTEND_RESET_URL/SMTP_*/nodemailer
// (.env.example, package.json) all existed with no route ever consuming them.
// This implements the reset lifecycle the spec's own auth contract requires:
// single-use token, short expiry, no user-existence leak, rate-limited by the
// caller's authLimiter (index.js mounts this whole router behind it).
const nodemailer = require('nodemailer');

const RESET_TOKEN_TTL_MINUTES = 30;

function createResetTransport() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD } : undefined,
  });
}

router.post('/request-reset', async (req, res, next) => {
  try {
    let email;
    try {
      email = normalizeEmail(req.body.email);
    } catch {
      // Invalid email shape: respond identically to "unknown email" below —
      // never let this endpoint confirm or deny whether an address is
      // registered or well-formed.
      return res.json({ status: 'ok' });
    }

    await db.withServiceRole(async (client) => {
      const found = await client.query('SELECT id FROM users WHERE email = $1', [email]);
      if (found.rows.length === 0) return; // no user-existence leak — respond ok either way

      const userId = found.rows[0].id;
      const token = createRefreshToken(); // reuse the same high-entropy opaque-token generator
      const hash = hashOpaqueToken(token);
      const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MINUTES * 60000);

      await client.query(
        `INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES ($1,$2,$3)`,
        [userId, hash, expiresAt]
      );

      const resetUrl = `${process.env.FRONTEND_RESET_URL}?token=${token}`;
      try {
        await createResetTransport().sendMail({
          from: process.env.SMTP_FROM,
          to: email,
          subject: 'Reset your iBag password',
          text: `Reset your password: ${resetUrl}\nThis link expires in ${RESET_TOKEN_TTL_MINUTES} minutes and can only be used once.`,
        });
      } catch (mailErr) {
        // Token is already persisted; a transient SMTP failure shouldn't leak
        // via a different HTTP response than the success case, and shouldn't
        // block the request — log server-side only.
        console.error(JSON.stringify({ type: 'password_reset_email_failed', message: String(mailErr.message || mailErr) }));
      }
    });

    res.json({ status: 'ok' });
  } catch (err) {
    next(err);
  }
});

router.post('/reset', async (req, res, next) => {
  try {
    const presented = req.body.token;
    const newPassword = req.body.password;
    if (typeof presented !== 'string' || presented.length < 32) {
      return res.status(400).json({ status: 'error', code: 'INVALID_RESET_TOKEN' });
    }
    assertPassword(newPassword);

    await db.withServiceRole(async (client) => {
      const hash = hashOpaqueToken(presented);
      const found = await client.query(
        `SELECT id, user_id, expires_at, consumed_at FROM password_reset_tokens
         WHERE token_hash = $1 FOR UPDATE`,
        [hash]
      );

      if (found.rows.length === 0) {
        const err = new Error('INVALID_RESET_TOKEN'); err.code = 'INVALID_RESET_TOKEN'; throw err;
      }
      const row = found.rows[0];
      if (row.consumed_at || new Date(row.expires_at) <= new Date()) {
        const err = new Error('RESET_TOKEN_EXPIRED_OR_USED'); err.code = 'RESET_TOKEN_EXPIRED_OR_USED'; throw err;
      }

      const passwordHash = await bcrypt.hash(newPassword, BCRYPT_COST);
      await client.query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, row.user_id]);
      // Single-use: mark consumed immediately so a replayed request fails.
      await client.query('UPDATE password_reset_tokens SET consumed_at = now() WHERE id = $1', [row.id]);
      // A password reset invalidates every existing session — the whole
      // point of a reset is "someone other than the legitimate owner may
      // have had access"; leaving old refresh sessions alive defeats that.
      await client.query(
        `UPDATE auth_refresh_sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL`,
        [row.user_id]
      );
    });

    res.json({ status: 'ok' });
  } catch (err) {
    next(err);
  }
});

module.exports = { router, authMiddleware };
