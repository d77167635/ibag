const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { verifyPlaidWebhook } = require('../webhooks/plaidWebhookVerify');
const db = require('../db');

// Mount with express.raw({ type: 'application/json' }) on this route specifically â€”
// do NOT let a global express.json() middleware parse this body first, or the raw
// bytes needed for hash verification are gone.
router.post('/', async (req, res) => {
  const rawBody = req.body; // Buffer, thanks to express.raw()
  const verificationHeader = req.headers['plaid-verification'];

  const result = await verifyPlaidWebhook(rawBody, verificationHeader);
  const bodySha256 = crypto.createHash('sha256').update(rawBody).digest('hex');

  // v4.2 fix: every write in this handler now runs inside withServiceRole()
  // (Section 8.3) so app.is_service_role is actually set on the connection.
  // Without it, RLS on plaid_webhook_events (Section 5.10) blocks every
  // INSERT below with no error surfaced to the caller other than a generic
  // DB failure â€” this was the "webhook pipeline can't boot" bug.
  if (!result.verified) {
    await db.withServiceRole((client) => client.query(
      `INSERT INTO plaid_webhook_events
         (idempotency_key, body_sha256, verification_status, raw_body)
       VALUES ($1, $2, $3, $4)`,
      [`rejected-${crypto.randomUUID()}`, bodySha256, `rejected_${result.reason.toLowerCase()}`, rawBody]
    ));
    return res.status(400).json({ status: 'error', code: result.reason });
  }

  const payload = result.payload;
  const idempotencyKey = payload.request_id || bodySha256;

  // v4.2 fix (Section 13.1.7): a separate SELECT-then-INSERT lets two
  // concurrent identical deliveries both pass the SELECT before either
  // commits, then race on the INSERT's UNIQUE constraint â€” which stops data
  // corruption but throws an unhandled DB error instead of deduplicating
  // gracefully. A single atomic INSERT ... ON CONFLICT DO NOTHING RETURNING
  // id makes "did I win the race" a single round-trip with no gap to race in.
  const inserted = await db.withServiceRole((client) => client.query(
    `INSERT INTO plaid_webhook_events
       (idempotency_key, item_id, webhook_type, webhook_code, request_id,
        body_sha256, raw_body, verification_status)
     VALUES ($1, $2, $3, $4, $5, $6, $7, 'verified')
     ON CONFLICT (idempotency_key) DO NOTHING
     RETURNING id`,
    [idempotencyKey, payload.item_id, payload.webhook_type, payload.webhook_code,
     payload.request_id, bodySha256, rawBody]
  ));

  if (inserted.rows.length === 0) {
    // No row returned means this idempotency_key already exists â€” another
    // delivery (possibly concurrent) already owns processing. Ack without
    // reprocessing or dispatching a second sync.
    return res.status(200).json({ status: 'ok', deduplicated: true });
  }

  // Persist only. The durable worker owns processing and retries.
  // HTTP 200 means "event durably accepted", not "sync completed".
  res.status(200).json({ status: 'ok', accepted: true });
});

module.exports = router;
