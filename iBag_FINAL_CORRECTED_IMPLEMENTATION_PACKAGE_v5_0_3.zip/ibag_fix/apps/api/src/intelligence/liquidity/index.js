async function computeLiquiditySignal(client, userId) {
  const balance = await client.query(
    `SELECT COALESCE(SUM(current_balance_cents), 0) AS total FROM accounts
     WHERE user_id = $1 AND type = 'depository'`,
    [userId]
  );
  const upcomingBills = await client.query(
    `SELECT COALESCE(SUM(average_amount_cents), 0) AS total FROM recurring_streams
     WHERE user_id = $1 AND stream_type = 'bill'
       AND next_expected_date <= (CURRENT_DATE + INTERVAL '30 days')`,
    [userId]
  );

  const liquidCents = Number(balance.rows[0].total);
  const upcomingCents = Number(upcomingBills.rows[0].total);
  const bufferCents = liquidCents - upcomingCents;

  await client.query(
    `INSERT INTO financial_health_signals (user_id, signal_type, value, evidence_state, calculation_version)
     VALUES ($1, 'liquidity_buffer_30d', $2, 'calculated', 'liquidity_v1')
     ON CONFLICT (user_id, signal_type, calculation_version)
     DO UPDATE SET value = $2, computed_at = now()`,
    [userId, bufferCents]
  );

  return { liquidCents, upcomingCents, bufferCents };
}

// v4.3 addition: fees were named in the Section 9.5 prose ("only counted
// when a real transaction is classified FEE") but had no corresponding code
// in v4.2. This sums actual FEE-classified transactions over the given
// period â€” never a published/estimated fee schedule, per that same rule.
async function computeFeeSignal(client, userId, periodStart, periodEnd) {
  const { rows } = await client.query(
    `SELECT COALESCE(SUM(t.amount_cents), 0) AS total
     FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE t.user_id = $1 AND tc.classification = 'FEE' AND t.removed_at IS NULL
       AND t.posted_date BETWEEN $2 AND $3`,
    [userId, periodStart, periodEnd]
  );
  const feeCents = Number(rows[0].total);

  await client.query(
    `INSERT INTO financial_health_signals (user_id, signal_type, value, evidence_state, calculation_version)
     VALUES ($1, 'fees_30d', $2, 'observed', 'fee_v1')
     ON CONFLICT (user_id, signal_type, calculation_version)
     DO UPDATE SET value = $2, computed_at = now()`,
    [userId, feeCents]
  );

  return { feeCents };
}

module.exports = { computeLiquiditySignal, computeFeeSignal };
