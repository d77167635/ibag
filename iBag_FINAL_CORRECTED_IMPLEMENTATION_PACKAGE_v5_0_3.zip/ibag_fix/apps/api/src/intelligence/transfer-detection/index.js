const TEMPORAL_TOLERANCE_DAYS = 3;

async function detectTransferPair(client, userId, transaction) {
  const { rows } = await client.query(
    `SELECT id FROM transactions
     WHERE user_id = $1 AND id != $2
       AND amount_cents = $3
       AND posted_date BETWEEN $4::date - $5::int AND $4::date + $5::int
       AND removed_at IS NULL`,
    [userId, transaction.id, -transaction.amount_cents, transaction.posted_date, TEMPORAL_TOLERANCE_DAYS]
  );
  if (rows.length === 0) return null;

  const otherId = rows[0].id;
  // Canonical ordering per Section 5.5's CHECK constraint.
  const [a, b] = transaction.id < otherId ? [transaction.id, otherId] : [otherId, transaction.id];

  await client.query(
    `INSERT INTO transaction_relationships (transaction_id_a, transaction_id_b, relationship_type, confidence, detected_by)
     VALUES ($1, $2, 'transfer_pair', 0.75, 'amount_date_match_v1')
     ON CONFLICT (transaction_id_a, transaction_id_b, relationship_type) DO NOTHING`,
    [a, b]
  );
  return { transactionIdA: a, transactionIdB: b };
}

module.exports = { detectTransferPair };
