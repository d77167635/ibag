const CALC_VERSION = 'net_worth_v1';

async function computeNetWorthSnapshot(client, userId, asOfDate) {
  const depository = await client.query(
    `SELECT COALESCE(SUM(current_balance_cents), 0) AS total FROM accounts
     WHERE user_id = $1 AND type = 'depository'`,
    [userId]
  );
  const investments = await client.query(
    `SELECT COALESCE(SUM(current_balance_cents), 0) AS total FROM accounts
     WHERE user_id = $1 AND type = 'investment'`,
    [userId]
  );
  const liabilities = await client.query(
    `SELECT COALESCE(SUM(current_balance_cents), 0) AS total FROM accounts
     WHERE user_id = $1 AND type IN ('credit','loan')`,
    [userId]
  );
  const capabilities = await client.query(
    `SELECT domain, last_successful_sync_at FROM provider_capabilities pc
     JOIN plaid_items pi ON pi.id = pc.plaid_item_id
     WHERE pi.user_id = $1`,
    [userId]
  );

  const missingDomains = capabilities.rows
    .filter((c) => !c.last_successful_sync_at)
    .map((c) => c.domain);
  const includedDomains = capabilities.rows
    .filter((c) => c.last_successful_sync_at)
    .map((c) => c.domain);

  const assets = Number(depository.rows[0].total) + Number(investments.rows[0].total);
  const liabilitiesTotal = Number(liabilities.rows[0].total);
  const netWorth = assets - liabilitiesTotal;
  const evidenceState = missingDomains.length > 0 ? 'limited' : 'calculated';

  await client.query(
    `INSERT INTO net_worth_snapshots
       (user_id, as_of_date, assets_cents, liabilities_cents, net_worth_cents,
        included_domains, missing_domains, evidence_state, calculation_version)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (user_id, as_of_date, calculation_version)
     DO UPDATE SET assets_cents=$3, liabilities_cents=$4, net_worth_cents=$5,
       included_domains=$6, missing_domains=$7, evidence_state=$8, computed_at=now()`,
    [userId, asOfDate, assets, liabilitiesTotal, netWorth,
     includedDomains, missingDomains, evidenceState, CALC_VERSION]
  );

  return { assets, liabilities: liabilitiesTotal, netWorth, evidenceState, missingDomains };
}

module.exports = { computeNetWorthSnapshot, CALC_VERSION };
