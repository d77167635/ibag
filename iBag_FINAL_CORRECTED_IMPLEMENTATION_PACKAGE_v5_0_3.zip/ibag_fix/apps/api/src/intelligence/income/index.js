const CALC_VERSION = 'income_v1';

function classifyCadence(gapDays) {
  if (gapDays >= 5 && gapDays <= 9) return 'weekly';
  if (gapDays >= 11 && gapDays <= 17) return 'biweekly';
  if (gapDays >= 25 && gapDays <= 35) return 'monthly';
  return 'irregular';
}

function amountVarianceOk(amounts) {
  const mean = amounts.reduce((a, b) => a + b, 0) / amounts.length;
  if (mean === 0) return false;
  return amounts.every((a) => Math.abs(a - mean) / mean < 0.15);
}

async function detectIncomeSignals(client, userId) {
  const { rows } = await client.query(
    `SELECT t.merchant_name AS merchant, t.amount_cents, t.posted_date
     FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE t.user_id = $1 AND t.amount_cents < 0
       AND tc.classification NOT IN ('TRANSFER_IN','TRANSFER_OUT')
       AND t.removed_at IS NULL
     ORDER BY t.merchant_name, t.posted_date ASC`,
    [userId]
  );

  const byMerchant = new Map();
  for (const row of rows) {
    const key = row.merchant || null;
    if (!byMerchant.has(key)) byMerchant.set(key, []);
    byMerchant.get(key).push(row);
  }

  const results = [];
  for (const [merchant, occurrences] of byMerchant) {
    if (occurrences.length < 2) continue;
    const gaps = [];
    for (let i = 1; i < occurrences.length; i++) {
      const days = (new Date(occurrences[i].posted_date) - new Date(occurrences[i - 1].posted_date)) / 86400000;
      gaps.push(days);
    }
    const avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
    const cadence = classifyCadence(avgGap);
    const amounts = occurrences.map((o) => Math.abs(Number(o.amount_cents)));
    const varianceOk = amountVarianceOk(amounts);
    if (cadence === 'irregular' || !varianceOk) continue;

    const last = occurrences[occurrences.length - 1];
    const cadenceDays = { weekly: 7, biweekly: 14, monthly: 30 }[cadence];
    const nextExpected = new Date(last.posted_date);
    nextExpected.setDate(nextExpected.getDate() + cadenceDays);
    const avgAmount = Math.round(amounts.reduce((a, b) => a + b, 0) / amounts.length);

    await client.query(
      `INSERT INTO income_signals
         (user_id, source_merchant, cadence, average_amount_cents, last_detected_date,
          next_expected_date, confidence, evidence_state, calculation_version)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'observed',$8)
       ON CONFLICT (user_id, source_merchant) WHERE source_merchant IS NOT NULL
       DO UPDATE SET cadence=$3, average_amount_cents=$4, last_detected_date=$5,
         next_expected_date=$6, confidence=$7, updated_at=now()`,
      [userId, merchant, cadence, avgAmount, last.posted_date,
       cadence === 'irregular' ? null : nextExpected.toISOString().slice(0, 10),
       Math.min(0.95, 0.5 + occurrences.length * 0.05), CALC_VERSION]
    );
    results.push({ merchant, cadence, avgAmount });
  }
  return results;
}

module.exports = { detectIncomeSignals, classifyCadence, amountVarianceOk, CALC_VERSION };
