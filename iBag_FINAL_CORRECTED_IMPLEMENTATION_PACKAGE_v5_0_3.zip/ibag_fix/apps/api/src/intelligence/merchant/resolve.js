async function resolveMerchantId(client, providerMerchantName) {
  if (!providerMerchantName) return null;
  const alias = await client.query(
    'SELECT merchant_id FROM merchant_aliases WHERE provider_merchant_name = $1',
    [providerMerchantName]
  );
  if (alias.rows.length) return alias.rows[0].merchant_id;
  const merchant = await client.query(
    `INSERT INTO merchants (canonical_name) VALUES ($1)
     ON CONFLICT (canonical_name) DO UPDATE SET canonical_name = merchants.canonical_name
     RETURNING id`,
    [providerMerchantName]
  );
  const id = merchant.rows[0].id;
  await client.query(
    `INSERT INTO merchant_aliases (merchant_id, provider_merchant_name)
     VALUES ($1,$2) ON CONFLICT (provider_merchant_name) DO NOTHING`,
    [id, providerMerchantName]
  );
  return id;
}
module.exports = { resolveMerchantId };
