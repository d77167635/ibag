const CALC_VERSION = 'cash_flow_v1';

async function computeCashFlowPeriod(client, userId, periodStart, periodEnd) {
  const { rows } = await client.query(
    `SELECT tc.classification, SUM(t.amount_cents) AS total
     FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE t.user_id = $1 AND t.posted_date BETWEEN $2 AND $3 AND t.removed_at IS NULL
     GROUP BY tc.classification`,
    [userId, periodStart, periodEnd]
  );

  const totals = Object.fromEntries(rows.map((r) => [r.classification, Number(r.total)]));
  const income = totals.INCOME || 0;
  const spending = totals.PURCHASE || 0;
  const transfers = (totals.TRANSFER_IN || 0) + (totals.TRANSFER_OUT || 0);
  const fees = totals.FEE || 0;

  await client.query(
    `INSERT INTO cash_flow_periods
       (user_id, period_start, period_end, income_cents, spending_cents, transfer_cents, fee_cents, calculation_version)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     ON CONFLICT (user_id, period_start, period_end, calculation_version)
     DO UPDATE SET income_cents = $4, spending_cents = $5, transfer_cents = $6, fee_cents = $7, computed_at = now()`,
    [userId, periodStart, periodEnd, income, spending, transfers, fees, CALC_VERSION]
  );

  return { income, spending, transfers, fees };
}

module.exports = { computeCashFlowPeriod, CALC_VERSION };
