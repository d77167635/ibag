const { classifyCadence, amountVarianceOk } = require('../income');
const { resolveMerchantId } = require('../merchant/resolve');

const CALC_VERSION = 'recurring_v1';

function inferStreamType(personalFinanceCategory) {
  if (!personalFinanceCategory) return 'other';
  const cat = personalFinanceCategory.toLowerCase();
  if (cat.includes('subscription')) return 'subscription';
  if (cat.includes('bill') || cat.includes('utilit') || cat.includes('rent') || cat.includes('loan')) return 'bill';
  return 'other';
}

async function detectRecurringStreams(client, userId) {
  const { rows } = await client.query(
    `SELECT t.merchant_name, t.amount_cents, t.posted_date, t.provider_category
     FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE t.user_id = $1 AND t.removed_at IS NULL
       AND tc.classification NOT IN ('TRANSFER_IN', 'TRANSFER_OUT', 'INCOME', 'PENDING_INCOME_REVIEW')
     ORDER BY t.merchant_name, t.posted_date ASC`,
    [userId]
  );

  const byMerchant = new Map();
  for (const row of rows) {
    if (!row.merchant_name) continue; // recurring_streams.merchant_id can't be resolved for an unnamed merchant â€” excluded, not guessed
    if (!byMerchant.has(row.merchant_name)) byMerchant.set(row.merchant_name, []);
    byMerchant.get(row.merchant_name).push(row);
  }

  const results = [];
  for (const [merchantName, occurrences] of byMerchant) {
    if (occurrences.length < 2) continue;
    const gaps = [];
    for (let i = 1; i < occurrences.length; i++) {
      const days = (new Date(occurrences[i].posted_date) - new Date(occurrences[i - 1].posted_date)) / 86400000;
      gaps.push(days);
    }
    const avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
    const cadence = classifyCadence(avgGap);
    const amounts = occurrences.map((o) => Math.abs(Number(o.amount_cents)));
    if (cadence === 'irregular' || !amountVarianceOk(amounts)) continue;

    const merchantId = await resolveMerchantId(client, merchantName);
    const last = occurrences[occurrences.length - 1];
    const cadenceDays = { weekly: 7, biweekly: 14, monthly: 30 }[cadence];
    const nextExpected = new Date(last.posted_date);
    nextExpected.setDate(nextExpected.getDate() + cadenceDays);
    const avgAmount = Math.round(amounts.reduce((a, b) => a + b, 0) / amounts.length);
    const variance = Math.round(Math.sqrt(amounts.reduce((s, a) => s + (a - avgAmount) ** 2, 0) / amounts.length));
    const streamType = inferStreamType(last.provider_category);

    await client.query(
      `INSERT INTO recurring_streams
         (user_id, merchant_id, stream_type, cadence, average_amount_cents, amount_variance_cents,
          last_observed_date, next_expected_date, confidence, calculation_version)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       ON CONFLICT (user_id, merchant_id, stream_type) DO UPDATE SET
         cadence = $4, average_amount_cents = $5, amount_variance_cents = $6,
         last_observed_date = $7, next_expected_date = $8, confidence = $9, updated_at = now()`,
      [userId, merchantId, streamType, cadence, avgAmount, variance,
       last.posted_date, nextExpected.toISOString().slice(0, 10),
       Math.min(0.95, 0.5 + occurrences.length * 0.05), CALC_VERSION]
    );
    results.push({ merchantId, streamType, cadence, avgAmount });
  }
  return results;
}

module.exports = { detectRecurringStreams, inferStreamType, CALC_VERSION };
