// CLOSURE FIX (#5): this process did not exist in the shipped package.
// webhookWorker.processWebhookEvents, reconciliation.reconcileRoundupAccumulators,
// incomeReview.runIncomeReviewForAllPendingUsers, roundup/rules.closeBatch, and
// every intelligence engine (cash-flow, net-worth, liquidity/fees, recurring)
// were all fully implemented as callable functions but nothing in the package
// ever called them. This is a second OS process (run via `npm run worker`,
// separate from the API process started by `npm start`) whose only job is to
// call them on a schedule.
//
// This is a minimum-viable poll loop, not a production task queue. It is
// intentionally simple (setInterval, in-process, single instance) so its
// behavior is easy to audit. Before PRODUCTION_VALIDATED, evaluate whether a
// real job scheduler (e.g. a managed cron trigger calling these same
// functions, or pg-boss/BullMQ) is needed for your deployment's concurrency
// and reliability requirements — running more than one instance of this file
// unchanged will still be correct (every write path here is already
// idempotent/advisory-locked per Section 29.24), just redundant.

require('dotenv').config();

const db = require('./db');
const { processWebhookEvents } = require('./jobs/webhookWorker');
const { reconcileRoundupAccumulators } = require('./jobs/reconciliation');
const { runIncomeReviewForAllPendingUsers } = require('./jobs/incomeReview');
const { closeBatch } = require('./roundup/rules');
const { computeNetWorthSnapshot } = require('./intelligence/net-worth');
const { computeCashFlowPeriod } = require('./intelligence/cash-flow');
const { computeLiquiditySignal, computeFeeSignal } = require('./intelligence/liquidity');
const { detectRecurringStreams } = require('./intelligence/recurring');

const WEBHOOK_POLL_MS = Number(process.env.WORKER_WEBHOOK_POLL_MS || 5000);
const INCOME_REVIEW_POLL_MS = Number(process.env.WORKER_INCOME_REVIEW_POLL_MS || 60000);
const RECONCILIATION_POLL_MS = Number(process.env.WORKER_RECONCILIATION_POLL_MS || 3600000); // hourly
const INTELLIGENCE_POLL_MS = Number(process.env.WORKER_INTELLIGENCE_POLL_MS || 3600000); // hourly
const BATCH_SETTLEMENT_POLL_MS = Number(process.env.WORKER_BATCH_SETTLEMENT_POLL_MS || 86400000); // daily

function logTick(name, extra) {
  console.log(JSON.stringify({ type: 'worker_tick', job: name, at: new Date().toISOString(), ...extra }));
}
function logError(name, err) {
  console.error(JSON.stringify({ type: 'worker_error', job: name, message: String(err && err.message || err) }));
}

async function tickWebhooks() {
  try {
    const processed = await processWebhookEvents(25);
    if (processed > 0) logTick('webhooks', { processed });
  } catch (err) { logError('webhooks', err); }
}

async function tickIncomeReview() {
  try {
    const results = await runIncomeReviewForAllPendingUsers();
    if (results.length > 0) logTick('income_review', { usersReviewed: results.length });
  } catch (err) { logError('income_review', err); }
}

async function tickReconciliation() {
  try {
    const result = await reconcileRoundupAccumulators();
    logTick('reconciliation', result);
    if (result.mismatches > 0) {
      console.error(JSON.stringify({ type: 'reconciliation_mismatch', mismatches: result.mismatches }));
    }
  } catch (err) { logError('reconciliation', err); }
}

// Every table this worker recomputes per-user is user-owned and RLS-gated on
// app.current_user_id, so "which users exist" itself has to be answered from
// the service-role connection — same class of fix as incomeReview's.
async function listActiveUserIds() {
  const { rows } = await db.withServiceRole((client) => client.query(
    `SELECT DISTINCT user_id FROM accounts WHERE status = 'active'`
  ));
  return rows.map((r) => r.user_id);
}

async function tickIntelligence() {
  let userIds;
  try {
    userIds = await listActiveUserIds();
  } catch (err) { logError('intelligence_user_list', err); return; }

  const today = new Date().toISOString().slice(0, 10);
  const periodStart = new Date();
  periodStart.setDate(1);
  const periodStartStr = periodStart.toISOString().slice(0, 10);

  let ok = 0, failed = 0;
  for (const userId of userIds) {
    try {
      await db.withUserContext(userId, async (client) => {
        await detectRecurringStreams(client, userId);
        await computeLiquiditySignal(client, userId);
        await computeFeeSignal(client, userId, periodStartStr, today);
        await computeNetWorthSnapshot(client, userId, today);
        await computeCashFlowPeriod(client, userId, periodStartStr, today);
      });
      ok++;
    } catch (err) {
      failed++;
      logError('intelligence_user', Object.assign(new Error(`${userId}: ${err.message}`), err));
    }
  }
  logTick('intelligence', { usersProcessed: ok, usersFailed: failed });
}

async function tickBatchSettlement() {
  try {
    const { rows: accumulators } = await db.withServiceRole((client) => client.query(
      `SELECT id FROM roundup_accumulators`
    ));
    let closed = 0;
    await db.withServiceRole(async (client) => {
      for (const acc of accumulators) {
        const result = await closeBatch(client, acc.id);
        if (result) closed++;
      }
    });
    logTick('batch_settlement', { accumulatorsChecked: accumulators.length, batchesClosed: closed });
  } catch (err) { logError('batch_settlement', err); }
}

function main() {
  console.log(JSON.stringify({ type: 'worker_start', at: new Date().toISOString() }));

  setInterval(tickWebhooks, WEBHOOK_POLL_MS);
  setInterval(tickIncomeReview, INCOME_REVIEW_POLL_MS);
  setInterval(tickReconciliation, RECONCILIATION_POLL_MS);
  setInterval(tickIntelligence, INTELLIGENCE_POLL_MS);
  setInterval(tickBatchSettlement, BATCH_SETTLEMENT_POLL_MS);

  // Run one pass of each immediately on startup rather than waiting a full
  // interval, so a freshly deployed worker doesn't sit idle.
  tickWebhooks();
  tickIncomeReview();
  tickReconciliation();
  tickIntelligence();
  tickBatchSettlement();
}

process.on('SIGTERM', () => { console.log('worker: SIGTERM received, exiting'); process.exit(0); });
process.on('SIGINT', () => { console.log('worker: SIGINT received, exiting'); process.exit(0); });

main();
