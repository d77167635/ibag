const db = require('../db');
const { runSync } = require('./sync');

async function processWebhookEvents(limit = 25) {
  return db.withServiceRole(async (client) => {
    const { rows } = await client.query(`
      SELECT id, item_id
      FROM plaid_webhook_events
      WHERE processing_status IN ('received','failed')
        AND (next_attempt_at IS NULL OR next_attempt_at <= now())
        AND attempt_count < max_attempts
      ORDER BY received_at
      FOR UPDATE SKIP LOCKED
      LIMIT $1
    `, [limit]);

    for (const event of rows) {
      await client.query(`
        UPDATE plaid_webhook_events
        SET processing_status = 'processing',
            attempt_count = attempt_count + 1,
            last_attempt_at = now()
        WHERE id = $1
      `, [event.id]);

      try {
        await runSync({ itemId: event.item_id, trigger: 'webhook' });
        await client.query(`
          UPDATE plaid_webhook_events
          SET processing_status = 'processed', processed_at = now()
          WHERE id = $1
        `, [event.id]);
      } catch (err) {
        await client.query(`
          UPDATE plaid_webhook_events
          SET processing_status =
                CASE WHEN attempt_count >= max_attempts
                     THEN 'dead_letter' ELSE 'failed' END,
              processing_error = $2,
              next_attempt_at =
                CASE WHEN attempt_count >= max_attempts
                     THEN NULL
                     ELSE now() + LEAST(interval '1 hour',
                                        (interval '1 minute' * power(2, attempt_count)))
                END
          WHERE id = $1
        `, [event.id, String(err.message || err)]);
      }
    }

    return rows.length;
  });
}

module.exports = { processWebhookEvents };
