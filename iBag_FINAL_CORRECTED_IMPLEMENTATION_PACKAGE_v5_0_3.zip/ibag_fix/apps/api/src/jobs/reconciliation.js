const db = require('../db');

// Writes to reconciliation_runs (Section 5.9), which is service-role-gated
// (Section 5.10) â€” must run under withServiceRole, per the same RLS fix as 8.5.
async function reconcileRoundupAccumulators() {
  return db.withServiceRole(async (client) => {
    const { rows: accumulators } = await client.query('SELECT id, account_id, total_cents FROM roundup_accumulators');
    let mismatches = 0;

    for (const acc of accumulators) {
      const expected = await client.query(
        `SELECT COALESCE(SUM(re.roundup_cents), 0) AS total
         FROM roundup_events re WHERE re.transaction_id IN (
           SELECT id FROM transactions WHERE account_id = $1
         ) AND re.eligibility_status = 'eligible'`,
        [acc.account_id]
      );
      const expectedCents = Number(expected.rows[0].total);
      const status = expectedCents === Number(acc.total_cents) ? 'ok' : 'mismatch';
      if (status === 'mismatch') mismatches++;

      await client.query(
        `INSERT INTO reconciliation_runs (scope, status, expected_value_cents, actual_value_cents, details)
         VALUES ('roundup_accumulator', $1, $2, $3, $4)`,
        [status, expectedCents, acc.total_cents, JSON.stringify({ accountId: acc.account_id })]
      );
    }
    return { checked: accumulators.length, mismatches };
  });
}

module.exports = { reconcileRoundupAccumulators };
