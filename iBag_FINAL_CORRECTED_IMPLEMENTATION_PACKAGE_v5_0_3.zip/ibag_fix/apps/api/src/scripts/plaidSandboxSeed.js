if (process.env.NODE_ENV === 'production' || process.env.PLAID_ENV !== 'sandbox') {
  console.error('FATAL: this script may only run with NODE_ENV != production and PLAID_ENV=sandbox.');
  process.exit(1);
}
if (!process.env.DATABASE_URL || !process.env.DATABASE_URL.includes('sandbox')) {
  console.error('FATAL: DATABASE_URL does not contain an explicit "sandbox" marker. Refusing to run.');
  process.exit(1);
}
