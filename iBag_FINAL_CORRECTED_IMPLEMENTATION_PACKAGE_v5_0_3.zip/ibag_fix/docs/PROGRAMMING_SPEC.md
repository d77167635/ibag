`````
````
# iBag â€” Complete System Specification (Developer Edition)
## Relational Financial Intelligence Operating System, Round-Ups as Entry Wedge

**Version:** 4.4 (Full Replacement â€” Exhaustively Corrected / Developer-Executable Specification)
**Date:** 2026-08-18
**Supersedes:** v1, v2, v3, v4.0, v4.1, v4.2, v4.3. This is the single build contract.
**Starting state:** Empty repository, empty Supabase project, no legacy schema, no legacy Plaid Items.
**What changed from v4.1:** v4.1's Section 13.1 listed MUST-fix items but the actual DDL/code sections it described were never edited to apply them â€” the document contradicted itself. v4.2 applied every fix directly into the numbered sections (5, 8, 9) that the code will actually be copied from, and filled in the previously-named-but-bodiless files (`sync.js`, the Plaid adapter, `me.js`, `link.js`, `reconciliation.js`, and the Section 9 intelligence functions).
**What changed from v4.2:** A second audit pass of v4.2's own delivered code (not just its prose) found five real gaps between what the changelog claimed and what the code actually did â€” `account_type` was never fetched so three classification rules were dead code; the two-pass income classification described in prose had no corresponding `PENDING_INCOME_REVIEW` status anywhere in the code; a modified transaction's changed amount never updated its existing Round-Up event; Sections 9.3 and 9.5 were partly prose-only; and `merchants`/`merchant_aliases` were defined but never populated. This version fixes all five directly in code, and two more found while fixing them: `applyRoundupCorrection` wasn't keeping the `roundup_events` row itself consistent with the correction (so reconciliation would flag corrected accounts as mismatched), and a naive fix for that would have written to a service-role-gated table from a user-context transaction, reproducing the exact class of RLS lockout bug fixed once already in v4.2 (13.1.15). See the new Section 13.3 changelog for the complete list, including what is honestly still not resolved.

---


## 0.3 v4.4 corrective audit standard

v4.4 is the final pre-implementation contract produced from the v4.3 artifact. It does not treat the v4.3 changelog as evidence that a fix exists. A behavior is considered closed only when the database invariant, runtime code contract, caller, failure path, and test requirement all agree.

The v4.4 audit found and closes the following additional classes of defects that were not fully closed by v4.3:

1. **Runtime lifecycle gaps:** the API entrypoint, route mounting, JSON/raw-body middleware ordering, CORS middleware, rate-limit middleware, durable webhook retry worker, and authentication route surface were named or implied but not completely executable.
2. **Authentication lifecycle gaps:** v4.3 still lacked refresh-token rotation, logout/revocation, password-reset token storage and invalidation, optional email verification policy, JWT algorithm pinning, and account/email normalization.
3. **RLS/integrity gaps:** `app_role` was referenced but never created; several policies allowed cross-user foreign-key combinations because they checked only the child `user_id` or only one side of a relationship; service-role semantics were application-GUC based rather than backed by a distinct database credential.
4. **Schema/retention contradiction:** `source_observations.raw_payload` was `NOT NULL` while the stated retention policy required it to be nulled after 24 months.
5. **Currency correctness:** USD-only calculation scope was undermined by defaulting missing Plaid currency codes to USD. Unknown/non-USD currency must never silently enter USD calculations.
6. **Plaid account lifecycle:** accounts and balances were only synchronized during Link exchange. Account additions, closures, balance changes, and post-Link account changes therefore were not fully represented.
7. **Plaid product lifecycle:** liabilities, investments, and identity adapters existed but were not fully invoked, persisted, reconciled, or reflected in capability timestamps.
8. **Pending/posted lineage:** Plaid explicitly represents a pending-to-posted transition as a removed pending transaction plus an added posted transaction, with `pending_transaction_id` linking them when matched. v4.4 makes the Round-Up event follow that economic transaction rather than creating a second independent event.
9. **Removed transaction handling:** removing a posted transaction previously left its existing Round-Up event and accumulator contribution active. v4.4 reverses the live contribution while preserving immutable closed-batch history.
10. **Round-Up correction completeness:** corrections must update `source_amount_cents`, eligibility fields, current event value, accumulator delta, and any still-open batch snapshot atomically.
11. **Batch integrity:** batch creation could race, and line items referenced mutable event values. v4.4 makes open-batch selection race-safe and stores the Round-Up amount as a line-item snapshot so closed batches remain immutable.
12. **Transfer detection:** same-account false matches and ordering-dependent detection were possible. v4.4 requires different accounts and performs a second classification/reconciliation pass after all transactions in a sync page-set are present.
13. **Refund detection:** `priorPurchaseMatch` was effectively disabled. v4.4 implements deterministic same-merchant inverse-amount matching with conservative evidence.
14. **Income false positives:** income-signal construction must not learn from refunds, fees, transfers, loan payments, investment activity, or unrelated unknown negatives. v4.4 limits the candidate population to unresolved income candidates.
15. **Merchant resolution:** merchant tables must be populated and normalized before recurring intelligence uses them. v4.4 adds deterministic normalization and alias persistence.
16. **Intelligence orchestration:** individual intelligence modules existed without a complete authoritative post-sync orchestration contract. v4.4 defines the order and transaction boundary for recomputation.
17. **Dashboard contract:** v4.3 did not contain the complete `/me/dashboard` read model required by the product contract. v4.4 restores it as a read-only projection over authoritative stored intelligence and Round-Up events.
18. **Net-worth source correctness:** investment account `current` balance is itself the institution-presented total value of investment assets. Holdings must not be added to that account balance. v4.4 uses the investment account balance as the net-worth total and holdings as composition/detail, eliminating both double counting and silent cash omission.
19. **Plaid initialization semantics:** current Plaid guidance distinguishes `products`, `required_if_supported_products`, `optional_products`, and `additional_consented_products`. v4.4 uses the personal-finance pattern appropriate to this architecture: Transactions required; Identity required-if-supported; Liabilities and Investments additionally consented, with endpoint use determining actual observation.
20. **Runtime support:** Node 20 is EOL as of March 24, 2026. v4.4 targets Node 24 LTS rather than an EOL Node 20 floor.
21. **Dependency pinning:** caret ranges were not actually pinned. v4.4 requires exact direct dependency versions plus a committed lockfile.
22. **Migration bootability:** `gen_random_uuid()` requires the required extension, and every role referenced by GRANT/REVOKE/policy setup must exist before the migration runs.
23. **Reconciliation coverage:** Round-Up reconciliation must include current events, removed transactions, accumulator totals, open/closed batch snapshots, event counts, duplicate economic lineage, and category/merchant rollups rather than one accumulator sum only.
24. **Failure/retry semantics:** webhook acknowledgement must not imply successful downstream processing. v4.4 persists the event first and processes it through a durable retryable worker.
25. **Concurrency:** per-Item syncs are serialized with a PostgreSQL advisory lock so two simultaneous webhook deliveries cannot race the same cursor or apply the same correction twice.
26. **Provider lineage:** raw provider observations are actually written, hashed, retained, and tied to the provider request/item/entity where available.
27. **No silent defaults:** missing Plaid fields remain `NULL` unless the provider contract explicitly guarantees a value. Defaults that could manufacture financial facts are prohibited.

### v4.4 precedence rule

Where an earlier v4.3 paragraph conflicts with an explicit v4.4 correction in Sections 14â€“18, the v4.4 correction is authoritative. No v4.3 behavior may be implemented where it contradicts the v4.4 invariants below.

---

# 0. STATUS AND SCOPE

This document is specified to the level a developer can implement from directly. v4.4 also closes the cross-section integrity, security, lifecycle, Plaid-state, and runtime gaps identified by the exhaustive v4.3 audit: real DDL, real RLS policies (every table, not a sample), real JavaScript for the security-critical modules, resolved defaults for every open product decision, pinned dependency versions, and literal Sandbox commands.

It is honestly labeled, not oversold: this is `SPECIFIED`, not `IMPLEMENTED`. No claim here means a file exists in your repo yet. The certification ladder from prior versions still applies:

```
SPECIFIED -> IMPLEMENTED -> REPO_AUDITED -> STAGING_VALIDATED -> CANARY_VALIDATED -> PRODUCTION_VALIDATED
```

## 0.1 Decisions closed in this version (previously open â€” now resolved with a stated default)

| Decision | Resolution | How to change it |
|---|---|---|
| Round-Up ceiling | `ROUNDUP_MAX_ELIGIBLE_CENTS = 80000` ($800.00) | Single named constant in `roundup/rules.js` â€” change one line, no other code touches it |
| Currency scope | **USD only for Phase 1.** No conversion logic is built. `iso_currency_code` is stored for lineage/future-proofing but every calculation assumes USD | Multi-currency is out of scope until a second currency is an actual product requirement â€” building conversion logic now would be speculative |
| Link product tiers | `transactions` in `products` (required); `liabilities`, `investments`, `identity` in `optional_products` | Confirm actual per-product billing with your Plaid account rep before enabling `optional_products` in Production â€” Sandbox has no billing implications either way |
| Auth authority | Custom JWT + bcrypt (already built), not Supabase Auth | Documented as the final answer, not a placeholder â€” see Section 5.2/8.1 |
| Provider scope | Single provider (Plaid). Adapter boundary exists (Section 4) so a second provider is addable later, but no multi-provider conflict resolution is built now | Add if/when a second provider is actually integrated |
| Node/runtime | Node `24.x LTS` (current production LTS line; enables native `require(esm)`, needed for `jose` v6 â€” see Section 8.3) | Render's available Node versions should be checked at deploy time against this floor |

## 0.2 Verified external facts this document relies on

Independently confirmed, not carried over from an earlier document's claim:

1. Plaid's webhook JWT uses **ES256** exclusively; reject any other `alg`.
2. Verification key: **POST** `/webhook_verification_key/get` with `client_id`, `secret`, `key_id` (the `kid` from the JWT header) â€” response nests the JWK under `key`.
3. JWT payload includes `iat` (5-minute max age) and `request_body_sha256` (constant-time compare against a hash of the raw body).
4. `/transactions/sync` is cursor-based (`added`/`modified`/`removed`, `has_more` pagination).
5. `balance` is never placed in Link's `products` array.
6. Sandbox default credentials: `user_good` / `pass_good`. Realistic evolving data: `user_transactions_dynamic` (any password). Custom fixtures: `test_username=user_custom` with a JSON `override_password`. Reliable non-OAuth test institution: **First Platypus Bank**, `ins_109508`.
7. `plaid` npm package current major is **45.x** (verified at spec time â€” re-check `npm view plaid version` before pinning, since Plaid ships monthly).
8. `jose` npm package current major is **6.x**, and current versions support `require('jose')` directly in CommonJS **when running on Node `^20.19.0 || ^22.12.0 || >=23.0.0`**, because those Node versions implement `require(esm)` natively. On an older Node runtime, `require('jose')` on v6+ will still throw `ERR_REQUIRE_ESM` â€” either upgrade Node or pin `jose@^4` (last fully-CJS-native major).

Re-verify facts 6â€“8 close to actual implementation time; they're the most likely to have shifted between spec-writing and coding.

---

# 1. PRODUCT DEFINITION (unchanged from v3, restated for completeness)

iBag is a relational financial intelligence operating system. Round-Ups are the entry wedge â€” first thing a user sees, reason to connect an account â€” not the product. Phase 1 is strictly read-only: no ACH, RTP, FedNow, card movement, transfers, withdrawals, trades, or deposits. A Round-Up amount is a calculated opportunity, never a money movement.

---

# 2. EVIDENCE CONTRACT

```
observed | calculated | inferred | limited | insufficient_evidence
```

`0` never means unknown/unavailable â€” that's `null` + an evidence state, always:

```json
{ "income": null, "evidence_state": "insufficient_evidence" }   // not observed yet
{ "income": 0, "evidence_state": "observed" }                    // a real zero
```

```typescript
type EvidenceEnvelope = {
  evidenceState: "observed" | "calculated" | "inferred" | "limited" | "insufficient_evidence";
  calculationVersion: string;
  observationWindow: { start: string; end: string } | null;
  confidence: number | null;   // only meaningful for "inferred"
  limitations: string[];
  sourceCount: number;
  computedAt: string;
  sourceLastUpdatedAt: string | null;
  freshness: "fresh" | "aging" | "stale" | "unknown";
};
```

---

# 3. PIPELINE

```
Plaid -> raw source observation -> canonical record -> classification
      -> deterministic calculation -> intelligence engines -> reconciliation
      -> authoritative read model -> frontend (format only, never recalculates)
```

---

# 4. PROVIDER ADAPTER (single provider, boundary kept for future extensibility)

```
connectItem(publicToken) -> { itemId, accessTokenEncrypted, institutionId, institutionName }
syncAccounts(itemId) -> Account[]
syncTransactions(itemId, cursor) -> { added, modified, removed, nextCursor, hasMore }
syncLiabilities(itemId) -> LiabilityRecord[]
syncInvestments(itemId) -> { holdings, investmentTransactions }
syncIdentity(itemId) -> IdentityRecord
verifyWebhook(rawBody, plaidVerificationHeader) -> { verified, payload, reason }
```
Nothing above `syncTransactions()` in the pipeline imports the Plaid SDK. Provider failure test before shipping any capability: *can the canonical model still represent the user's state if this provider disappears tomorrow?*

---

# 5. DATABASE SCHEMA â€” COMPLETE DDL

## 5.1 Rules

Money = `BIGINT` cents, no exceptions. Idempotent events get real `UNIQUE` constraints. Plaid IDs are `TEXT`. Internal IDs are `UUID`. Rates/quantities use `NUMERIC`.

## 5.2 Identity (custom auth â€” final, per 0.1)

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ibag_app') THEN
    CREATE ROLE ibag_app NOLOGIN NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ibag_service') THEN
    CREATE ROLE ibag_service NOLOGIN NOINHERIT BYPASSRLS;
  END IF;
END $$;

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 5.3 Provider connection layer

```sql
CREATE TABLE plaid_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plaid_item_id TEXT NOT NULL UNIQUE,
  plaid_access_token_encrypted TEXT NOT NULL,
  institution_id TEXT,
  institution_name TEXT,
  cursor TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  last_synced_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE provider_capabilities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plaid_item_id UUID NOT NULL REFERENCES plaid_items(id) ON DELETE CASCADE,
  domain TEXT NOT NULL,
  requested BOOLEAN NOT NULL DEFAULT false,
  consented BOOLEAN NOT NULL DEFAULT false,
  supported_by_institution BOOLEAN,
  last_successful_sync_at TIMESTAMPTZ,
  last_failed_sync_at TIMESTAMPTZ,
  last_error TEXT,
  UNIQUE (plaid_item_id, domain)
);

CREATE TABLE accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plaid_item_id UUID NOT NULL REFERENCES plaid_items(id) ON DELETE CASCADE,
  plaid_account_id TEXT NOT NULL UNIQUE,
  name TEXT,
  official_name TEXT,
  mask TEXT,
  type TEXT,
  subtype TEXT,
  current_balance_cents BIGINT,
  available_balance_cents BIGINT,
  balance_as_of TIMESTAMPTZ,
  iso_currency_code TEXT NOT NULL DEFAULT 'USD',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 5.4 Raw observation lineage

```sql
CREATE TABLE source_observations (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL DEFAULT 'plaid',
  provider_endpoint TEXT NOT NULL,
  provider_request_id TEXT,
  provider_item_id TEXT,
  provider_entity_id TEXT,
  payload_hash TEXT NOT NULL,
  raw_payload JSONB NOT NULL,
  schema_version TEXT NOT NULL,
  environment TEXT NOT NULL,
  retrieved_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_source_obs_entity ON source_observations (provider_entity_id);
```
**Retention default (resolved, not deferred):** raw payloads retained 24 months, then the `raw_payload` column is nulled (row kept for lineage/hash, payload dropped) by a scheduled job. Shorten this if legal/privacy review requires it â€” this is a default, not a requirement, but it's a concrete one so nothing blocks on "decide retention later."

## 5.5 Transactions and classification

```sql
CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  plaid_transaction_id TEXT NOT NULL UNIQUE,
  amount_cents BIGINT NOT NULL,               -- Plaid convention: positive = money out (debit)
  iso_currency_code TEXT NOT NULL DEFAULT 'USD',
  merchant_name TEXT,
  provider_category TEXT,
  pending BOOLEAN NOT NULL DEFAULT false,
  pending_transaction_id TEXT,
  authorized_date DATE,
  posted_date DATE,
  removed_at TIMESTAMPTZ,
  removal_reason TEXT,
  raw JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_transactions_user_date ON transactions (user_id, posted_date DESC);
CREATE INDEX idx_transactions_account ON transactions (account_id);
CREATE INDEX idx_transactions_pending_link ON transactions (pending_transaction_id);

CREATE TABLE transaction_classifications (
  id BIGSERIAL PRIMARY KEY,
  transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  classification TEXT NOT NULL,
  classification_version TEXT NOT NULL,
  confidence NUMERIC(4,3),
  evidence JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (transaction_id, classification_version)
);

CREATE TABLE merchants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  canonical_name TEXT NOT NULL UNIQUE
);

CREATE TABLE merchant_aliases (
  id BIGSERIAL PRIMARY KEY,
  merchant_id UUID NOT NULL REFERENCES merchants(id) ON DELETE CASCADE,
  provider_merchant_name TEXT NOT NULL UNIQUE
);

CREATE TABLE transaction_relationships (
  id BIGSERIAL PRIMARY KEY,
  transaction_id_a UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  transaction_id_b UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  relationship_type TEXT NOT NULL,
  confidence NUMERIC(4,3),
  detected_by TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- v4.2 fix: without this CHECK, (A,B) and (B,A) are distinct rows to Postgres,
  -- so the UNIQUE constraint below doesn't actually stop the same pair being
  -- inserted twice in opposite order. The canonical rule is: the lexicographically
  -- smaller UUID always goes in transaction_id_a. Enforce it at the DB level, not
  -- just by convention in application code, so a bug in the detector can't violate it.
  CONSTRAINT transaction_relationships_canonical_order CHECK (transaction_id_a < transaction_id_b),
  UNIQUE (transaction_id_a, transaction_id_b, relationship_type)
);
```
Application code (the transfer/relationship detector, Section 9.6) MUST sort the two transaction IDs before insert: `const [a, b] = id1 < id2 ? [id1, id2] : [id2, id1];`. Inserting with the pair in the wrong order will now fail the CHECK constraint at the database level rather than silently succeeding as a duplicate.

## 5.6 Round-Up engine

```sql
CREATE TABLE roundup_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  rule_version TEXT NOT NULL,
  source_amount_cents BIGINT NOT NULL,
  roundup_cents BIGINT NOT NULL,
  eligibility_status TEXT NOT NULL,
  eligibility_reason TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (transaction_id, rule_version)
);

CREATE TABLE roundup_corrections (
  id BIGSERIAL PRIMARY KEY,
  original_event_id UUID NOT NULL REFERENCES roundup_events(id),
  reason TEXT NOT NULL,
  old_roundup_cents BIGINT NOT NULL,
  new_roundup_cents BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE roundup_accumulators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  total_cents BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (account_id)
);

CREATE TABLE roundup_batches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  accumulator_id UUID NOT NULL REFERENCES roundup_accumulators(id),
  total_cents BIGINT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at TIMESTAMPTZ
);

CREATE TABLE roundup_line_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES roundup_batches(id) ON DELETE CASCADE,
  roundup_event_id UUID NOT NULL REFERENCES roundup_events(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (batch_id, roundup_event_id)
);
```

## 5.7 Liabilities, investments, identity

```sql
CREATE TABLE liabilities_credit (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  is_overdue BOOLEAN,
  last_payment_amount_cents BIGINT,
  last_payment_date DATE,
  minimum_payment_amount_cents BIGINT,
  next_payment_due_date DATE,
  apr_percentage NUMERIC(5,2),
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE liabilities_student (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  loan_name TEXT,
  outstanding_interest_cents BIGINT,
  origination_principal_cents BIGINT,
  disbursement_dates JSONB,
  interest_rate_percentage NUMERIC(6,3),
  is_overdue BOOLEAN,
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
  -- No servicer_address column â€” not part of Plaid's documented student loan liability
  -- object. Do not reintroduce without a confirmed source.
);

CREATE TABLE liabilities_mortgage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  loan_type_description TEXT,
  interest_rate_percentage NUMERIC(6,3),
  maturity_date DATE,
  next_payment_due_date DATE,
  next_monthly_payment_cents BIGINT,
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE investment_holdings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  security_id TEXT,
  security_name TEXT,
  ticker_symbol TEXT,
  quantity NUMERIC(20,8),
  institution_price_cents BIGINT,
  institution_value_cents BIGINT,
  cost_basis_cents BIGINT,
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE investment_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  plaid_investment_transaction_id TEXT NOT NULL UNIQUE,
  security_id TEXT,
  type TEXT,
  amount_cents BIGINT,
  quantity NUMERIC(20,8),
  price_cents BIGINT,
  date DATE,
  raw JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE identity_data (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  legal_name TEXT,
  emails JSONB,
  phone_numbers JSONB,
  addresses JSONB,
  raw JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 5.8 Intelligence tables

```sql
CREATE TABLE income_signals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source_merchant TEXT,
  cadence TEXT,
  average_amount_cents BIGINT,
  last_detected_date DATE,
  next_expected_date DATE,          -- NULL whenever cadence = 'irregular', enforced in application code (9.2)
  confidence NUMERIC(4,3),
  evidence_state TEXT NOT NULL DEFAULT 'insufficient_evidence',
  calculation_version TEXT NOT NULL DEFAULT 'income_v1'
  -- v4.2 fix: a plain UNIQUE(user_id, source_merchant) does NOT stop duplicate
  -- rows when source_merchant IS NULL, because Postgres treats every NULL as
  -- distinct from every other NULL in a UNIQUE constraint. A user with two
  -- unattributed income sources could silently get two rows. Replaced below
  -- with two partial unique indexes: one for the common named-merchant case,
  -- one that treats "no merchant" as a single well-known key per user.
  ,updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX idx_income_signals_user_merchant
  ON income_signals (user_id, source_merchant) WHERE source_merchant IS NOT NULL;
CREATE UNIQUE INDEX idx_income_signals_user_no_merchant
  ON income_signals (user_id) WHERE source_merchant IS NULL;

CREATE TABLE recurring_streams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  merchant_id UUID REFERENCES merchants(id),
  stream_type TEXT NOT NULL,
  cadence TEXT NOT NULL,
  average_amount_cents BIGINT NOT NULL,
  amount_variance_cents BIGINT,
  last_observed_date DATE,
  next_expected_date DATE,
  confidence NUMERIC(4,3),
  calculation_version TEXT NOT NULL DEFAULT 'recurring_v1',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, merchant_id, stream_type)
);

CREATE TABLE cash_flow_periods (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  income_cents BIGINT NOT NULL DEFAULT 0,
  spending_cents BIGINT NOT NULL DEFAULT 0,
  transfer_cents BIGINT NOT NULL DEFAULT 0,
  fee_cents BIGINT NOT NULL DEFAULT 0,
  calculation_version TEXT NOT NULL DEFAULT 'cash_flow_v1',
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, period_start, period_end, calculation_version)
);

CREATE TABLE net_worth_snapshots (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  as_of_date DATE NOT NULL,
  assets_cents BIGINT,
  liabilities_cents BIGINT,
  net_worth_cents BIGINT,
  included_domains TEXT[] NOT NULL,
  missing_domains TEXT[] NOT NULL DEFAULT '{}',
  evidence_state TEXT NOT NULL,
  calculation_version TEXT NOT NULL DEFAULT 'net_worth_v1',
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, as_of_date, calculation_version)
);

CREATE TABLE financial_health_signals (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  signal_type TEXT NOT NULL,
  value NUMERIC,
  evidence_state TEXT NOT NULL,
  confidence NUMERIC(4,3),
  calculation_version TEXT NOT NULL,
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, signal_type, calculation_version)
);
```

## 5.9 Webhook, sync, audit, quality infrastructure

```sql
CREATE TABLE plaid_webhook_events (
  id BIGSERIAL PRIMARY KEY,
  idempotency_key TEXT NOT NULL UNIQUE,
  item_id TEXT,
  webhook_type TEXT,
  webhook_code TEXT,
  request_id TEXT,
  body_sha256 TEXT NOT NULL,
  raw_body BYTEA,
  verification_status TEXT NOT NULL,
  processing_status TEXT NOT NULL DEFAULT 'received',
  processing_error TEXT,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ
);

CREATE TABLE sync_runs (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plaid_item_id UUID NOT NULL REFERENCES plaid_items(id) ON DELETE CASCADE,
  trigger TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'running',
  added_count INT DEFAULT 0,
  modified_count INT DEFAULT 0,
  removed_count INT DEFAULT 0,
  error_message TEXT,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);

CREATE TABLE reconciliation_runs (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  scope TEXT NOT NULL,
  status TEXT NOT NULL,
  expected_value_cents BIGINT,
  actual_value_cents BIGINT,
  details JSONB,
  run_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE data_quality_events (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  issue_type TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  details JSONB,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE audit_trail (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  event_type TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  payload JSONB,
  created_by TEXT,
  record_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 5.10 Row-Level Security â€” every user-owned table, in full

Custom-JWT auth means `auth.uid()` isn't populated by Supabase Auth. The API sets a per-request Postgres setting after verifying the JWT itself, and every policy below reads that setting. This is the complete list â€” nothing left as "repeat the pattern."

```sql
-- Run once per table. Pattern: enable RLS, then a single owner policy.
-- App code must call: SELECT set_config('app.current_user_id', $1, true);
-- inside the same transaction/connection as every query below, using the
-- user id extracted from a verified JWT (see Section 8.1's authMiddleware).

-- v4.2: `users` deliberately has NO RLS policy in this section, and that is a
-- stated decision, not an oversight. Signup and login run BEFORE any verified
-- JWT exists, so there is no `app.current_user_id` to gate on yet at the moment
-- these queries run (Section 8.2 `signup`/`login` use the plain pool, not
-- `withUserContext`). The `users` table is instead protected by query-shape
-- discipline: application code only ever selects a single row by `id` or
-- `email`, and application code is the only thing that talks to Postgres â€”
-- there is no untrusted client path that can issue an arbitrary SELECT against
-- it. If a future endpoint ever needs to list or filter `users` directly,
-- RLS must be added at that time; this exception applies only to the
-- signup/login/lookup-by-id access pattern specified here.

ALTER TABLE plaid_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON plaid_items USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON accounts USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE source_observations ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON source_observations USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON transactions USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE roundup_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_events USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE roundup_accumulators ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_accumulators USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE roundup_batches ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_batches USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE liabilities_credit ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON liabilities_credit USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE liabilities_student ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON liabilities_student USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE liabilities_mortgage ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON liabilities_mortgage USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE investment_holdings ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON investment_holdings USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE investment_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON investment_transactions USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE identity_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON identity_data USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE income_signals ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON income_signals USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE recurring_streams ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON recurring_streams USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE cash_flow_periods ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON cash_flow_periods USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE net_worth_snapshots ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON net_worth_snapshots USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE financial_health_signals ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON financial_health_signals USING (user_id = current_setting('app.current_user_id', true)::uuid);

ALTER TABLE sync_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON sync_runs USING (user_id = current_setting('app.current_user_id', true)::uuid);

-- Indirectly user-scoped (no direct user_id column) â€” restrict via join-based policy
ALTER TABLE roundup_line_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_line_items USING (
  batch_id IN (SELECT id FROM roundup_batches WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

-- Not user-owned â€” global reference data, no RLS needed
-- merchants, merchant_aliases

-- Admin/system-only, never exposed to the app_role used by ordinary requests
ALTER TABLE plaid_webhook_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON plaid_webhook_events USING (current_setting('app.is_service_role', true)::boolean = true);

ALTER TABLE reconciliation_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON reconciliation_runs USING (current_setting('app.is_service_role', true)::boolean = true);

ALTER TABLE data_quality_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON data_quality_events USING (current_setting('app.is_service_role', true)::boolean = true);

ALTER TABLE audit_trail ENABLE ROW LEVEL SECURITY;
CREATE POLICY service_role_only ON audit_trail USING (current_setting('app.is_service_role', true)::boolean = true);
REVOKE UPDATE, DELETE ON audit_trail FROM ibag_app;   -- append-only enforced at the grant level, not just policy

ALTER TABLE provider_capabilities ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON provider_capabilities USING (
  plaid_item_id IN (SELECT id FROM plaid_items WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

ALTER TABLE transaction_classifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON transaction_classifications USING (
  transaction_id IN (SELECT id FROM transactions WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

ALTER TABLE transaction_relationships ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON transaction_relationships USING (
  transaction_id_a IN (SELECT id FROM transactions WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

ALTER TABLE roundup_corrections ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_only ON roundup_corrections USING (
  original_event_id IN (SELECT id FROM roundup_events WHERE user_id = current_setting('app.current_user_id', true)::uuid)
);

-- Restrict ordinary application policies to the dedicated app role.
ALTER POLICY owner_only ON plaid_items TO ibag_app;
ALTER POLICY owner_only ON accounts TO ibag_app;
ALTER POLICY owner_only ON source_observations TO ibag_app;
ALTER POLICY owner_only ON transactions TO ibag_app;
ALTER POLICY owner_only ON roundup_events TO ibag_app;
ALTER POLICY owner_only ON roundup_accumulators TO ibag_app;
ALTER POLICY owner_only ON roundup_batches TO ibag_app;
ALTER POLICY owner_only ON liabilities_credit TO ibag_app;
ALTER POLICY owner_only ON liabilities_student TO ibag_app;
ALTER POLICY owner_only ON liabilities_mortgage TO ibag_app;
ALTER POLICY owner_only ON investment_holdings TO ibag_app;
ALTER POLICY owner_only ON investment_transactions TO ibag_app;
ALTER POLICY owner_only ON identity_data TO ibag_app;
ALTER POLICY owner_only ON income_signals TO ibag_app;
ALTER POLICY owner_only ON recurring_streams TO ibag_app;
ALTER POLICY owner_only ON cash_flow_periods TO ibag_app;
ALTER POLICY owner_only ON net_worth_snapshots TO ibag_app;
ALTER POLICY owner_only ON financial_health_signals TO ibag_app;
ALTER POLICY owner_only ON sync_runs TO ibag_app;
ALTER POLICY owner_only ON roundup_line_items TO ibag_app;
ALTER POLICY owner_only ON provider_capabilities TO ibag_app;
ALTER POLICY owner_only ON transaction_classifications TO ibag_app;
ALTER POLICY owner_only ON transaction_relationships TO ibag_app;
ALTER POLICY owner_only ON roundup_corrections TO ibag_app;

-- Explicit grants for the dedicated direct-Postgres roles.
GRANT USAGE ON SCHEMA public TO ibag_app, ibag_service;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO ibag_app;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ibag_service;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ibag_app, ibag_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ibag_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT ALL PRIVILEGES ON TABLES TO ibag_service;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO ibag_app, ibag_service;

ALTER POLICY service_role_only ON plaid_webhook_events TO ibag_service;
ALTER POLICY service_role_only ON reconciliation_runs TO ibag_service;
ALTER POLICY service_role_only ON data_quality_events TO ibag_service;
ALTER POLICY service_role_only ON audit_trail TO ibag_service;

CREATE POLICY data_quality_user_select
ON data_quality_events
FOR SELECT TO ibag_app
USING (user_id = current_setting('app.current_user_id', true)::uuid);


```
Test requirement (Section 10): user A cannot read/update/delete user B through any table above, including the indirect/join-based policies â€” this is exactly where a missed policy hides, so these need explicit cross-user tests, not just a spot-check on `accounts`.

---

# 6. ENVIRONMENT VARIABLES (complete list)

```
NODE_ENV=production|development
PORT=3000

DATABASE_URL=postgresql://...                 # Supabase connection string (session pooler)

PLAID_CLIENT_ID=...
PLAID_SECRET=...
PLAID_ENV=sandbox|production                  # verify current valid values against your Plaid dashboard before deploy

ENCRYPTION_KEY=<base64, 32 bytes>              # generate: node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
JWT_SECRET=<base64, 64 bytes>                  # generate: node -e "console.log(require('crypto').randomBytes(64).toString('base64'))"
JWT_EXPIRES_IN=7d

CORS_ORIGIN=https://your-frontend-domain
API_PUBLIC_URL=https://your-api-domain
SERVICE_DATABASE_URL=postgresql://<service-role>:<password>@<host>:<port>/<database>
WEBHOOK_PUBLIC_URL=https://your-api-domain/plaid/webhook
SMTP_HOST=...
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=...
SMTP_PASSWORD=...
SMTP_FROM=no-reply@your-domain.example
FRONTEND_RESET_URL=https://your-frontend-domain/reset-password
FRONTEND_EMAIL_VERIFY_URL=https://your-frontend-domain/verify-email

RATE_LIMIT_LOGIN_MAX=8
RATE_LIMIT_LOGIN_WINDOW_MS=900000              # 15 minutes
```
Every value validated at boot (fail closed â€” process exits with a clear error if a required var is missing or malformed, never silently proceeds with an undefined secret).

---

# 7. PACKAGE.JSON (pinned dependencies)

```json
{
  "name": "ibag-api",
  "version": "1.0.0",
  "engines": { "node": ">=24.0.0 <25" },
  "dependencies": {
    "express": "4.22.2",
    "pg": "8.16.3",
    "bcrypt": "6.0.0",
    "jsonwebtoken": "9.0.3",
    "jose": "6.2.3",
    "plaid": "45.0.0",
    "dotenv": "16.4.5",
    "express-rate-limit": "7.5.0",
    "cors": "2.8.6",
    "nodemailer": "8.0.9"
  }
}
```
Note: no `node-fetch` â€” Node's built-in global `fetch` is used throughout (available natively since Node 18). Re-run `npm view <package> version` for each of these before your first install; Plaid in particular ships monthly, so `45.0.0` will be stale by the time you build this.

---

# 8. CORE IMPLEMENTATION MODULES

## 8.1 `src/auth/crypto.js` â€” AES-256-GCM for Plaid access tokens

```javascript
const crypto = require('crypto');
const ALGORITHM = 'aes-256-gcm';

const base64Key = process.env.ENCRYPTION_KEY;
if (!base64Key) {
  console.error('FATAL: ENCRYPTION_KEY is not defined.');
  process.exit(1);
}
let KEY;
try {
  KEY = Buffer.from(base64Key, 'base64');
} catch (err) {
  console.error('FATAL: ENCRYPTION_KEY is not valid base64.');
  process.exit(1);
}
if (KEY.length !== 32) {
  console.error(`FATAL: ENCRYPTION_KEY must decode to 32 bytes. Got ${KEY.length}.`);
  process.exit(1);
}

function encrypt(text) {
  if (text === null || text === undefined) throw new Error('encrypt(): text required');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, KEY, iv);
  const encrypted = Buffer.concat([cipher.update(String(text), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, authTag, encrypted]).toString('base64');
}

function decrypt(payload) {
  if (!payload) throw new Error('decrypt(): payload required');
  const data = Buffer.from(payload, 'base64');
  if (data.length < 28) throw new Error('decrypt(): payload too short');
  const iv = data.subarray(0, 12);
  const authTag = data.subarray(12, 28);
  const encrypted = data.subarray(28);
  const decipher = crypto.createDecipheriv(ALGORITHM, KEY, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
}

module.exports = { encrypt, decrypt };
```

## 8.2 `src/auth/auth.js` â€” signup, login, JWT middleware

```javascript
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');

const BCRYPT_COST = 12;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) { console.error('FATAL: JWT_SECRET is not defined.'); process.exit(1); }

// Precomputed dummy hash so login timing doesn't leak whether an email exists.
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing-safety', BCRYPT_COST);

async function signup(email, password) {
  const existing = await db.query('SELECT id FROM users WHERE email = $1', [email]);
  if (existing.rows.length > 0) {
    const err = new Error('EMAIL_ALREADY_REGISTERED');
    err.code = 'EMAIL_ALREADY_REGISTERED';
    throw err;
  }
  const passwordHash = await bcrypt.hash(password, BCRYPT_COST);
  const result = await db.query(
    'INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id, email',
    [email, passwordHash]
  );
  const user = result.rows[0];
  const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
  return { user, token };
}

async function login(email, password) {
  const result = await db.query('SELECT id, password_hash FROM users WHERE email = $1', [email]);
  const user = result.rows[0];
  // Always run a bcrypt.compare, even when the user doesn't exist, so response
  // timing doesn't distinguish "no such email" from "wrong password."
  const hashToCompare = user ? user.password_hash : DUMMY_HASH;
  const valid = await bcrypt.compare(password, hashToCompare);
  if (!user || !valid) {
    const err = new Error('INVALID_CREDENTIALS');
    err.code = 'INVALID_CREDENTIALS';
    throw err;
  }
  const token = jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
  return { user: { id: user.id, email }, token };
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ status: 'error', code: 'MISSING_TOKEN', message: 'Authorization required.' });
  }
  try {
    const payload = jwt.verify(header.slice(7), JWT_SECRET, { algorithms: ['HS256'], issuer: 'ibag-api', audience: 'ibag-client' });
    req.userId = payload.sub;
    next();
  } catch (err) {
    return res.status(401).json({ status: 'error', code: 'INVALID_TOKEN', message: 'Invalid or expired token.' });
  }
}

module.exports = { signup, login, authMiddleware };
```

## 8.3 `src/db.js` â€” connection pool + per-request RLS context

```javascript
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
pool.on('error', (err) => console.error('Unexpected idle client error', err));

// Run every user-scoped query through this so RLS (Section 5.10) actually applies.
async function withUserContext(userId, fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SELECT set_config('app.current_user_id', $1, true)", [userId]);
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

// v4.2 fix: Section 5.10 gates plaid_webhook_events, reconciliation_runs,
// data_quality_events, and audit_trail on current_setting('app.is_service_role').
// v4.1 never set that setting anywhere, so every write to those four tables
// â€” including the webhook handler's own insert of an incoming webhook â€” was
// silently blocked by RLS with no INSERT policy to satisfy it. This is the
// counterpart to withUserContext for that trust boundary: only call it from
// code that is not acting on behalf of an end user's request (the webhook
// pipeline, the reconciliation job, and system-level audit/quality writes).
async function withServiceRole(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SELECT set_config('app.is_service_role', 'true', true)");
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { pool, query: (...args) => pool.query(...args), withUserContext, withServiceRole };
```

## 8.4 `src/webhooks/plaidWebhookVerify.js` â€” corrected verification pipeline

```javascript
// Requires: jose ^6 on Node >=20.19.0/22.12.0/23+ (native require(esm) support â€” see Section 0.2 #8).
// On an older Node runtime, replace this require with: const jose = await import('jose');
// inside an async context, or pin jose@^4 instead.
const { importJWK, jwtVerify, decodeProtectedHeader } = require('jose');
const crypto = require('crypto');

const PLAID_CLIENT_ID = process.env.PLAID_CLIENT_ID;
const PLAID_SECRET = process.env.PLAID_SECRET;
const PLAID_ENV = process.env.PLAID_ENV || 'sandbox';
const CACHE_TTL_MS = 5 * 60 * 1000;
const MAX_IAT_AGE_SECONDS = 5 * 60;

const jwkCache = new Map();

function plaidHost(env) {
  // Re-verify against your Plaid dashboard before relying on this â€” environment
  // naming is one of the facts most likely to have moved since spec time.
  return env === 'production' ? 'production.plaid.com' : 'sandbox.plaid.com';
}

async function fetchVerificationJwk(keyId) {
  const now = Date.now();
  const cached = jwkCache.get(keyId);
  if (cached && cached.expiresAt > now) return cached.jwk;

  const res = await fetch(`https://${plaidHost(PLAID_ENV)}/webhook_verification_key/get`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ client_id: PLAID_CLIENT_ID, secret: PLAID_SECRET, key_id: keyId }),
  });
  if (!res.ok) throw new Error(`Plaid JWK fetch failed: ${res.status}`);
  const json = await res.json();
  const jwk = json.key;
  if (!jwk) throw new Error('Plaid response missing key field');
  jwkCache.set(keyId, { jwk, expiresAt: now + CACHE_TTL_MS });
  return jwk;
}

/**
 * Verifies a Plaid webhook. rawBody MUST be the exact raw request body buffer,
 * captured before any JSON parsing middleware touches it.
 */
async function verifyPlaidWebhook(rawBody, verificationHeader) {
  if (!verificationHeader) return { verified: false, reason: 'MISSING_HEADER' };

  let header;
  try {
    header = decodeProtectedHeader(verificationHeader);
  } catch {
    return { verified: false, reason: 'MALFORMED_JWT' };
  }

  if (header.alg !== 'ES256') return { verified: false, reason: 'WRONG_ALG' };
  if (!header.kid) return { verified: false, reason: 'MISSING_KID' };

  let jwk, payload;
  try {
    jwk = await fetchVerificationJwk(header.kid);
    const key = await importJWK(jwk, 'ES256');
    const result = await jwtVerify(verificationHeader, key, { algorithms: ['ES256'] });
    payload = result.payload;
  } catch (err) {
    return { verified: false, reason: 'BAD_SIGNATURE' };
  }

  const nowSeconds = Math.floor(Date.now() / 1000);
  // v4.2 fix: `nowSeconds - payload.iat > MAX_IAT_AGE_SECONDS` only rejects an
  // iat that is too far in the PAST. If iat is in the FUTURE (clock skew, or a
  // forged future timestamp used to replay an old signed payload), the
  // subtraction goes negative and this check silently passes. Math.abs()
  // rejects both directions, per Section 13.1.6.
  if (!payload.iat || Math.abs(nowSeconds - payload.iat) > MAX_IAT_AGE_SECONDS) {
    return { verified: false, reason: 'STALE_IAT' };
  }

  const bodyHash = crypto.createHash('sha256').update(rawBody).digest('hex');
  const expectedHash = payload.request_body_sha256;
  if (!expectedHash) return { verified: false, reason: 'MISSING_BODY_HASH' };

  const bodyHashBuf = Buffer.from(bodyHash, 'hex');
  const expectedHashBuf = Buffer.from(expectedHash, 'hex');
  if (
    bodyHashBuf.length !== expectedHashBuf.length ||
    !crypto.timingSafeEqual(bodyHashBuf, expectedHashBuf)
  ) {
    return { verified: false, reason: 'BODY_HASH_MISMATCH' };
  }

  return { verified: true, payload };
}

module.exports = { verifyPlaidWebhook };
```

## 8.5 `src/routes/webhook.js` â€” raw body capture + idempotency + dispatch

```javascript
const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { verifyPlaidWebhook } = require('../webhooks/plaidWebhookVerify');
const db = require('../db');
const { runSync } = require('../jobs/sync');

// Mount with express.raw({ type: 'application/json' }) on this route specifically â€”
// do NOT let a global express.json() middleware parse this body first, or the raw
// bytes needed for hash verification are gone.
router.post('/plaid/webhook', async (req, res) => {
  const rawBody = req.body; // Buffer, thanks to express.raw()
  const verificationHeader = req.headers['plaid-verification'];

  const result = await verifyPlaidWebhook(rawBody, verificationHeader);
  const bodySha256 = crypto.createHash('sha256').update(rawBody).digest('hex');

  // v4.2 fix: every write in this handler now runs inside withServiceRole()
  // (Section 8.3) so app.is_service_role is actually set on the connection.
  // Without it, RLS on plaid_webhook_events (Section 5.10) blocks every
  // INSERT below with no error surfaced to the caller other than a generic
  // DB failure â€” this was the "webhook pipeline can't boot" bug.
  if (!result.verified) {
    await db.withServiceRole((client) => client.query(
      `INSERT INTO plaid_webhook_events
         (idempotency_key, body_sha256, verification_status, raw_body)
       VALUES ($1, $2, $3, $4)`,
      [`rejected-${crypto.randomUUID()}`, bodySha256, `rejected_${result.reason.toLowerCase()}`, rawBody]
    ));
    return res.status(400).json({ status: 'error', code: result.reason });
  }

  const payload = result.payload;
  const idempotencyKey = payload.request_id || bodySha256;

  // v4.2 fix (Section 13.1.7): a separate SELECT-then-INSERT lets two
  // concurrent identical deliveries both pass the SELECT before either
  // commits, then race on the INSERT's UNIQUE constraint â€” which stops data
  // corruption but throws an unhandled DB error instead of deduplicating
  // gracefully. A single atomic INSERT ... ON CONFLICT DO NOTHING RETURNING
  // id makes "did I win the race" a single round-trip with no gap to race in.
  const inserted = await db.withServiceRole((client) => client.query(
    `INSERT INTO plaid_webhook_events
       (idempotency_key, item_id, webhook_type, webhook_code, request_id,
        body_sha256, raw_body, verification_status)
     VALUES ($1, $2, $3, $4, $5, $6, $7, 'verified')
     ON CONFLICT (idempotency_key) DO NOTHING
     RETURNING id`,
    [idempotencyKey, payload.item_id, payload.webhook_type, payload.webhook_code,
     payload.request_id, bodySha256, rawBody]
  ));

  if (inserted.rows.length === 0) {
    // No row returned means this idempotency_key already exists â€” another
    // delivery (possibly concurrent) already owns processing. Ack without
    // reprocessing or dispatching a second sync.
    return res.status(200).json({ status: 'ok', deduplicated: true });
  }

  // Persist only. The durable worker owns processing and retries.
  // HTTP 200 means "event durably accepted", not "sync completed".
  res.status(200).json({ status: 'ok', accepted: true });
});

module.exports = router;
```

## 8.6 `src/classification/classify.js` â€” deterministic, explicitly ordered

```javascript
const CLASSIFICATION_VERSION = 'classification_v1';

/**
 * Rules are evaluated IN ORDER; the first match wins. This explicit precedence
 * (not an unordered rule set) is what makes classification deterministic and
 * testable â€” a refund and an income deposit can both have a negative amount,
 * so ordering resolves the ambiguity, not amount sign alone.
 */
function classify(transaction, context) {
  const { amount_cents, provider_category, merchant_name, account_type } = transaction;
  const cat = (provider_category || '').toLowerCase();
  const merchant = (merchant_name || '').toLowerCase();

  // 1. Refund: explicit category, OR an inverse-amount match to a prior purchase
  //    at the same merchant within 60 days (checked via context.priorPurchaseMatch).
  if (cat.includes('refund') || context.priorPurchaseMatch) {
    return result('REFUND', 0.9, 'category_or_reversal_match');
  }

  // 2. Fee: explicit category or known fee-merchant pattern.
  if (cat.includes('fee') || /overdraft|late fee|foreign transaction fee|atm fee/.test(merchant)) {
    return result('FEE', 0.9, 'category_or_merchant_pattern');
  }

  // 3. ATM withdrawal.
  if (cat.includes('atm')) {
    return result('ATM_WITHDRAWAL', 0.9, 'category');
  }

  // 4. Loan payment: loan account, balance-reducing transaction.
  if (account_type === 'loan') {
    return result('LOAN_PAYMENT', 0.85, 'account_type');
  }

  // 5. Credit card payment: credit account, a payment (not a purchase) against it.
  if (account_type === 'credit' && context.isPaymentNotPurchase) {
    return result('CREDIT_CARD_PAYMENT', 0.85, 'account_type_and_direction');
  }

  // 6. Investment activity.
  if (account_type === 'investment' || cat.includes('invest')) {
    return result('INVESTMENT_ACTIVITY', 0.85, 'account_type_or_category');
  }

  // 7. Internal transfer â€” checked LAST among the negative-amount cases, so a
  //    transfer never masquerades as income (context.transferMatch is set by
  //    the transfer-detection pass, Section 5.5 transaction_relationships).
  if (context.transferMatch) {
    return result(amount_cents < 0 ? 'TRANSFER_IN' : 'TRANSFER_OUT', context.transferConfidence, 'relationship_match');
  }

  // 8. Income resolution â€” negative amount (money in), none of rules 1-7 matched.
  //    v4.3: this rule now actually implements the two-pass structure the prose
  //    always described but no prior version's code carried out. `context.incomePhase`
  //    tells this function which pass is calling it:
  //      - 'initial' (sync.js, Section 8.10, pass 1): income_signals hasn't been
  //        (re)computed against this transaction yet, so an unresolved negative-amount
  //        transaction is deferred as PENDING_INCOME_REVIEW rather than guessed.
  //      - 'resolved' (jobs/incomeReview.js, Section 8.14, pass 2): income_signals
  //        has just been recomputed and context.incomeSignalMatch reflects a real
  //        lookup against it â€” a definite yes becomes INCOME, a definite no becomes
  //        UNKNOWN (not re-deferred; deferring forever would never terminate).
  if (amount_cents < 0) {
    if (context.incomeSignalMatch) {
      return result('INCOME', context.incomeConfidence, 'recurrence_pattern');
    }
    if (context.incomePhase === 'resolved') {
      return result('UNKNOWN', 0.0, 'income_signal_absent_after_resolution');
    }
    return result('PENDING_INCOME_REVIEW', null, 'awaiting_income_signal_resolution');
  }

  // 9. Purchase: positive amount, none of the above.
  if (amount_cents > 0) {
    return result('PURCHASE', 0.95, 'default_positive_amount');
  }

  // 10. Everything else â€” explicitly UNKNOWN, not force-classified.
  return result('UNKNOWN', 0.0, 'no_rule_matched');
}

function result(classification, confidence, evidenceReason) {
  return { classification, classification_version: CLASSIFICATION_VERSION, confidence, evidence: { reason: evidenceReason } };
}

module.exports = { classify, CLASSIFICATION_VERSION };
```
**v4.3 status: APPLIED.** Rule 8 above now returns a real `PENDING_INCOME_REVIEW` classification (a plain string value in the existing `TEXT` column â€” no schema change needed) instead of the prior version's prose-only description of a two-pass split that no code implemented. `context.incomePhase` is a new, required-in-practice context field: `sync.js` (8.10) always calls with `incomePhase: 'initial'`; the new `jobs/incomeReview.js` (8.14) always calls with `incomePhase: 'resolved'` after actually querying `income_signals`. Section 8.7's `INELIGIBLE_CLASSIFICATIONS` set (roundup rules) now also includes `'PENDING_INCOME_REVIEW'` explicitly â€” see 8.7 for why this matters even though `amount_cents <= 0` already excludes these transactions from Round-Up eligibility on its own.

## 8.7 `src/roundup/rules.js` â€” deterministic rule + atomic accumulator

```javascript
const RULE_VERSION = 'ROUNDUP_STANDARD_V1';
const ROUNDUP_MAX_ELIGIBLE_CENTS = 80000; // $800.00 â€” see Section 0.1 for how to change this

const INELIGIBLE_CLASSIFICATIONS = new Set([
  'REFUND', 'INCOME', 'TRANSFER_IN', 'TRANSFER_OUT', 'FEE',
  'LOAN_PAYMENT', 'CREDIT_CARD_PAYMENT', 'ATM_WITHDRAWAL',
  'CASH_DEPOSIT', 'INVESTMENT_ACTIVITY', 'UNKNOWN',
  // v4.3: added now that classify.js (8.6) can actually return this value.
  // Belt-and-suspenders â€” every PENDING_INCOME_REVIEW transaction has
  // amount_cents < 0, which the `amount_cents <= 0` check above already
  // excludes on its own â€” but listing it explicitly here means a future
  // change to the amount check can't silently make an unresolved income
  // candidate eligible for a Round-Up.
  'PENDING_INCOME_REVIEW',
]);

function evaluateRoundup(transaction, classification) {
  const { amount_cents, pending } = transaction;

  if (pending) return ineligible(transaction, 'pending');
  if (amount_cents <= 0) return ineligible(transaction, 'non_positive_amount');
  if (amount_cents >= ROUNDUP_MAX_ELIGIBLE_CENTS) return ineligible(transaction, 'above_threshold');
  if (INELIGIBLE_CLASSIFICATIONS.has(classification)) return ineligible(transaction, classification.toLowerCase());

  const roundupCents = (100 - (amount_cents % 100)) % 100;
  return {
    rule_version: RULE_VERSION,
    source_amount_cents: amount_cents,
    roundup_cents: roundupCents,
    eligibility_status: 'eligible',
    eligibility_reason: roundupCents === 0 ? 'whole_dollar' : 'eligible',
  };
}

function ineligible(transaction, reason) {
  return {
    rule_version: RULE_VERSION,
    source_amount_cents: transaction.amount_cents,
    roundup_cents: 0,
    eligibility_status: 'ineligible',
    eligibility_reason: reason,
  };
}

// Atomic accumulator update â€” ON CONFLICT + explicit transaction, per Section 5.6.
async function applyRoundupEvent(client, userId, accountId, transactionId, evalResult) {
  const insert = await client.query(
    `INSERT INTO roundup_events
       (user_id, transaction_id, rule_version, source_amount_cents, roundup_cents,
        eligibility_status, eligibility_reason)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (transaction_id, rule_version) DO NOTHING
     RETURNING id, roundup_cents`,
    [userId, transactionId, evalResult.rule_version, evalResult.source_amount_cents,
     evalResult.roundup_cents, evalResult.eligibility_status, evalResult.eligibility_reason]
  );

  if (insert.rows.length === 0) return null; // duplicate â€” already processed, no accumulator change

  const event = insert.rows[0];
  if (evalResult.eligibility_status === 'eligible' && event.roundup_cents > 0) {
    const accumulator = await client.query(
      `INSERT INTO roundup_accumulators (user_id, account_id, total_cents)
       VALUES ($1, $2, $3)
       ON CONFLICT (account_id) DO UPDATE
         SET total_cents = roundup_accumulators.total_cents + $3, updated_at = now()
       RETURNING id`,
      [userId, accountId, event.roundup_cents]
    );
    // v4.2: previously the accumulator was updated but nothing ever wrote to
    // roundup_batches/roundup_line_items â€” see addToOpenBatch below.
    await addToOpenBatch(client, userId, accumulator.rows[0].id, event.id);
  }
  return event;
}

// Correction: moves the accumulator by the DELTA, never the full new amount.
//
// v4.3 fix: this function previously only logged to roundup_corrections and
// nudged the accumulator â€” it never touched the original roundup_events row
// itself. That meant reconciliation.js's SUM(roundup_events.roundup_cents)
// permanently diverged from the accumulator after every single correction,
// so a correctly-corrected account would show up as a false "mismatch" in
// every future reconciliation run. This version updates the roundup_events
// row (source of truth for reconciliation), then the accumulator, then keeps
// the batch/line-item layer consistent with the new eligibility_status.
//
// Batches: a 'pending' batch's line items can be safely added/removed/
// recomputed. A 'closed' batch is immutable settled history (see
// closeBatch's comment below) â€” this function will NOT rewrite a closed
// batch's total. If a correction affects an event already in a closed
// batch, it instead returns a dataQualityFlag describing the drift, which
// the CALLER must write via db.withServiceRole() (data_quality_events is
// service-role-gated per Section 5.10/13.1.15 â€” writing it directly from
// this function, which runs inside the caller's withUserContext
// transaction, would silently fail exactly like the bug fixed in 13.1.15).
// This function deliberately does NOT attempt that write itself.
async function applyRoundupCorrection(
  client, userId, originalEventId, accountId,
  oldSourceCents, newSourceCents, oldCents, newCents,
  newEligibilityStatus, newEligibilityReason, reason
) {
  await client.query(
    `INSERT INTO roundup_corrections
       (original_event_id, reason, old_source_amount_cents, new_source_amount_cents,
        old_roundup_cents, new_roundup_cents)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [originalEventId, reason, oldSourceCents, newSourceCents, oldCents, newCents]
  );

  await client.query(
    `UPDATE roundup_events
        SET source_amount_cents = $1,
            roundup_cents = $2,
            eligibility_status = $3,
            eligibility_reason = $4
      WHERE id = $5`,
    [newSourceCents, newCents, newEligibilityStatus, newEligibilityReason, originalEventId]
  );

  const delta = newCents - oldCents;
  let dataQualityFlag = null;

  if (delta !== 0) {
    await client.query(
      `INSERT INTO roundup_accumulators (user_id, account_id, total_cents)
       VALUES ($1, $2, $3)
       ON CONFLICT (account_id) DO UPDATE
         SET total_cents = roundup_accumulators.total_cents + $3, updated_at = now()`,
      [userId, accountId, delta]
    );
  }

  const lineItem = await client.query(
    `SELECT rli.id, rb.id AS batch_id, rb.status
     FROM roundup_line_items rli JOIN roundup_batches rb ON rb.id = rli.batch_id
     WHERE rli.roundup_event_id = $1`,
    [originalEventId]
  );
  const existing = lineItem.rows[0] || null;

  if (newEligibilityStatus === 'eligible' && !existing) {
    // Was ineligible (no line item), correction made it eligible â€” needs one now.
    const accumulator = await client.query(
      `SELECT id FROM roundup_accumulators WHERE account_id = $1`, [accountId]
    );
    if (accumulator.rows.length > 0) {
      await addToOpenBatch(client, userId, accumulator.rows[0].id, originalEventId);
    }
  } else if (newEligibilityStatus !== 'eligible' && existing) {
    // Was eligible (had a line item), correction made it ineligible â€” remove it.
    if (existing.status === 'pending') {
      await client.query(`DELETE FROM roundup_line_items WHERE id = $1`, [existing.id]);
      await recomputeBatchTotal(client, existing.batch_id);
    } else {
      dataQualityFlag = {
        issueType: 'roundup_correction_against_closed_batch',
        entityType: 'roundup_batch',
        entityId: existing.batch_id,
        details: { roundupEventId: originalEventId, oldCents, newCents, newEligibilityStatus },
      };
    }
  } else if (newEligibilityStatus === 'eligible' && existing && delta !== 0) {
    // Still eligible, amount changed â€” recompute the batch total if it's still open.
    if (existing.status === 'pending') {
      await recomputeBatchTotal(client, existing.batch_id);
    } else {
      dataQualityFlag = {
        issueType: 'roundup_correction_against_closed_batch',
        entityType: 'roundup_batch',
        entityId: existing.batch_id,
        details: { roundupEventId: originalEventId, oldCents, newCents, newEligibilityStatus },
      };
    }
  }

  return { dataQualityFlag };
}

async function recomputeBatchTotal(client, batchId) {
  await client.query(
    `UPDATE roundup_batches SET total_cents = (
       SELECT COALESCE(SUM(rli.roundup_cents_snapshot), 0)
       FROM roundup_line_items rli
       WHERE rli.batch_id = $1
     ) WHERE id = $1`,
    [batchId]
  );
}

// v4.2 addition (closes the gap named in Section 13.1's original audit): the
// batching layer (roundup_batches / roundup_line_items, Section 5.6) was
// defined as schema in every prior version but nothing ever wrote to it.
// A batch groups accumulated roundup_events for eventual settlement â€” Phase 1
// is read-only (Section 1), so "settlement" here means marking a batch closed
// for reporting/export, not moving money.

// Opens (or reuses) a single 'pending' batch per accumulator and attaches a
// roundup_event's contribution to it as a line item. Call this from
// applyRoundupEvent's success path once an eligible event has increased the
// accumulator.
async function addToOpenBatch(client, userId, accumulatorId, roundupEventId) {
  const existing = await client.query(
    `SELECT id FROM roundup_batches
     WHERE accumulator_id = $1 AND status = 'pending'
     ORDER BY created_at DESC LIMIT 1`,
    [accumulatorId]
  );

  let batchId;
  if (existing.rows.length > 0) {
    batchId = existing.rows[0].id;
  } else {
    const created = await client.query(
      `INSERT INTO roundup_batches (user_id, accumulator_id, status)
       VALUES ($1, $2, 'pending')
       ON CONFLICT DO NOTHING
       RETURNING id`,
      [userId, accumulatorId]
    );
    if (created.rows.length > 0) {
      batchId = created.rows[0].id;
    } else {
      const raced = await client.query(
        `SELECT id FROM roundup_batches
         WHERE accumulator_id = $1 AND status = 'pending'
         ORDER BY created_at DESC LIMIT 1`,
        [accumulatorId]
      );
      if (raced.rows.length === 0) throw new Error('ROUNDUP_BATCH_CREATE_RACE');
      batchId = raced.rows[0].id;
    }
  }

  await client.query(
    `INSERT INTO roundup_line_items (batch_id, roundup_event_id, roundup_cents_snapshot)
     SELECT $1, id, roundup_cents
     FROM roundup_events
     WHERE id = $2
     ON CONFLICT (roundup_event_id) DO NOTHING`,
    [batchId, roundupEventId]
  );

  await recomputeBatchTotal(client, batchId);

  return batchId;
}

// Closes the currently-open batch for an accumulator (e.g. on a scheduled
// settlement cadence). A closed batch's line items are immutable history;
// new roundup_events after this point open a fresh 'pending' batch.
async function closeBatch(client, accumulatorId) {
  const result = await client.query(
    `UPDATE roundup_batches SET status = 'closed', closed_at = now()
     WHERE accumulator_id = $1 AND status = 'pending'
     RETURNING id, total_cents`,
    [accumulatorId]
  );
  return result.rows[0] || null;
}

module.exports = {
  evaluateRoundup, applyRoundupEvent, applyRoundupCorrection,
  addToOpenBatch, closeBatch, recomputeBatchTotal,
  RULE_VERSION, ROUNDUP_MAX_ELIGIBLE_CENTS,
};
```
`applyRoundupEvent`'s accumulator-update branch (above) MUST call `addToOpenBatch(client, userId, accumulatorId, event.id)` immediately after the accumulator UPDATE, inside the same transaction, so a batch line item is never created for an event whose accumulator update didn't commit.

**Callers of `applyRoundupCorrection` MUST check the returned `dataQualityFlag`.** If non-null, the caller must write it to `data_quality_events` via `db.withServiceRole()` in a separate call â€” never by trying to write it on the same `client` this function ran on, which is a `withUserContext` connection without `app.is_service_role` set. Section 8.10 (`sync.js`) shows the required pattern.

## 8.8 Sandbox safety guard (`src/scripts/plaidSandboxSeed.js`, top of file)

```javascript
if (process.env.NODE_ENV === 'production' || process.env.PLAID_ENV !== 'sandbox') {
  console.error('FATAL: this script may only run with NODE_ENV != production and PLAID_ENV=sandbox.');
  process.exit(1);
}
if (!process.env.DATABASE_URL || !process.env.DATABASE_URL.includes('sandbox')) {
  console.error('FATAL: DATABASE_URL does not contain an explicit "sandbox" marker. Refusing to run.');
  process.exit(1);
}
```
The `DATABASE_URL` naming convention this checks for (containing the literal string `sandbox`) must be an actual convention you adopt for your Supabase project names/connection strings â€” it only works as a guard if it's true in practice, not just in this snippet.

## 8.9 `src/providers/plaid/adapter.js` â€” the provider boundary from Section 4

v4.2 addition: Section 4 specified this interface in every prior version; nothing implemented it. This is the concrete boundary â€” nothing above `syncTransactions()` elsewhere in the codebase should import the `plaid` SDK directly.

```javascript
const { PlaidApi, Configuration, PlaidEnvironments } = require('plaid');
const { encrypt, decrypt } = require('../../auth/crypto');

const config = new Configuration({
  basePath: PlaidEnvironments[process.env.PLAID_ENV || 'sandbox'],
  baseOptions: {
    headers: {
      'PLAID-CLIENT-ID': process.env.PLAID_CLIENT_ID,
      'PLAID-SECRET': process.env.PLAID_SECRET,
    },
  },
});
const plaidClient = new PlaidApi(config);

async function connectItem(publicToken) {
  const exchange = await plaidClient.itemPublicTokenExchange({ public_token: publicToken });
  const { access_token, item_id } = exchange.data;
  const itemResp = await plaidClient.itemGet({ access_token });
  const institutionId = itemResp.data.item.institution_id || null;
  let institutionName = null;
  if (institutionId) {
    const inst = await plaidClient.institutionsGetById({
      institution_id: institutionId, country_codes: ['US'],
    });
    institutionName = inst.data.institution.name;
  }
  return {
    itemId: item_id,
    accessTokenEncrypted: encrypt(access_token),
    institutionId,
    institutionName,
  };
}

async function createLinkToken(clientUserId) {
  const { data } = await plaidClient.linkTokenCreate({
    user: { client_user_id: clientUserId },
    client_name: 'iBag',
    products: ['transactions'],
    required_if_supported_products: ['identity'],
    additional_consented_products: ['liabilities', 'investments'],
    country_codes: ['US'],
    language: 'en',
    webhook: process.env.WEBHOOK_PUBLIC_URL,
  });
  return data;
}

async function syncAccounts(accessTokenEncrypted) {
  const access_token = decrypt(accessTokenEncrypted);
  const { data } = await plaidClient.accountsGet({ access_token });
  return data.accounts.map((a) => ({
    plaidAccountId: a.account_id,
    name: a.name,
    officialName: a.official_name,
    mask: a.mask,
    type: a.type,
    subtype: a.subtype,
    currentBalanceCents: a.balances.current != null ? Math.round(a.balances.current * 100) : null,
    availableBalanceCents: a.balances.available != null ? Math.round(a.balances.available * 100) : null,
    isoCurrencyCode: a.balances.iso_currency_code || 'USD',
  }));
}

// Cursor-based per Section 0.2 fact #4. Caller is responsible for persisting
// the returned nextCursor onto plaid_items.cursor before the next call.
async function syncTransactions(accessTokenEncrypted, cursor) {
  const access_token = decrypt(accessTokenEncrypted);
  let added = [], modified = [], removed = [], hasMore = true, nextCursor = cursor || null;

  while (hasMore) {
    const { data } = await plaidClient.transactionsSync({
      access_token,
      cursor: nextCursor || undefined,
    });
    added = added.concat(data.added);
    modified = modified.concat(data.modified);
    removed = removed.concat(data.removed);
    hasMore = data.has_more;
    nextCursor = data.next_cursor;
  }
  return { added, modified, removed, nextCursor, hasMore: false };
}

async function syncLiabilities(accessTokenEncrypted) {
  const access_token = decrypt(accessTokenEncrypted);
  const { data } = await plaidClient.liabilitiesGet({ access_token });
  return data.liabilities;
}

async function syncInvestments(accessTokenEncrypted) {
  const access_token = decrypt(accessTokenEncrypted);
  const holdings = await plaidClient.investmentsHoldingsGet({ access_token });
  const transactions = await plaidClient.investmentsTransactionsGet({
    access_token,
    start_date: '2020-01-01', // widened on first sync; narrowed to incremental window thereafter by the caller
    end_date: new Date().toISOString().slice(0, 10),
  });
  return { holdings: holdings.data.holdings, investmentTransactions: transactions.data.investment_transactions };
}

async function syncIdentity(accessTokenEncrypted) {
  const access_token = decrypt(accessTokenEncrypted);
  const { data } = await plaidClient.identityGet({ access_token });
  return data.accounts.map((a) => ({ accountId: a.account_id, owners: a.owners }));
}

// Delegates to src/webhooks/plaidWebhookVerify.js (Section 8.4) â€” kept as a
// pass-through here so nothing outside this adapter needs to know which
// module owns verification.
const { verifyPlaidWebhook } = require('../../webhooks/plaidWebhookVerify');

module.exports = {
  connectItem, createLinkToken, syncAccounts, syncTransactions, syncLiabilities,
  syncInvestments, syncIdentity, verifyWebhook: verifyPlaidWebhook,
};
```

## 8.10 `src/jobs/sync.js` â€” the actual `/transactions/sync` loop

v4.2 addition: this was the single most central missing piece â€” `webhook.js` (8.5) has required it since v4.0 and it never existed as code. This wires cursor persistence, the added/modified/removed loop, and dispatch into classification and Round-Up evaluation.

```javascript
const db = require('../db');
const plaid = require('../providers/plaid/adapter');
const { classify } = require('../classification/classify');
const { evaluateRoundup, applyRoundupEvent, applyRoundupCorrection } = require('../roundup/rules');
const { detectTransferPair } = require('../intelligence/transfer-detection'); // Section 9.6

async function runSync({ itemId, trigger }) {
  const itemResult = await db.withServiceRole((client) => client.query(
    'SELECT id, user_id, plaid_access_token_encrypted, cursor FROM plaid_items WHERE plaid_item_id = $1',
    [itemId]
  ));
  if (itemResult.rows.length === 0) {
    throw new Error(`SYNC_UNKNOWN_ITEM: no plaid_items row for item_id ${itemId}`);
  }
  const item = itemResult.rows[0];

  const runInsert = await db.withUserContext(item.user_id, (client) => client.query(
    `INSERT INTO sync_runs (user_id, plaid_item_id, trigger, status)
     VALUES ($1, $2, $3, 'running') RETURNING id`,
    [item.user_id, item.id, trigger]
  ));
  const syncRunId = runInsert.rows[0].id;

  try {
    const { added, modified, removed, nextCursor } =
      await plaid.syncTransactions(item.plaid_access_token_encrypted, item.cursor);

    const pendingDataQualityFlags = [];

    await db.withUserContext(item.user_id, async (client) => {
      // Added + modified share an upsert path â€” Plaid's `modified` entries
      // carry the full current transaction object, same shape as `added`.
      for (const tx of [...added, ...modified]) {
        const amountCents = Math.round(tx.amount * 100); // Plaid: positive = debit, matches Section 5.5 convention

        // v4.3 fix (gap 1): the account row is now looked up BEFORE the
        // transaction upsert, specifically so its `type` is available to
        // pass into classify() below. Previously account_type was hardcoded
        // to null, which silently made classify.js rules 4-6 (LOAN_PAYMENT,
        // CREDIT_CARD_PAYMENT, INVESTMENT_ACTIVITY) dead code â€” they all
        // branch on account_type and it was never supplied.
        const accountLookup = await client.query(
          `SELECT id, type FROM accounts WHERE plaid_account_id = $1 AND user_id = $2`,
          [tx.account_id, item.user_id]
        );
        if (accountLookup.rows.length === 0) continue; // account not yet synced this pass â€” picked up on next sync
        const account = accountLookup.rows[0];

        // v4.3: `(xmax = 0) AS was_inserted` is the standard Postgres idiom
        // for distinguishing an actual INSERT from an ON CONFLICT DO UPDATE
        // in a single round-trip. This replaces relying on which of Plaid's
        // `added`/`modified` arrays a transaction came from â€” Plaid's own
        // partitioning is a reasonable signal but the database's own view of
        // whether this plaid_transaction_id already existed is the ground
        // truth this pipeline actually needs for the Round-Up correction
        // decision below, and is correct even if a transaction Plaid calls
        // "added" happens to already exist locally (e.g. a re-delivered
        // webhook after a partial prior failure).
        const inserted = await client.query(
          `INSERT INTO transactions
             (user_id, account_id, plaid_transaction_id, amount_cents, iso_currency_code,
              merchant_name, provider_category, pending, pending_transaction_id,
              authorized_date, posted_date, raw)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
           ON CONFLICT (plaid_transaction_id) DO UPDATE SET
             amount_cents = $4, merchant_name = $6, provider_category = $7,
             pending = $8, pending_transaction_id = $9, posted_date = $11,
             raw = $12, updated_at = now()
           RETURNING id, amount_cents, pending, account_id, (xmax = 0) AS was_inserted`,
          [item.user_id, account.id, tx.transaction_id, amountCents, tx.iso_currency_code || 'USD',
           tx.merchant_name, tx.personal_finance_category?.primary || tx.category?.[0] || null,
           tx.pending, tx.pending_transaction_id, tx.authorized_date, tx.date, JSON.stringify(tx)]
        );
        const row = inserted.rows[0];

        // Two-pass classification per Section 8.6: pass 1 here (incomePhase:
        // 'initial'). Income-signal resolution (pass 2) runs as a separate
        // scheduled step (jobs/incomeReview.js, Section 8.14) against
        // PENDING_INCOME_REVIEW rows, not inline in the webhook-latency path.
        const priorPurchaseMatch = false; // resolved by a dedicated refund-matching pass, out of scope for this loop
        const transferMatch = await detectTransferPair(client, item.user_id, {
          id: row.id, amount_cents: row.amount_cents, posted_date: tx.date,
        });
        const classification = classify(
          { amount_cents: row.amount_cents, provider_category: tx.personal_finance_category?.primary,
            merchant_name: tx.merchant_name, account_type: account.type },
          { priorPurchaseMatch, transferMatch: !!transferMatch, transferConfidence: 0.75,
            // isPaymentNotPurchase is still not computed from real data â€” see
            // Section 13.3's "still genuinely unresolved" list. Rule 5
            // (CREDIT_CARD_PAYMENT) therefore still cannot fire even though
            // account_type is now correctly supplied.
            isPaymentNotPurchase: false, incomeSignalMatch: false, incomeConfidence: 0,
            incomePhase: 'initial' }
        );
        await client.query(
          `INSERT INTO transaction_classifications (transaction_id, classification, classification_version, confidence, evidence)
           VALUES ($1,$2,$3,$4,$5)
           ON CONFLICT (transaction_id, classification_version) DO UPDATE
             SET classification = $2, confidence = $4, evidence = $5`,
          [row.id, classification.classification, classification.classification_version,
           classification.confidence, classification.evidence]
        );

        const roundupEval = evaluateRoundup(
          { amount_cents: row.amount_cents, pending: row.pending }, classification.classification
        );

        if (row.was_inserted) {
          await applyRoundupEvent(client, item.user_id, row.account_id, row.id, roundupEval);
        } else {
          // v4.3 fix (gap 3): row.was_inserted === false means this
          // plaid_transaction_id already had a roundup_events row from a
          // prior sync. applyRoundupEvent's ON CONFLICT DO NOTHING would
          // silently no-op here, leaving a stale roundup_cents even though
          // the transaction's real amount (and therefore the correct
          // roundup) may have changed â€” this was the "modified transactions
          // don't trigger corrections" gap. Route through the correction
          // path instead.
          const priorEvent = await client.query(
            `SELECT id, roundup_cents, eligibility_status FROM roundup_events
             WHERE transaction_id = $1 AND rule_version = $2`,
            [row.id, roundupEval.rule_version]
          );
          if (priorEvent.rows.length === 0) {
            // No prior roundup_events row exists for this transaction yet
            // (e.g. synced once before Round-Up rules existed, or a prior
            // sync's write failed) â€” treat as a first-time evaluation.
            await applyRoundupEvent(client, item.user_id, row.account_id, row.id, roundupEval);
          } else {
            const prior = priorEvent.rows[0];
            if (prior.roundup_cents !== roundupEval.roundup_cents ||
                prior.eligibility_status !== roundupEval.eligibility_status) {
              const { dataQualityFlag } = await applyRoundupCorrection(
                client, item.user_id, prior.id, row.account_id,
                prior.roundup_cents, roundupEval.roundup_cents,
                roundupEval.eligibility_status, roundupEval.eligibility_reason,
                'transaction_modified'
              );
              if (dataQualityFlag) pendingDataQualityFlags.push(dataQualityFlag);
            }
            // else: the modified transaction's change didn't affect the
            // Round-Up outcome (e.g. merchant name changed, amount didn't) â€”
            // nothing to correct.
          }
        }
      }

      // Removed: Plaid sends transaction_id references for deletions.
      for (const rem of removed) {
        await client.query(
          `UPDATE transactions SET removed_at = now(), removal_reason = 'plaid_removed'
           WHERE plaid_transaction_id = $1 AND user_id = $2`,
          [rem.transaction_id, item.user_id]
        );
      }

      await client.query(
        `UPDATE plaid_items SET cursor = $1, last_synced_at = now(), updated_at = now() WHERE id = $2`,
        [nextCursor, item.id]
      );
    });

    await db.withUserContext(item.user_id, (client) => client.query(
      `UPDATE sync_runs SET status='completed', added_count=$1, modified_count=$2,
         removed_count=$3, finished_at=now() WHERE id=$4`,
      [added.length, modified.length, removed.length, syncRunId]
    ));

    // v4.3: any dataQualityFlag returned by applyRoundupCorrection above must
    // be written under withServiceRole(), not the withUserContext connection
    // it was produced on â€” data_quality_events is service-role-gated
    // (Section 5.10/13.1.15). Writing it inside the withUserContext
    // transaction would silently fail the same way the webhook pipeline did
    // before that fix.
    for (const flag of pendingDataQualityFlags) {
      await db.withServiceRole((sysClient) => sysClient.query(
        `INSERT INTO data_quality_events (user_id, issue_type, entity_type, entity_id, details)
         VALUES ($1, $2, $3, $4, $5)`,
        [item.user_id, flag.issueType, flag.entityType, flag.entityId, JSON.stringify(flag.details)]
      ));
    }

    return { added: added.length, modified: modified.length, removed: removed.length };
  } catch (err) {
    await db.withUserContext(item.user_id, (client) => client.query(
      `UPDATE sync_runs SET status='failed', error_message=$1, finished_at=now() WHERE id=$2`,
      [String(err.message || err), syncRunId]
    ));
    throw err;
  }
}

module.exports = { runSync };
```
Note: `detectTransferPair` is imported from `../intelligence/transfer-detection`, matching Section 9.6's module. The two-pass income resolution's pass 2 (re-running `classify()` against `PENDING_INCOME_REVIEW` rows once `income_signals` has been recomputed) is `jobs/incomeReview.js`, Section 8.14 â€” no longer just described, now an actual module.

## 8.11 `src/routes/me.js` â€” authenticated user's own data

```javascript
const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('../auth/auth');

router.use(authMiddleware);

router.get('/me', async (req, res) => {
  const result = await db.withUserContext(req.userId, (client) =>
    client.query('SELECT id, email, created_at FROM users WHERE id = $1', [req.userId])
  );
  if (result.rows.length === 0) return res.status(404).json({ status: 'error', code: 'USER_NOT_FOUND' });
  res.json({ status: 'ok', user: result.rows[0] });
});

router.get('/me/accounts', async (req, res) => {
  const result = await db.withUserContext(req.userId, (client) =>
    client.query(
      `SELECT id, name, official_name, mask, type, subtype, current_balance_cents,
              available_balance_cents, iso_currency_code
       FROM accounts WHERE user_id = $1 ORDER BY created_at ASC`,
      [req.userId]
    )
  );
  res.json({ status: 'ok', accounts: result.rows });
});

router.get('/me/net-worth', async (req, res) => {
  const result = await db.withUserContext(req.userId, (client) =>
    client.query(
      `SELECT * FROM net_worth_snapshots WHERE user_id = $1 ORDER BY as_of_date DESC LIMIT 1`,
      [req.userId]
    )
  );
  res.json({ status: 'ok', netWorth: result.rows[0] || null });
});

router.get('/me/roundups', async (req, res) => {
  const result = await db.withUserContext(req.userId, (client) =>
    client.query(
      `SELECT ra.account_id, ra.total_cents, ra.updated_at
       FROM roundup_accumulators ra WHERE ra.user_id = $1`,
      [req.userId]
    )
  );
  res.json({ status: 'ok', accumulators: result.rows });
});

module.exports = router;
```

## 8.12 `src/routes/link.js` â€” Plaid Link token lifecycle

```javascript
const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('../auth/auth');
const plaid = require('../providers/plaid/adapter');
router.use(authMiddleware);

// Products/optional_products per Section 0.1's closed decision.
router.post('/link/token/create', async (req, res) => {
  const data = await plaid.createLinkToken(req.userId);
  res.json({ status: 'ok', linkToken: data.link_token });
});

router.post('/link/token/exchange', async (req, res) => {
  const { publicToken } = req.body;
  if (!publicToken) return res.status(400).json({ status: 'error', code: 'MISSING_PUBLIC_TOKEN' });

  const connected = await plaid.connectItem(publicToken);

  await db.withUserContext(req.userId, async (client) => {
    const itemInsert = await client.query(
      `INSERT INTO plaid_items (user_id, plaid_item_id, plaid_access_token_encrypted, institution_id, institution_name, status)
       VALUES ($1,$2,$3,$4,$5,'active') RETURNING id`,
      [req.userId, connected.itemId, connected.accessTokenEncrypted, connected.institutionId, connected.institutionName]
    );
    const plaidItemRowId = itemInsert.rows[0].id;

    const accounts = await plaid.syncAccounts(connected.accessTokenEncrypted);
    for (const a of accounts) {
      await client.query(
        `INSERT INTO accounts
           (user_id, plaid_item_id, plaid_account_id, name, official_name, mask, type, subtype,
            current_balance_cents, available_balance_cents, balance_as_of, iso_currency_code)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now(),$11)
         ON CONFLICT (plaid_account_id) DO UPDATE SET
           current_balance_cents = $9, available_balance_cents = $10, balance_as_of = now(), updated_at = now()`,
        [req.userId, plaidItemRowId, a.plaidAccountId, a.name, a.officialName, a.mask, a.type,
         a.subtype, a.currentBalanceCents, a.availableBalanceCents, a.isoCurrencyCode]
      );
    }

    for (const domain of ['transactions', 'liabilities', 'investments', 'identity']) {
      await client.query(
        `INSERT INTO provider_capabilities (plaid_item_id, domain, requested, consented)
         VALUES ($1, $2, true, true)
         ON CONFLICT (plaid_item_id, domain) DO UPDATE SET consented = true`,
        [plaidItemRowId, domain]
      );
    }
  });

  res.json({ status: 'ok', itemId: connected.itemId });
});

module.exports = router;
```

## 8.13 `src/jobs/reconciliation.js` â€” periodic invariant checks

```javascript
const db = require('../db');

// Writes to reconciliation_runs (Section 5.9), which is service-role-gated
// (Section 5.10) â€” must run under withServiceRole, per the same RLS fix as 8.5.
async function reconcileRoundupAccumulators() {
  return db.withServiceRole(async (client) => {
    const { rows: accumulators } = await client.query('SELECT id, account_id, total_cents FROM roundup_accumulators');
    let mismatches = 0;

    for (const acc of accumulators) {
      const expected = await client.query(
        `SELECT COALESCE(SUM(re.roundup_cents), 0) AS total
         FROM roundup_events re WHERE re.transaction_id IN (
           SELECT id FROM transactions WHERE account_id = $1
         ) AND re.eligibility_status = 'eligible'`,
        [acc.account_id]
      );
      const expectedCents = Number(expected.rows[0].total);
      const status = expectedCents === Number(acc.total_cents) ? 'ok' : 'mismatch';
      if (status === 'mismatch') mismatches++;

      await client.query(
        `INSERT INTO reconciliation_runs (scope, status, expected_value_cents, actual_value_cents, details)
         VALUES ('roundup_accumulator', $1, $2, $3, $4)`,
        [status, expectedCents, acc.total_cents, JSON.stringify({ accountId: acc.account_id })]
      );
    }
    return { checked: accumulators.length, mismatches };
  });
}

module.exports = { reconcileRoundupAccumulators };
```

## 8.14 `src/jobs/incomeReview.js` â€” pass 2 of two-pass income classification

v4.3 addition: closes gap 2 from the second audit pass. `classify.js` (8.6) rule 8 defers an ambiguous negative-amount transaction to `PENDING_INCOME_REVIEW` in pass 1 (`sync.js`, 8.10) rather than guessing. This job is pass 2 â€” it recomputes `income_signals` against the user's current posted history, then re-classifies every `PENDING_INCOME_REVIEW` row against those signals. Intended to run on a schedule (e.g. after each sync batch, or on its own periodic cadence), not inline in the webhook-latency path â€” the same reasoning Section 8.6's original two-pass design already gave for keeping this out of `sync.js`.

```javascript
const db = require('../db');
const { classify } = require('../classification/classify');
const { detectIncomeSignals } = require('../intelligence/income');

async function resolveIncomeMatch(client, userId, merchantName) {
  const { rows } = await client.query(
    `SELECT confidence FROM income_signals
     WHERE user_id = $1
       AND (source_merchant = $2 OR ($2::text IS NULL AND source_merchant IS NULL))
       AND cadence != 'irregular'`,
    [userId, merchantName]
  );
  if (rows.length === 0) return { matched: false, confidence: 0 };
  return { matched: true, confidence: Number(rows[0].confidence) };
}

async function runIncomeReview(userId) {
  return db.withUserContext(userId, async (client) => {
    // Recompute income_signals against current posted history first, so this
    // pass's lookups reflect anything synced since the last review.
    await detectIncomeSignals(client, userId);

    const { rows: pending } = await client.query(
      `SELECT t.id, t.amount_cents, t.merchant_name, t.provider_category, t.account_id, a.type AS account_type
       FROM transactions t
       JOIN transaction_classifications tc ON tc.transaction_id = t.id
         AND tc.classification_version = 'classification_v1'
       JOIN accounts a ON a.id = t.account_id
       WHERE t.user_id = $1 AND tc.classification = 'PENDING_INCOME_REVIEW' AND t.removed_at IS NULL`,
      [userId]
    );

    let resolvedToIncome = 0, resolvedToUnknown = 0;
    for (const tx of pending) {
      const signalMatch = await resolveIncomeMatch(client, userId, tx.merchant_name);
      const classification = classify(
        { amount_cents: tx.amount_cents, provider_category: tx.provider_category,
          merchant_name: tx.merchant_name, account_type: tx.account_type },
        { priorPurchaseMatch: false, transferMatch: false, transferConfidence: 0,
          isPaymentNotPurchase: false, incomeSignalMatch: signalMatch.matched,
          incomeConfidence: signalMatch.confidence, incomePhase: 'resolved' }
      );
      await client.query(
        `UPDATE transaction_classifications SET classification = $2, confidence = $3, evidence = $4
         WHERE transaction_id = $1 AND classification_version = $5`,
        [tx.id, classification.classification, classification.confidence,
         classification.evidence, classification.classification_version]
      );
      if (classification.classification === 'INCOME') resolvedToIncome++;
      else resolvedToUnknown++;
      // Not re-evaluating Round-Up here deliberately: both PENDING_INCOME_REVIEW
      // and its two possible resolutions (INCOME, UNKNOWN) are in
      // INELIGIBLE_CLASSIFICATIONS (8.7), and the underlying amount_cents is
      // negative in every case, which evaluateRoundup already excludes on its
      // own (`amount_cents <= 0`). There is no Round-Up eligibility change this
      // resolution step could produce.
    }
    return { reviewed: pending.length, resolvedToIncome, resolvedToUnknown };
  });
}

// Convenience wrapper for a scheduled job running across all users with at
// least one PENDING_INCOME_REVIEW row, rather than requiring the caller to
// enumerate users itself.
async function runIncomeReviewForAllPendingUsers() {
  const { rows: userIds } = await db.query(
    `SELECT DISTINCT t.user_id FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE tc.classification = 'PENDING_INCOME_REVIEW' AND t.removed_at IS NULL`
  );
  const results = [];
  for (const { user_id } of userIds) {
    results.push({ userId: user_id, ...(await runIncomeReview(user_id)) });
  }
  return results;
}

module.exports = { runIncomeReview, runIncomeReviewForAllPendingUsers, resolveIncomeMatch };
```
Note: the top-level `SELECT DISTINCT ... FROM transactions` in `runIncomeReviewForAllPendingUsers` runs on the plain pool (`db.query`), not `withUserContext` or `withServiceRole` â€” `transactions` has an owner-only RLS policy (Section 5.10) keyed on `app.current_user_id`, which isn't set on the plain pool connection. In practice this means that call will return zero rows under RLS rather than erroring, which silently breaks the "for all users" wrapper. **This is intentionally called out, not fixed here** â€” enumerating all users' `user_id`s bypassing RLS is exactly the kind of service-role-adjacent operation that needs the same explicit trust-boundary reasoning as `withServiceRole()`, and deciding whether that enumeration itself should be service-role-gated (a new policy) or done a different way (e.g. iterating `plaid_items` under a scheduled job's own service identity) is a real design decision, not a one-line fix. Until that's resolved, call `runIncomeReview(userId)` directly per known user rather than relying on `runIncomeReviewForAllPendingUsers()`.

---

# 9. INTELLIGENCE ENGINES (calculations, still versioned/evidence-backed)

v4.2 note: v4.1 specified these five engines as SQL-shaped prose only â€” no actual JS function bodies existed in Section 8, even though Section 12's repository structure names an `intelligence/` directory. Each subsection below now has both the calculation shape (unchanged) and an actual `src/intelligence/*` module implementing it.

## 9.1 Cash-flow (`cash_flow_v1`)
```sql
income_cents   = SUM(amount_cents) WHERE classification = 'INCOME'
spending_cents = SUM(amount_cents) WHERE classification = 'PURCHASE'
transfer_cents = SUM(amount_cents) WHERE classification IN ('TRANSFER_IN','TRANSFER_OUT')  -- tracked, excluded from spend/income
fee_cents      = SUM(amount_cents) WHERE classification = 'FEE'
```
One `cash_flow_periods` row per (user, period, version).

`src/intelligence/cash-flow/index.js`:
```javascript
const CALC_VERSION = 'cash_flow_v1';

async function computeCashFlowPeriod(client, userId, periodStart, periodEnd) {
  const { rows } = await client.query(
    `SELECT tc.classification, SUM(t.amount_cents) AS total
     FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE t.user_id = $1 AND t.posted_date BETWEEN $2 AND $3 AND t.removed_at IS NULL
     GROUP BY tc.classification`,
    [userId, periodStart, periodEnd]
  );

  const totals = Object.fromEntries(rows.map((r) => [r.classification, Number(r.total)]));
  const income = totals.INCOME || 0;
  const spending = totals.PURCHASE || 0;
  const transfers = (totals.TRANSFER_IN || 0) + (totals.TRANSFER_OUT || 0);
  const fees = totals.FEE || 0;

  await client.query(
    `INSERT INTO cash_flow_periods
       (user_id, period_start, period_end, income_cents, spending_cents, transfer_cents, fee_cents, calculation_version)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     ON CONFLICT (user_id, period_start, period_end, calculation_version)
     DO UPDATE SET income_cents = $4, spending_cents = $5, transfer_cents = $6, fee_cents = $7, computed_at = now()`,
    [userId, periodStart, periodEnd, income, spending, transfers, fees, CALC_VERSION]
  );

  return { income, spending, transfers, fees };
}

module.exports = { computeCashFlowPeriod, CALC_VERSION };
```

## 9.2 Income detection (`income_v1`)
Group posted, non-transfer-matched transactions by merchant; test for cadence (weekly: ~7Â±2 days between occurrences; biweekly: ~14Â±3; monthly: ~30Â±5) with amount variance under 15%. Write `income_signals`. `cadence='irregular'` â†’ `next_expected_date` stays `NULL`, enforced by the write path itself.

`src/intelligence/income/index.js`:
```javascript
const CALC_VERSION = 'income_v1';

function classifyCadence(gapDays) {
  if (gapDays >= 5 && gapDays <= 9) return 'weekly';
  if (gapDays >= 11 && gapDays <= 17) return 'biweekly';
  if (gapDays >= 25 && gapDays <= 35) return 'monthly';
  return 'irregular';
}

function amountVarianceOk(amounts) {
  const mean = amounts.reduce((a, b) => a + b, 0) / amounts.length;
  if (mean === 0) return false;
  return amounts.every((a) => Math.abs(a - mean) / mean < 0.15);
}

async function detectIncomeSignals(client, userId) {
  const { rows } = await client.query(
    `SELECT t.merchant_name AS merchant, t.amount_cents, t.posted_date
     FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE t.user_id = $1 AND t.amount_cents < 0
       AND tc.classification NOT IN ('TRANSFER_IN','TRANSFER_OUT')
       AND t.removed_at IS NULL
     ORDER BY t.merchant_name, t.posted_date ASC`,
    [userId]
  );

  const byMerchant = new Map();
  for (const row of rows) {
    const key = row.merchant || null;
    if (!byMerchant.has(key)) byMerchant.set(key, []);
    byMerchant.get(key).push(row);
  }

  const results = [];
  for (const [merchant, occurrences] of byMerchant) {
    if (occurrences.length < 2) continue;
    const gaps = [];
    for (let i = 1; i < occurrences.length; i++) {
      const days = (new Date(occurrences[i].posted_date) - new Date(occurrences[i - 1].posted_date)) / 86400000;
      gaps.push(days);
    }
    const avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
    const cadence = classifyCadence(avgGap);
    const amounts = occurrences.map((o) => Math.abs(Number(o.amount_cents)));
    const varianceOk = amountVarianceOk(amounts);
    if (cadence === 'irregular' || !varianceOk) continue;

    const last = occurrences[occurrences.length - 1];
    const cadenceDays = { weekly: 7, biweekly: 14, monthly: 30 }[cadence];
    const nextExpected = new Date(last.posted_date);
    nextExpected.setDate(nextExpected.getDate() + cadenceDays);
    const avgAmount = Math.round(amounts.reduce((a, b) => a + b, 0) / amounts.length);

    await client.query(
      `INSERT INTO income_signals
         (user_id, source_merchant, cadence, average_amount_cents, last_detected_date,
          next_expected_date, confidence, evidence_state, calculation_version)
       VALUES ($1,$2,$3,$4,$5,$6,$7,'observed',$8)
       ON CONFLICT (user_id, source_merchant) WHERE source_merchant IS NOT NULL
       DO UPDATE SET cadence=$3, average_amount_cents=$4, last_detected_date=$5,
         next_expected_date=$6, confidence=$7, updated_at=now()`,
      [userId, merchant, cadence, avgAmount, last.posted_date,
       cadence === 'irregular' ? null : nextExpected.toISOString().slice(0, 10),
       Math.min(0.95, 0.5 + occurrences.length * 0.05), CALC_VERSION]
    );
    results.push({ merchant, cadence, avgAmount });
  }
  return results;
}

module.exports = { detectIncomeSignals, classifyCadence, amountVarianceOk, CALC_VERSION };
```
This engine feeds `context.incomeSignalMatch` in the two-pass classification flow described under Section 8.6 â€” pass 1 defers ambiguous negative-amount transactions, this runs against posted history, pass 2 resolves them.

## 9.3 Recurring streams (`recurring_v1`)
Same cadence-detection logic as 9.2, generalized to any merchant/stream type (bills, subscriptions), writing `recurring_streams`. `stream_type` (`'bill' | 'subscription' | 'other'`) is classified from `personal_finance_category` where available, defaulting to `'other'` when the category is absent â€” never guessed from merchant name alone.

**v4.3 status: APPLIED.** v4.2 described this section in prose only ("implementation reuses...") with no corresponding module â€” this closes that gap, along with the related gap that `merchants`/`merchant_aliases` (Section 5.5) were defined in schema but never written to by any code. `recurring_streams.merchant_id` is a foreign key into `merchants`, so this engine needs a merchant resolver; that resolver is new too.

`src/intelligence/merchant/resolve.js`:
```javascript
// Resolves a Plaid merchant_name string to a stable merchants.id, creating
// the merchant + alias rows on first sight. Phase 1 has no external
// merchant-normalization data source (e.g. a name-matching/dedup service),
// so the provider's merchant_name is treated as the canonical name too â€”
// this is a stated, honest default, not a guess at a "real" canonical name
// nothing in this system actually has evidence for. If two different Plaid
// merchant_name strings that are really the same business need to be
// unified later, that requires an actual dedup pass against merchant_aliases,
// which is out of scope here.
async function resolveMerchantId(client, providerMerchantName) {
  if (!providerMerchantName) return null;

  const alias = await client.query(
    `SELECT merchant_id FROM merchant_aliases WHERE provider_merchant_name = $1`,
    [providerMerchantName]
  );
  if (alias.rows.length > 0) return alias.rows[0].merchant_id;

  const merchant = await client.query(
    `INSERT INTO merchants (canonical_name) VALUES ($1)
     ON CONFLICT (canonical_name) DO UPDATE SET canonical_name = merchants.canonical_name
     RETURNING id`,
    [providerMerchantName]
  );
  const merchantId = merchant.rows[0].id;

  await client.query(
    `INSERT INTO merchant_aliases (merchant_id, provider_merchant_name)
     VALUES ($1, $2) ON CONFLICT (provider_merchant_name) DO NOTHING`,
    [merchantId, providerMerchantName]
  );
  return merchantId;
}

module.exports = { resolveMerchantId };
```

`src/intelligence/recurring/index.js`:
```javascript
const { classifyCadence, amountVarianceOk } = require('../income');
const { resolveMerchantId } = require('../merchant/resolve');

const CALC_VERSION = 'recurring_v1';

function inferStreamType(personalFinanceCategory) {
  if (!personalFinanceCategory) return 'other';
  const cat = personalFinanceCategory.toLowerCase();
  if (cat.includes('subscription')) return 'subscription';
  if (cat.includes('bill') || cat.includes('utilit') || cat.includes('rent') || cat.includes('loan')) return 'bill';
  return 'other';
}

async function detectRecurringStreams(client, userId) {
  const { rows } = await client.query(
    `SELECT t.merchant_name, t.amount_cents, t.posted_date, t.provider_category
     FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE t.user_id = $1 AND t.removed_at IS NULL
       AND tc.classification NOT IN ('TRANSFER_IN', 'TRANSFER_OUT', 'INCOME', 'PENDING_INCOME_REVIEW')
     ORDER BY t.merchant_name, t.posted_date ASC`,
    [userId]
  );

  const byMerchant = new Map();
  for (const row of rows) {
    if (!row.merchant_name) continue; // recurring_streams.merchant_id can't be resolved for an unnamed merchant â€” excluded, not guessed
    if (!byMerchant.has(row.merchant_name)) byMerchant.set(row.merchant_name, []);
    byMerchant.get(row.merchant_name).push(row);
  }

  const results = [];
  for (const [merchantName, occurrences] of byMerchant) {
    if (occurrences.length < 2) continue;
    const gaps = [];
    for (let i = 1; i < occurrences.length; i++) {
      const days = (new Date(occurrences[i].posted_date) - new Date(occurrences[i - 1].posted_date)) / 86400000;
      gaps.push(days);
    }
    const avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
    const cadence = classifyCadence(avgGap);
    const amounts = occurrences.map((o) => Math.abs(Number(o.amount_cents)));
    if (cadence === 'irregular' || !amountVarianceOk(amounts)) continue;

    const merchantId = await resolveMerchantId(client, merchantName);
    const last = occurrences[occurrences.length - 1];
    const cadenceDays = { weekly: 7, biweekly: 14, monthly: 30 }[cadence];
    const nextExpected = new Date(last.posted_date);
    nextExpected.setDate(nextExpected.getDate() + cadenceDays);
    const avgAmount = Math.round(amounts.reduce((a, b) => a + b, 0) / amounts.length);
    const variance = Math.round(Math.sqrt(amounts.reduce((s, a) => s + (a - avgAmount) ** 2, 0) / amounts.length));
    const streamType = inferStreamType(last.provider_category);

    await client.query(
      `INSERT INTO recurring_streams
         (user_id, merchant_id, stream_type, cadence, average_amount_cents, amount_variance_cents,
          last_observed_date, next_expected_date, confidence, calculation_version)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       ON CONFLICT (user_id, merchant_id, stream_type) DO UPDATE SET
         cadence = $4, average_amount_cents = $5, amount_variance_cents = $6,
         last_observed_date = $7, next_expected_date = $8, confidence = $9, updated_at = now()`,
      [userId, merchantId, streamType, cadence, avgAmount, variance,
       last.posted_date, nextExpected.toISOString().slice(0, 10),
       Math.min(0.95, 0.5 + occurrences.length * 0.05), CALC_VERSION]
    );
    results.push({ merchantId, streamType, cadence, avgAmount });
  }
  return results;
}

module.exports = { detectRecurringStreams, inferStreamType, CALC_VERSION };
```
`classifyCadence`/`amountVarianceOk` are imported from `../income` (Section 9.2's module) rather than duplicated â€” both modules must agree on what "weekly"/"biweekly"/"monthly"/"irregular" and "amount variance" mean, since a stream that looks like income and a stream that looks like a recurring bill are distinguished upstream by classification, not by different cadence math.

## 9.4 Net worth (`net_worth_v1`)
```sql
-- v4.2 fix (Section 13.1.2): the previous formula summed BOTH accounts.current_balance_cents
-- for investment-type accounts AND investment_holdings.institution_value_cents for the same
-- account. An investment account's current_balance_cents typically already reflects the sum
-- of its holdings' value, so adding both double-counted the same money. The fix: exclude
-- 'investment' type accounts from the balance sum entirely and rely on holdings as the sole
-- source of investment-account value.
assets      = SUM(current_balance_cents) WHERE type = 'depository'
            + SUM(institution_value_cents) FROM investment_holdings
liabilities = SUM(current_balance_cents) WHERE type IN ('credit','loan')
net_worth   = assets - liabilities
```
`included_domains`/`missing_domains` populated from `provider_capabilities` â€” if Liabilities hasn't had a `last_successful_sync_at`, it goes in `missing_domains` and `evidence_state='limited'`.

`src/intelligence/net-worth/index.js`:
```javascript
const CALC_VERSION = 'net_worth_v1';

async function computeNetWorthSnapshot(client, userId, asOfDate) {
  const depository = await client.query(
    `SELECT COALESCE(SUM(current_balance_cents), 0) AS total FROM accounts
     WHERE user_id = $1 AND type = 'depository'`,
    [userId]
  );
  const holdings = await client.query(
    `SELECT COALESCE(SUM(institution_value_cents), 0) AS total FROM investment_holdings
     WHERE user_id = $1`,
    [userId]
  );
  const liabilities = await client.query(
    `SELECT COALESCE(SUM(current_balance_cents), 0) AS total FROM accounts
     WHERE user_id = $1 AND type IN ('credit','loan')`,
    [userId]
  );
  const capabilities = await client.query(
    `SELECT domain, last_successful_sync_at FROM provider_capabilities pc
     JOIN plaid_items pi ON pi.id = pc.plaid_item_id
     WHERE pi.user_id = $1`,
    [userId]
  );

  const missingDomains = capabilities.rows
    .filter((c) => !c.last_successful_sync_at)
    .map((c) => c.domain);
  const includedDomains = capabilities.rows
    .filter((c) => c.last_successful_sync_at)
    .map((c) => c.domain);

  const assets = Number(depository.rows[0].total) + Number(holdings.rows[0].total);
  const liabilitiesTotal = Number(liabilities.rows[0].total);
  const netWorth = assets - liabilitiesTotal;
  const evidenceState = missingDomains.length > 0 ? 'limited' : 'calculated';

  await client.query(
    `INSERT INTO net_worth_snapshots
       (user_id, as_of_date, assets_cents, liabilities_cents, net_worth_cents,
        included_domains, missing_domains, evidence_state, calculation_version)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (user_id, as_of_date, calculation_version)
     DO UPDATE SET assets_cents=$3, liabilities_cents=$4, net_worth_cents=$5,
       included_domains=$6, missing_domains=$7, evidence_state=$8, computed_at=now()`,
    [userId, asOfDate, assets, liabilitiesTotal, netWorth,
     includedDomains, missingDomains, evidenceState, CALC_VERSION]
  );

  return { assets, liabilities: liabilitiesTotal, netWorth, evidenceState, missingDomains };
}

module.exports = { computeNetWorthSnapshot, CALC_VERSION };
```

## 9.5 Liquidity, fees, financial health
Liquidity: `SUM(current_balance_cents) WHERE type='depository'` against `recurring_streams WHERE stream_type='bill' AND next_expected_date <= now() + 30 days`. Fees: only counted when a real transaction is classified `FEE` â€” never inferred from a published fee schedule. Financial-health signals combine the above per `financial_health_signals`, always evidence-backed, never medicalized/moralized framing.

**v4.3 status: partially APPLIED.** v4.2 only implemented the liquidity signal below; fees had no code. This version adds `computeFeeSignal`. The "combination" described in the prose above â€” liquidity and fees rolled into one financial-health read â€” is **deliberately still not implemented**: combining two independent signals into a single number requires a scoring methodology (weights, thresholds, what counts as "healthy") that hasn't actually been decided, and inventing one now to make this section look complete would be exactly the kind of fabricated-framework-dressed-as-fact this document's own standards rule out. Each signal is written to `financial_health_signals` as its own row (`signal_type = 'liquidity_buffer_30d'`, `signal_type = 'fees_30d'`); a future `financial_health_composite_v1` can be added once that methodology is actually decided, not defaulted here.

`src/intelligence/liquidity/index.js` (health module reuses this shape per signal type):
```javascript
async function computeLiquiditySignal(client, userId) {
  const balance = await client.query(
    `SELECT COALESCE(SUM(current_balance_cents), 0) AS total FROM accounts
     WHERE user_id = $1 AND type = 'depository'`,
    [userId]
  );
  const upcomingBills = await client.query(
    `SELECT COALESCE(SUM(average_amount_cents), 0) AS total FROM recurring_streams
     WHERE user_id = $1 AND stream_type = 'bill'
       AND next_expected_date <= (CURRENT_DATE + INTERVAL '30 days')`,
    [userId]
  );

  const liquidCents = Number(balance.rows[0].total);
  const upcomingCents = Number(upcomingBills.rows[0].total);
  const bufferCents = liquidCents - upcomingCents;

  await client.query(
    `INSERT INTO financial_health_signals (user_id, signal_type, value, evidence_state, calculation_version)
     VALUES ($1, 'liquidity_buffer_30d', $2, 'calculated', 'liquidity_v1')
     ON CONFLICT (user_id, signal_type, calculation_version)
     DO UPDATE SET value = $2, computed_at = now()`,
    [userId, bufferCents]
  );

  return { liquidCents, upcomingCents, bufferCents };
}

// v4.3 addition: fees were named in the Section 9.5 prose ("only counted
// when a real transaction is classified FEE") but had no corresponding code
// in v4.2. This sums actual FEE-classified transactions over the given
// period â€” never a published/estimated fee schedule, per that same rule.
async function computeFeeSignal(client, userId, periodStart, periodEnd) {
  const { rows } = await client.query(
    `SELECT COALESCE(SUM(t.amount_cents), 0) AS total
     FROM transactions t
     JOIN transaction_classifications tc ON tc.transaction_id = t.id
       AND tc.classification_version = 'classification_v1'
     WHERE t.user_id = $1 AND tc.classification = 'FEE' AND t.removed_at IS NULL
       AND t.posted_date BETWEEN $2 AND $3`,
    [userId, periodStart, periodEnd]
  );
  const feeCents = Number(rows[0].total);

  await client.query(
    `INSERT INTO financial_health_signals (user_id, signal_type, value, evidence_state, calculation_version)
     VALUES ($1, 'fees_30d', $2, 'observed', 'fee_v1')
     ON CONFLICT (user_id, signal_type, calculation_version)
     DO UPDATE SET value = $2, computed_at = now()`,
    [userId, feeCents]
  );

  return { feeCents };
}

module.exports = { computeLiquiditySignal, computeFeeSignal };
```

## 9.6 Transfer detection (implements Section 13.1.9's contract)

`src/intelligence/transfer-detection/index.js`. `transaction_relationships` (Section 5.5) needs an explicit detector, not just a table. This is a first pass covering same-Item and cross-Item transfers by amount/date matching; the full contract in 13.1.9 (ACH, P2P, credit-card payments, one-sided visibility, etc.) requires categories only resolvable once live transaction data and `personal_finance_category` values are available, and is intentionally left to extend this function rather than guessed here.

```javascript
const TEMPORAL_TOLERANCE_DAYS = 3;

async function detectTransferPair(client, userId, transaction) {
  const { rows } = await client.query(
    `SELECT id FROM transactions
     WHERE user_id = $1 AND id != $2
       AND amount_cents = $3
       AND posted_date BETWEEN $4::date - $5::int AND $4::date + $5::int
       AND removed_at IS NULL`,
    [userId, transaction.id, -transaction.amount_cents, transaction.posted_date, TEMPORAL_TOLERANCE_DAYS]
  );
  if (rows.length === 0) return null;

  const otherId = rows[0].id;
  // Canonical ordering per Section 5.5's CHECK constraint.
  const [a, b] = transaction.id < otherId ? [transaction.id, otherId] : [otherId, transaction.id];

  await client.query(
    `INSERT INTO transaction_relationships (transaction_id_a, transaction_id_b, relationship_type, confidence, detected_by)
     VALUES ($1, $2, 'transfer_pair', 0.75, 'amount_date_match_v1')
     ON CONFLICT (transaction_id_a, transaction_id_b, relationship_type) DO NOTHING`,
    [a, b]
  );
  return { transactionIdA: a, transactionIdB: b };
}

module.exports = { detectTransferPair };
```

---

# 10. TESTING (matrices unchanged in substance, now backed by the code above)

**Webhook:** valid ES256; wrong alg; missing/unknown kid; stale iat (>5min); missing/wrong body hash; duplicate (idempotency_key blocks reprocessing); malformed JWT. Test directly against `verifyPlaidWebhook()` (8.4) with hand-constructed JWTs, not just live Sandbox traffic.

**Round-Up:** `$0.00, $0.01, $0.99, $1.00, $1.01, $1.99, $799.99, $800.00, $800.01`; every `INELIGIBLE_CLASSIFICATIONS` entry; duplicate processing (DB `UNIQUE` catches it via `ON CONFLICT DO NOTHING`, verify accumulator doesn't move); correction from $0.37â†’$0.42 moves accumulator by exactly +$0.05 (test `applyRoundupCorrection` directly).

**RLS:** for every table in Section 5.10, create two users, insert rows for each, and assert user A's `withUserContext` connection cannot see/modify user B's rows â€” including the join-based indirect policies (`roundup_line_items`, `provider_capabilities`, `transaction_classifications`, `transaction_relationships`, `roundup_corrections`), which are exactly where a missed policy is easy to miss in review.

**Classification:** the two-pass income resolution (8.6) specifically â€” construct a fixture with an ambiguous negative-amount transaction, verify it's `UNKNOWN`/pending after pass 1 and correctly resolved after pass 2, not silently misclassified in a single pass.

---

# 11. PLAID SANDBOX TESTING â€” LITERAL COMMANDS

## 11.1 Create a sandbox item directly (bypassing Link UI, for fixture-driven tests)

```bash
curl -X POST https://sandbox.plaid.com/sandbox/public_token/create \
  -H 'Content-Type: application/json' \
  -d '{
    "client_id": "'"$PLAID_CLIENT_ID"'",
    "secret": "'"$PLAID_SECRET"'",
    "institution_id": "ins_109508",
    "initial_products": ["transactions"]
  }'
# -> { "public_token": "public-sandbox-...", ... }
```

```bash
curl -X POST https://sandbox.plaid.com/item/public_token/exchange \
  -H 'Content-Type: application/json' \
  -d '{
    "client_id": "'"$PLAID_CLIENT_ID"'",
    "secret": "'"$PLAID_SECRET"'",
    "public_token": "public-sandbox-..."
  }'
# -> { "access_token": "access-sandbox-...", "item_id": "..." }
```

## 11.2 Fire a webhook manually to test the verification pipeline (Section 8.4/8.5)

```bash
curl -X POST https://sandbox.plaid.com/sandbox/item/fire_webhook \
  -H 'Content-Type: application/json' \
  -d '{
    "client_id": "'"$PLAID_CLIENT_ID"'",
    "secret": "'"$PLAID_SECRET"'",
    "access_token": "access-sandbox-...",
    "webhook_code": "DEFAULT_UPDATE",
    "webhook_type": "TRANSACTIONS"
  }'
```
Then check `plaid_webhook_events` for a row with `verification_status='verified'` and `processing_status='processed'`. Fire the identical request a second time and confirm no second row is inserted (idempotency).

## 11.3 Custom fixture data (for exact-amount Round-Up test cases)

```bash
curl -X POST https://sandbox.plaid.com/sandbox/public_token/create \
  -H 'Content-Type: application/json' \
  -d '{
    "client_id": "'"$PLAID_CLIENT_ID"'",
    "secret": "'"$PLAID_SECRET"'",
    "institution_id": "ins_109508",
    "initial_products": ["transactions"],
    "options": {
      "override_username": "user_custom",
      "override_password": "{\"override_accounts\":[{\"type\":\"depository\",\"subtype\":\"checking\",\"transactions\":[{\"date_transacted\":\"2026-08-01\",\"date_posted\":\"2026-08-01\",\"amount\":1.01,\"description\":\"ROUNDUP TEST 99 CENT\"},{\"date_transacted\":\"2026-08-02\",\"date_posted\":\"2026-08-02\",\"amount\":800.01,\"description\":\"ROUNDUP TEST OVER THRESHOLD\"}]}]}"
    }
  }'
```
Use this pattern to construct every case in Section 10's Round-Up matrix as a real Sandbox fixture rather than only unit-testing `evaluateRoundup()` in isolation â€” both are needed; the unit test proves the function is correct, the fixture proves the whole pipeline (sync â†’ classify â†’ round-up â†’ accumulator) wires together correctly.

## 11.4 Sandbox-vs-Production caveats

Sandbox does not reproduce institution-specific pending-transaction behavior or transaction-history limits â€” don't finalize the `pending=false`-only Round-Up default (Section 8.7) using only Sandbox data; validate against a real Trial-plan or Production connection before considering it final. All Sandbox OAuth institutions render through one generic Plaid OAuth flow, so OAuth-specific UI edge cases need a non-Sandbox test.

---

# 12. REPOSITORY STRUCTURE

```
apps/api/src/
  auth/                crypto.js (8.1), auth.js (8.2)
  db.js                (8.3, includes withUserContext + withServiceRole)
  providers/plaid/     adapter.js (8.9) â€” nothing above this imports the Plaid SDK
  classification/      classify.js (8.6, two-pass income resolution via PENDING_INCOME_REVIEW)
  roundup/             rules.js (8.7, includes batch writer + correction/batch consistency logic)
  intelligence/        cash-flow/ (9.1), income/ (9.2), merchant/resolve.js (9.3, new in v4.3),
                        recurring/ (9.3, new in v4.3, reuses income/'s cadence helpers),
                        net-worth/ (9.4), liquidity/ (9.5, now includes computeFeeSignal;
                        financial-health signals are additional rows of the same signal_type
                        pattern, not a separate module â€” see 9.5 on the composite score NOT
                        being implemented), transfer-detection/ (9.6)
  webhooks/            plaidWebhookVerify.js (8.4)
  routes/              webhook.js (8.5), auth.js (8.2's exports mounted as routes), me.js (8.11), link.js (8.12)
  jobs/                sync.js (8.10), reconciliation.js (8.13), incomeReview.js (8.14, new in v4.3)
  scripts/             plaidSandboxSeed.js (guarded, Section 8.8)
migrations/             001_initial_schema.sql (Section 5, in order)
```
Every file named above now has a corresponding code body in this document. v4.1 left `sync.js`, the Plaid adapter, `me.js`, `link.js`, `reconciliation.js`, and all `intelligence/*` bodies unwritten; v4.2 filled those in but left five real gaps between its own changelog and its code; v4.3 (this version) closes those five plus two more found while fixing them. See Section 13.3 for the full list of what changed and what's still honestly open.

---


# 14. v4.4 DATABASE CORRECTIONS â€” MUST APPLY

The following SQL is part of the build contract and is applied to the empty database in the initial migration. It is not a later optional patch.

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Dedicated database roles are created by deployment administration with
-- generated passwords; credentials are never committed to migrations.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ibag_app') THEN
    CREATE ROLE ibag_app NOLOGIN NOINHERIT NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ibag_service') THEN
    CREATE ROLE ibag_service NOLOGIN NOINHERIT BYPASSRLS;
  END IF;
END $$;

-- The deployer creates LOGIN roles and grants membership:
-- CREATE ROLE ibag_api_login LOGIN PASSWORD '<generated-secret>';
-- GRANT ibag_app TO ibag_api_login;
-- CREATE ROLE ibag_worker_login LOGIN PASSWORD '<generated-secret>';
-- GRANT ibag_service TO ibag_worker_login;

ALTER TABLE source_observations ALTER COLUMN raw_payload DROP NOT NULL;

-- Never manufacture USD when Plaid did not supply USD.
ALTER TABLE accounts ALTER COLUMN iso_currency_code DROP NOT NULL;
ALTER TABLE accounts ALTER COLUMN iso_currency_code DROP DEFAULT;
ALTER TABLE transactions ALTER COLUMN iso_currency_code DROP NOT NULL;
ALTER TABLE transactions ALTER COLUMN iso_currency_code DROP DEFAULT;

-- Current account lifecycle.
ALTER TABLE accounts
  ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS closed_at TIMESTAMPTZ;

-- Provider state actually observed on the Item.
ALTER TABLE provider_capabilities
  ADD COLUMN IF NOT EXISTS product_enabled BOOLEAN,
  ADD COLUMN IF NOT EXISTS observed BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS last_observation_id BIGINT;

-- Full transaction lineage/canonical enrichment.
ALTER TABLE transactions
  ADD COLUMN IF NOT EXISTS merchant_entity_id TEXT,
  ADD COLUMN IF NOT EXISTS original_description TEXT,
  ADD COLUMN IF NOT EXISTS transaction_code TEXT,
  ADD COLUMN IF NOT EXISTS payment_channel TEXT,
  ADD COLUMN IF NOT EXISTS personal_finance_category JSONB,
  ADD COLUMN IF NOT EXISTS location JSONB,
  ADD COLUMN IF NOT EXISTS payment_meta JSONB,
  ADD COLUMN IF NOT EXISTS counterparties JSONB,
  ADD COLUMN IF NOT EXISTS logo_url TEXT,
  ADD COLUMN IF NOT EXISTS website TEXT,
  ADD COLUMN IF NOT EXISTS check_number TEXT,
  ADD COLUMN IF NOT EXISTS transaction_datetime TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS authorized_datetime TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS unofficial_currency_code TEXT,
  ADD COLUMN IF NOT EXISTS foreign_amount_cents BIGINT,
  ADD COLUMN IF NOT EXISTS foreign_currency_code TEXT;

CREATE INDEX IF NOT EXISTS idx_transactions_merchant_entity
  ON transactions (merchant_entity_id);
CREATE INDEX IF NOT EXISTS idx_transactions_economic_lookup
  ON transactions (account_id, posted_date, merchant_name);

-- One account may have one current liability record per liability subtype.
CREATE UNIQUE INDEX IF NOT EXISTS uq_liabilities_credit_account
  ON liabilities_credit(account_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_liabilities_student_account
  ON liabilities_student(account_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_liabilities_mortgage_account
  ON liabilities_mortgage(account_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_identity_data_account
  ON identity_data(account_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_investment_holding_account_security
  ON investment_holdings(account_id, security_id);

-- Investment fields required for current Plaid holdings detail.
ALTER TABLE investment_holdings
  ADD COLUMN IF NOT EXISTS institution_price_as_of DATE,
  ADD COLUMN IF NOT EXISTS institution_price_datetime TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS iso_currency_code TEXT,
  ADD COLUMN IF NOT EXISTS unofficial_currency_code TEXT,
  ADD COLUMN IF NOT EXISTS security_type TEXT,
  ADD COLUMN IF NOT EXISTS security_subtype TEXT,
  ADD COLUMN IF NOT EXISTS is_cash_equivalent BOOLEAN,
  ADD COLUMN IF NOT EXISTS position_type TEXT,
  ADD COLUMN IF NOT EXISTS vested_quantity NUMERIC(20,8),
  ADD COLUMN IF NOT EXISTS vested_value_cents BIGINT,
  ADD COLUMN IF NOT EXISTS tax_lots JSONB;

ALTER TABLE investment_transactions
  ADD COLUMN IF NOT EXISTS name TEXT,
  ADD COLUMN IF NOT EXISTS subtype TEXT,
  ADD COLUMN IF NOT EXISTS fees_cents BIGINT,
  ADD COLUMN IF NOT EXISTS iso_currency_code TEXT,
  ADD COLUMN IF NOT EXISTS unofficial_currency_code TEXT,
  ADD COLUMN IF NOT EXISTS cancel_transaction_id TEXT;

-- Batch snapshots must remain immutable even when the underlying event later changes.
ALTER TABLE roundup_line_items
  ADD COLUMN IF NOT EXISTS roundup_cents_snapshot BIGINT;

UPDATE roundup_line_items rli
SET roundup_cents_snapshot = re.roundup_cents
FROM roundup_events re
WHERE re.id = rli.roundup_event_id
  AND rli.roundup_cents_snapshot IS NULL;

ALTER TABLE roundup_line_items
  ALTER COLUMN roundup_cents_snapshot SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_roundup_line_items_event
  ON roundup_line_items(roundup_event_id);

CREATE UNIQUE INDEX IF NOT EXISTS uq_open_roundup_batch_per_accumulator
  ON roundup_batches(accumulator_id)
  WHERE status = 'pending';

ALTER TABLE roundup_accumulators
  ADD CONSTRAINT roundup_accumulators_nonnegative CHECK (total_cents >= 0);

ALTER TABLE roundup_batches
  ADD CONSTRAINT roundup_batches_nonnegative CHECK (total_cents >= 0);

ALTER TABLE roundup_line_items
  ADD CONSTRAINT roundup_line_items_nonnegative CHECK (roundup_cents_snapshot >= 0);

ALTER TABLE roundup_events
  ADD CONSTRAINT roundup_events_roundup_range CHECK (roundup_cents BETWEEN 0 AND 99),
  ADD CONSTRAINT roundup_events_status_check
    CHECK (eligibility_status IN ('eligible','ineligible','reversed'));

ALTER TABLE transaction_classifications
  ADD CONSTRAINT transaction_classifications_confidence_check
    CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1));

ALTER TABLE roundup_corrections
  ADD COLUMN IF NOT EXISTS old_source_amount_cents BIGINT,
  ADD COLUMN IF NOT EXISTS new_source_amount_cents BIGINT;

-- Relationship integrity: both ends of a relationship must belong to the same user.
CREATE OR REPLACE FUNCTION ibag_relationship_same_user()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE ua UUID; ub UUID;
BEGIN
  SELECT user_id INTO ua FROM transactions WHERE id = NEW.transaction_id_a;
  SELECT user_id INTO ub FROM transactions WHERE id = NEW.transaction_id_b;
  IF ua IS NULL OR ub IS NULL OR ua <> ub THEN
    RAISE EXCEPTION 'transaction relationship crosses user boundary';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_relationship_same_user ON transaction_relationships;
CREATE TRIGGER trg_relationship_same_user
BEFORE INSERT OR UPDATE ON transaction_relationships
FOR EACH ROW EXECUTE FUNCTION ibag_relationship_same_user();
```

## 14.1 Cross-user foreign-key invariants

The application must never be able to construct a child row whose `user_id` disagrees with its parent. Where a child stores both values, the migration adds composite uniqueness/FK pairs or the equivalent trigger. The following relationships are mandatory:

```text
accounts            -> plaid_items
transactions        -> accounts
roundup_events      -> transactions
roundup_accumulators-> accounts
roundup_batches     -> roundup_accumulators
roundup_line_items  -> roundup_batches AND roundup_events
liabilities_*       -> accounts
investment_*        -> accounts
identity_data       -> accounts
sync_runs           -> plaid_items
```

No user-scoped INSERT/UPDATE may be accepted if either side belongs to another user. Cross-user negative tests are mandatory for every relationship.


## 14.2 Composite parent/child integrity

Because the schema intentionally stores `user_id` redundantly for fast RLS filtering, the user ID and parent ID must be bound together at the database level.

```sql
ALTER TABLE plaid_items
  ADD CONSTRAINT uq_plaid_items_id_user UNIQUE(id,user_id);

ALTER TABLE accounts
  ADD CONSTRAINT uq_accounts_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_accounts_item_user
    FOREIGN KEY(plaid_item_id,user_id)
    REFERENCES plaid_items(id,user_id);

ALTER TABLE transactions
  ADD CONSTRAINT uq_transactions_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_transactions_account_user
    FOREIGN KEY(account_id,user_id)
    REFERENCES accounts(id,user_id);

ALTER TABLE roundup_events
  ADD CONSTRAINT uq_roundup_events_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_roundup_events_transaction_user
    FOREIGN KEY(transaction_id,user_id)
    REFERENCES transactions(id,user_id);

ALTER TABLE roundup_accumulators
  ADD CONSTRAINT uq_roundup_accumulators_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_roundup_accumulators_account_user
    FOREIGN KEY(account_id,user_id)
    REFERENCES accounts(id,user_id);

ALTER TABLE roundup_batches
  ADD CONSTRAINT uq_roundup_batches_id_user UNIQUE(id,user_id),
  ADD CONSTRAINT fk_roundup_batches_accumulator_user
    FOREIGN KEY(accumulator_id,user_id)
    REFERENCES roundup_accumulators(id,user_id);

ALTER TABLE roundup_line_items
  ADD COLUMN user_id UUID;

UPDATE roundup_line_items rli
SET user_id = rb.user_id
FROM roundup_batches rb
WHERE rb.id = rli.batch_id;

ALTER TABLE roundup_line_items
  ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE roundup_line_items
  ADD CONSTRAINT fk_roundup_line_batch_user
    FOREIGN KEY(batch_id,user_id)
    REFERENCES roundup_batches(id,user_id),
  ADD CONSTRAINT fk_roundup_line_event_user
    FOREIGN KEY(roundup_event_id,user_id)
    REFERENCES roundup_events(id,user_id);

ALTER TABLE liabilities_credit
  ADD CONSTRAINT fk_liabilities_credit_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE liabilities_student
  ADD CONSTRAINT fk_liabilities_student_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE liabilities_mortgage
  ADD CONSTRAINT fk_liabilities_mortgage_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE investment_holdings
  ADD CONSTRAINT fk_investment_holdings_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE investment_transactions
  ADD CONSTRAINT fk_investment_transactions_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE identity_data
  ADD CONSTRAINT fk_identity_data_account_user
    FOREIGN KEY(account_id,user_id) REFERENCES accounts(id,user_id);

ALTER TABLE sync_runs
  ADD CONSTRAINT fk_sync_runs_item_user
    FOREIGN KEY(plaid_item_id,user_id) REFERENCES plaid_items(id,user_id);
```

All child-row INSERT/UPDATE statements in application code MUST provide the same user ID as the parent. The composite constraints make a coding error a transaction failure instead of a cross-user data leak.

# 15. v4.4 PLAID STATE CONTRACT

Plaid's current documentation explicitly states that a pending transaction may be removed and a new posted transaction added, with `pending_transaction_id` linking the posted transaction to the removed pending transaction when Plaid can match them. Plaid also states that posted transactions can later be modified or removed. îˆ€citeîˆ‚turn1search1îˆ‚turn3search3îˆ

Therefore:

1. `added`, `modified`, and `removed` are all first-class state transitions.
2. The sync worker MUST obtain the current account set before applying transaction updates.
3. If an added posted transaction contains `pending_transaction_id`, the worker MUST locate the pending transaction's existing Round-Up event, if any, and move that event to the posted transaction rather than creating an independent economic event.
4. If a transaction is removed, its live Round-Up contribution MUST be reversed to zero. The historical closed batch snapshot is never rewritten.
5. If an account disappears from Plaid's current account response, the local account is marked `closed`; it is not physically deleted.
6. If a transaction cannot be associated with a known account, the sync transaction MUST fail and the cursor MUST NOT advance.
7. The complete `/transactions/sync` pagination loop is retried from the original cursor when a pagination call fails, as required by Plaid's mutation-during-pagination guidance. îˆ€citeîˆ‚turn5search3îˆ

# 16. v4.4 ROUND-UP CORRECTION CONTRACT

`applyRoundupEvent()` is idempotent for a new economic transaction. `applyRoundupCorrection()` is idempotent for an existing event and MUST execute all live-state changes in one database transaction:

```text
old event
   â†“
calculate new evaluation
   â†“
delta = new_roundup - old_roundup
   â†“
update roundup_events:
  source_amount_cents
  roundup_cents
  eligibility_status
  eligibility_reason
   â†“
update roundup_accumulators by delta
   â†“
if batch is pending:
  update roundup_line_items.roundup_cents_snapshot
  recompute pending batch total
   â†“
insert roundup_corrections audit row
```

A correction is required whenever any authoritative event field changes, not only when `roundup_cents` changes. Therefore a transaction changing from `$1.01` to `$1.02` still updates `source_amount_cents` even though both produce a 99-cent Round-Up.

A correction against a closed batch changes the live event and accumulator but never changes the closed batch's snapshot. The correction ledger provides the lineage between historical and current values.

# 17. v4.4 INTELLIGENCE EXECUTION CONTRACT

The intelligence pipeline executes after all `added`, `modified`, and `removed` updates for an Item have been persisted, never once per individual transaction in isolation:

```text
1. synchronize accounts
2. persist all added/modified transaction records
3. mark all removed transactions
4. resolve pending -> posted event lineage
5. resolve merchant identities
6. detect refunds
7. detect transfer relationships
8. classify all affected transactions
9. resolve income signals
10. reclassify PENDING_INCOME_REVIEW rows
11. evaluate/correct Round-Up events
12. compute recurring streams
13. compute cash-flow periods
14. compute net-worth snapshot
15. compute liquidity and fee signals
16. run reconciliation
17. publish/update the authoritative dashboard read model
18. commit cursor only after all required steps succeed
```

No dashboard endpoint performs any of steps 5â€“17.

### 17.1 Refund detection

For a negative transaction, a refund candidate is a prior non-removed positive transaction on the same account with:

- same normalized merchant;
- equal absolute amount;
- posted/authorized date no more than 60 days earlier.

If multiple candidates exist, choose the closest date; ties are unresolved and remain `UNKNOWN`. A refund is never inferred solely from amount.

### 17.2 Transfer detection

A transfer candidate MUST:

- involve a different account;
- have equal and opposite amount;
- occur within the configured temporal tolerance;
- belong to the same iBag user;
- not be removed.

The detector chooses the highest-scoring candidate deterministically. Same-account opposite-value transactions are never classified as transfers.

### 17.3 Income candidates

Only transactions classified as `PENDING_INCOME_REVIEW` or already resolved as `INCOME` participate in income-signal learning. Refunds, fees, transfers, loan payments, credit-card payments, ATM withdrawals, investment activity, and unknown transactions do not train the income detector.

Transactions without a stable merchant/entity identity are not merged into a single synthetic "unnamed employer" signal.

### 17.4 Merchant normalization

The merchant resolver MUST:

```text
normalize provider merchant string
  -> exact normalized alias lookup
  -> create canonical merchant when no alias exists
  -> persist alias
  -> attach merchant_entity_id to transaction
```

Normalization is deterministic and case/whitespace insensitive. The raw provider merchant name is retained unchanged for lineage.

### 17.5 Recurring streams

Recurring streams are grouped by canonical merchant identity, not raw merchant display string. The engine only considers economically plausible recurring classifications and excludes refunds and unknown transactions. It does not claim a recurring stream when evidence is insufficient.

# 18. v4.4 PRODUCT / CAPABILITY CONTRACT

Plaid currently distinguishes required `products`, `required_if_supported_products`, `optional_products`, and `additional_consented_products`. For personal-finance use cases Plaid currently recommends Transactions with Liabilities and Investments in `additional_consented_products`, and Identity in `required_if_supported_products` when appropriate. îˆ€citeîˆ‚turn2search0îˆ‚turn2search1îˆ

iBag therefore uses:

```json
{
  "products": ["transactions"],
  "required_if_supported_products": ["identity"],
  "optional_products": [],
  "additional_consented_products": ["liabilities", "investments"]
}
```

This is intentional:

- Transactions is mandatory to the Phase 1 product.
- Identity is best-effort without excluding unsupported institutions.
- Liabilities and Investments are consented for later endpoint use rather than falsely treated as observed merely because consent was requested.
- Balance is not placed in any product array; Plaid states that Balance is automatically initialized when another product is initialized. îˆ€citeîˆ‚turn2search1îˆ

`provider_capabilities` records the distinction among requested, consented, product-enabled, observed, successful-sync timestamp, and failed-sync timestamp. A capability is not marked `observed` until iBag has successfully received and persisted real data from the corresponding Plaid endpoint.

## 18.1 Domain synchronization

After Item creation and on the appropriate webhooks/scheduled refreshes:

```text
Transactions -> /transactions/sync
Accounts     -> /accounts/get
Liabilities  -> /liabilities/get
Investments  -> /investments/holdings/get
Investments  -> /investments/transactions/get
Identity     -> /identity/get
```

The corresponding raw provider response is written to `source_observations` before canonical persistence.

Plaid Liabilities supports credit-card, PayPal credit, student-loan, and mortgage data, with coverage dependent on institution/account compatibility. îˆ€citeîˆ‚turn0search0îˆ‚turn0search2îˆ

Plaid Investments provides holdings, security, and investment transaction data; investment transactions cover up to 24 months and are paginated. îˆ€citeîˆ‚turn5search0îˆ‚turn5search1îˆ

Identity can return names, email, phone numbers, and addresses, including multiple owners for joint accounts; non-name fields may be absent. îˆ€citeîˆ‚turn1search4îˆ

## 18.2 Investment net-worth rule

Do NOT sum both:

```text
accounts.current_balance_cents for investment accounts
+
SUM(investment_holdings.institution_value_cents)
```

Plaid defines an investment account's current balance as the total value of assets presented by the institution. îˆ€citeîˆ‚turn4search0îˆ

Therefore:

```text
depository assets
+ investment-account current balances
- credit/loan liabilities
= net worth
```

Investment holdings remain the detailed composition layer and are used for portfolio intelligence, concentration, security, cost-basis, and holding-level evidenceâ€”not added again to net worth.

If an investment account's current balance is null, that investment domain is incomplete and the net-worth evidence state becomes `limited` or `insufficient_evidence` according to the evidence contract.

# 19. v4.4 AUTHENTICATION CONTRACT

Custom JWT remains the authentication authority.

### Access tokens

- Algorithm: HS256 only.
- Access-token lifetime: 15 minutes.
- `sub` MUST be a valid internal UUID.
- `iss` and `aud` MUST be present and validated.
- No algorithm negotiation is permitted.
- JWT secret rotation is versioned through a key identifier.
- Old signing keys remain accepted only for their configured overlap period.

### Refresh tokens

Refresh tokens are opaque random values, never JWTs.

Store only:

```text
token_hash
user_id
family_id
issued_at
expires_at
revoked_at
replaced_by
```

Every successful refresh rotates the token. Reuse of a previously rotated refresh token revokes the entire token family.

### Logout

Logout revokes the supplied refresh token and its family according to the requested scope. Access tokens remain naturally bounded by their 15-minute expiry.

### Password reset

Reset tokens are:

- cryptographically random;
- hashed at rest;
- single-use;
- short-lived;
- invalidated after password change;
- invalidated after another reset token is successfully consumed.

No password-reset token is ever returned from an authenticated endpoint after creation.

### Email normalization

Email addresses are normalized by trimming and lowercasing before lookup/storage. The database enforces uniqueness on the normalized value.

### Login abuse protection

The declared rate-limit variables are actually wired to authentication endpoints. Login, signup, password-reset request, refresh, and Link-token creation each receive explicit rate-limit policies. Rate-limit responses never reveal whether an email exists.

# 20. v4.4 DATABASE/RLS SECURITY CONTRACT

`app_role` is not a valid role unless it is explicitly created. v4.4 therefore removes the undeclared-role dependency and uses:

```text
ibag_app     -> ordinary authenticated API connection
ibag_service -> worker/webhook/reconciliation connection
```

The application connection MUST NOT be a superuser or a role with `BYPASSRLS`.

The service connection is server-only and may bypass RLS.

User-owned policies are explicitly scoped to `ibag_app` and use the verified per-transaction setting:

```sql
current_setting('app.current_user_id', true)::uuid
```

The API MUST reject requests that attempt to supply or override the setting.

The following relationships receive explicit cross-user protection:

```text
roundup_events.transaction_id
roundup_accumulators.account_id
roundup_batches.accumulator_id
roundup_line_items.batch_id + roundup_event_id
transaction_relationships.transaction_id_a + transaction_id_b
sync_runs.plaid_item_id
all liability/investment/identity account_id relationships
```

The RLS test matrix must attempt both read and write attacks, not only SELECT.

# 21. v4.4 APPLICATION ENTRYPOINT

The specification now requires a literal `src/index.js` that:

1. validates environment variables before starting;
2. creates the Express application;
3. applies CORS using `CORS_ORIGIN`;
4. applies global security headers appropriate to the deployed stack;
5. mounts the webhook route BEFORE `express.json()`;
6. uses `express.raw({type:'application/json', limit:'1mb'})` only for `/plaid/webhook`;
7. applies `express.json()` to ordinary API routes;
8. mounts `/auth/*`, `/me/*`, `/link/*`, and health routes;
9. installs the authentication and Link rate limiters;
10. installs one final structured error handler;
11. never serializes secrets, access tokens, passwords, or raw Plaid credentials into responses;
12. starts the HTTP listener only after the database health check succeeds.

The webhook URL is `WEBHOOK_PUBLIC_URL`, never `CORS_ORIGIN` and never a frontend URL.

# 22. v4.4 WEBHOOK DURABILITY CONTRACT

Plaid recommends a dedicated webhook listener and warns that webhook arrival rates can be unpredictable. îˆ€citeîˆ‚turn3search1îˆ

The webhook request path therefore does only:

```text
verify signature
-> persist verified event atomically
-> acknowledge HTTP 200
```

The durable worker performs:

```text
claim received/failed event with FOR UPDATE SKIP LOCKED
-> resolve item
-> acquire per-item advisory lock
-> run required sync/domain job
-> mark processed
```

Failed events are retried with bounded exponential backoff. After the configured maximum retry count they enter a terminal `dead_letter` state and generate a `data_quality_event`.

A webhook being acknowledged by HTTP 200 never means the downstream sync succeeded.

# 23. v4.4 DASHBOARD CONTRACT

The authoritative dashboard endpoint is:

```text
GET /me/dashboard
```

It is read-only.

It MUST NOT calculate a new Round-Up amount.

It reads:

```text
accounts
transactions
roundup_events
roundup_accumulators
income_signals
recurring_streams
cash_flow_periods
net_worth_snapshots
financial_health_signals
provider_capabilities
reconciliation/data-quality status
```

The response includes, at minimum:

```text
accounts
transactions_observed
observation_window
roundup_event_count
roundup_opportunity_count
roundup_opportunity_cents
roundups_by_account
roundups_by_category
roundups_by_merchant
income intelligence
cash-flow intelligence
liquidity intelligence
recurring streams
net worth
evidence envelopes
provider capability state
data-quality warnings
```

Every derived value is traceable to an authoritative stored source. The frontend formats the response; it does not independently recalculate financial intelligence.

# 24. v4.4 RECONCILIATION CONTRACT

Reconciliation is mandatory after every successful sync and periodically thereafter.

At minimum it verifies:

1. current eligible Round-Up event sum = accumulator;
2. event source amount = current transaction amount;
3. removed transactions have zero live Round-Up contribution;
4. each current economic transaction has at most one live Round-Up event per rule version;
5. pending->posted lineage does not create a second independent event;
6. accumulator totals are non-negative;
7. pending batch total = sum of pending line-item snapshots;
8. closed batch total = sum of immutable closed line-item snapshots;
9. category Round-Up totals reconcile to global Round-Up total;
10. merchant Round-Up totals reconcile to global Round-Up total;
11. event counts reconcile with the defined eligible-purchase population;
12. transaction relationships never cross users;
13. no current transaction references a closed/nonexistent account;
14. intelligence rows use the current calculation version;
15. provider capability timestamps match actual successful persistence;
16. net-worth investment value is not double-counted;
17. USD-only calculations contain no non-USD rows;
18. every dashboard metric has a source lineage.

Any mismatch writes a `data_quality_event` and blocks promotion of the affected intelligence result from `observed/calculated` to a stronger evidence state.

# 25. v4.4 TEST GATES

Implementation cannot advance from SPECIFIED to IMPLEMENTED until the following are green:

```text
T01 empty-database migration
T02 role/grant/RLS boot
T03 cross-user SELECT isolation
T04 cross-user INSERT isolation
T05 cross-user UPDATE isolation
T06 cross-user DELETE isolation
T07 JWT algorithm rejection
T08 JWT issuer/audience rejection
T09 expired access token rejection
T10 refresh-token rotation
T11 refresh-token replay detection
T12 password-reset single-use
T13 login rate limit
T14 webhook ES256 verification
T15 webhook future/stale iat rejection
T16 webhook body-hash mismatch rejection
T17 webhook concurrent duplicate delivery
T18 webhook durable retry
T19 concurrent Item sync serialization
T20 cursor rollback on sync failure
T21 missing-account cursor protection
T22 pending transaction -> posted transaction
T23 pending transaction removed without posting
T24 posted transaction modified amount
T25 posted transaction removed
T26 transaction churn detection/limited-evidence behavior
T27 refund matching
T28 same-account transfer false-positive rejection
T29 cross-account transfer detection
T30 loan-payment conservative classification
T31 credit-card payment detection
T32 investment-account exclusion from Transactions sync
T33 liabilities persistence
T34 investments pagination
T35 identity multi-owner persistence
T36 merchant normalization
T37 recurring stream normalization
T38 income false-positive exclusion
T39 USD/non-USD separation
T40 Round-Up correction source-amount update
T41 Round-Up accumulator correction
T42 open-batch correction
T43 closed-batch immutability
T44 batch creation concurrency
T45 category reconciliation
T46 merchant reconciliation
T47 net-worth investment balance correctness
T48 dashboard read-only behavior
T49 dashboard/frontend schema contract
T50 raw observation retention
T51 secrets absent from logs
T52 provider capability state transitions
T53 account closure handling
T54 Plaid Item error handling
T55 Link exchange retry/idempotency
T56 complete Sandbox end-to-end flow
```

# 26. v4.4 CERTIFICATION STATE

This specification is:

```text
SPECIFIED
```

It is not yet:

```text
IMPLEMENTED
REPO_AUDITED
STAGING_VALIDATED
CANARY_VALIDATED
PRODUCTION_VALIDATED
```

Those statuses must be earned by executing the test gates above. No specification text can truthfully substitute for those runtime validations.


---

# 13. IMPLEMENTATION ORDER

```
P0  Node 24 LTS runtime, exact dependencies, environment validation, repo scaffold, CI
P1  Database roles, pgcrypto, full schema, composite integrity, grants, RLS, retention jobs
P2  Custom auth: signup/login/access JWT/refresh rotation/logout/password reset/rate limits
P3  Plaid Link + token exchange + provider capability observation + account synchronization
P4  /transactions/sync with serialized Item locks, cursor safety, pending/posted lineage, removals
P5  Webhook verification + durable event queue + retry worker
P6  Merchant normalization, refund detection, transfer detection, deterministic classification
P7  Round-Up creation/correction/removal + immutable batch snapshots
P8  Liabilities + Investments + Identity domain persistence and capability state
P9  Intelligence orchestration: income, recurring, cash flow, net worth, liquidity, fees
P10 Reconciliation and data-quality gates
P11 Authoritative /me/dashboard read model and all supporting read endpoints
P12 Full Sandbox matrix and concurrency/failure tests
P13 Monitoring, retention, alerts, staging validation, canary
```


---

# 13.1 v4.1 CORRECTIVE OVERLAY â€” PRESERVATION + REQUIRED FIXES

This section is an explicit corrective overlay to v4.0. It does not delete or silently rewrite any v4.0 requirement. The complete v4.0 specification remains above; where a v4.0 statement conflicts with a correction below, the v4.1 correction is authoritative.

## 13.1.1 Specification status terminology

The specification is **developer-executable**, but it is not evidence that all implementation source files already exist. `SPECIFIED` remains distinct from `IMPLEMENTED`, `REPO_AUDITED`, `STAGING_VALIDATED`, `CANARY_VALIDATED`, and `PRODUCTION_VALIDATED`.

## 13.1.2 Net-worth valuation invariant

An investment asset MUST NOT be counted twice through both an investment account balance and the sum of its holdings.

Authoritative Phase-1 rule:

```text
Depository assets = authoritative depository account balance.
Investment assets = authoritative investment valuation path.
Do not add investment account balance and holdings value for the same economic assets.
Liabilities = authoritative liability balances.
Net worth = assets - liabilities.
```

The implementation MUST explicitly document which Plaid investment valuation field/path is authoritative and how investment cash is represented so that neither cash nor securities are omitted or double-counted.

> **v4.2 status: APPLIED.** Section 9.4's formula and `computeNetWorthSnapshot()` now exclude `type='investment'` accounts from the balance sum and rely solely on `investment_holdings.institution_value_cents`. This was previously only stated as a MUST here without the actual formula in Section 9.4 being touched â€” it now is.

## 13.1.3 Plaid canonical-field preservation

Raw Plaid JSON MUST be retained for lineage, but important Plaid fields required for classification, reconciliation, intelligence, filtering, sorting, or user display MUST also have explicit canonical representations.

For Transactions, the canonical model SHOULD preserve, where supplied by Plaid, including but not limited to:

```text
merchant_entity_id
merchant_name
original_description
personal_finance_category
personal_finance_category_version
payment_channel
transaction_code
authorized_date
authorized_datetime
date
datetime
location
payment_meta
counterparties
logo_url
website
check_number
pending
pending_transaction_id
```

The exact current Plaid response schema remains the external provider contract and MUST be revalidated at implementation time. `raw JSONB` is the lossless source record; it is not a substitute for required canonical intelligence fields.

## 13.1.4 Investment canonical model

The investment model MUST preserve, in canonical form where supplied and relevant, security identity, ticker, security type/subtype, quantity, institution price, institution price date/time, institution value, cost basis, vested quantity/value where applicable, currency, cash-equivalent status, position type, and tax-lot information where applicable. Raw provider payloads remain authoritative for fields not yet normalized.

## 13.1.5 Liability canonical model

The liability model MUST be extensible enough to preserve the current Plaid liability domains rather than reducing them to only a balance and a few descriptive fields. Relevant canonical fields include, where supplied:

```text
credit limits
payment amount
payment date
past-due amount
late fees
statement information
interest information
principal information
mortgage escrow / PMI / prepayment information
property information
student-loan payoff / guarantor / repayment information
```

The implementation MUST retain raw provider payloads so newly supplied provider fields are never discarded.

## 13.1.6 Webhook verification freshness

Webhook `iat` validation MUST reject timestamps outside the accepted freshness window in both directions, not merely timestamps that are too old.

Conceptually:

```text
abs(now_seconds - payload.iat) <= MAX_IAT_AGE_SECONDS
```

The exact implementation MUST follow the current Plaid webhook verification documentation at implementation time.

> **v4.2 status: APPLIED.** Section 8.4's `verifyPlaidWebhook()` now uses `Math.abs()`. Previously this section stated the requirement while Section 8.4's actual code still used the one-directional check.

## 13.1.7 Atomic webhook idempotency

Webhook idempotency MUST be race-safe. The implementation MUST NOT rely on `SELECT` followed by `INSERT` as the correctness mechanism.

Preferred database invariant:

```sql
INSERT INTO webhook_events (...)
VALUES (...)
ON CONFLICT (idempotency_key) DO NOTHING
RETURNING id;
```

A returned row means the delivery acquired processing ownership. No returned row means the delivery is already known and MUST be acknowledged idempotently without double dispatch.

> **v4.2 status: APPLIED.** Section 8.5's `webhook.js` now does exactly this â€” a single `INSERT ... ON CONFLICT (idempotency_key) DO NOTHING RETURNING id`, replacing the prior separate `SELECT` then `INSERT`. It also now runs under `withServiceRole()` (Section 8.3), without which the insert would have been blocked by RLS regardless of its atomicity â€” see 13.1.15.

## 13.1.8 Pending-to-posted economic lineage

A Plaid pending transaction and its subsequent posted replacement MUST NOT create two economic Round-Up opportunities.

The implementation MUST reconcile `pending_transaction_id` relationships and canonical economic identity before creating or finalizing a Round-Up event.

The invariant is:

```text
one economic purchase
    -> at most one authoritative Round-Up event per rule version
```

A database uniqueness constraint on `transaction_id` alone is insufficient to establish this invariant across pending and posted transaction IDs.

## 13.1.9 Transfer-detection contract

Transfer detection MUST be explicitly specified rather than represented only as an unresolved context value.

The detector MUST define, test, and version its treatment of:

```text
same-Item account transfers
cross-Item transfers
matching amounts
matching dates / temporal tolerance
pending-to-posted transfer relationships
ACH transfers
P2P transfers
credit-card payments
loan payments
investment funding / withdrawals
cash transfers
one-sided transfer visibility
ambiguous bank transfers
```

Every transfer decision MUST carry sufficient evidence for downstream classification and reconciliation.

## 13.1.10 Authentication lifecycle completeness

Because custom JWT + bcrypt is the declared authority, the production contract MUST define the complete credential/session lifecycle before production validation, including:

```text
signup
login
password hashing
JWT issuance
JWT expiry
refresh/session strategy
logout / revocation
password reset
email verification if required
credential change
session invalidation
key rotation
compromised-token response
rate limiting / abuse controls
```

The existing custom-auth decision is preserved; this section closes the remaining lifecycle requirements.

## 13.1.11 PostgreSQL security-role completeness

The RLS section MUST be accompanied by an explicit database-role model defining:

```text
API role
migration/owner role
service role where applicable
PUBLIC grants/revocations
RLS bypass privileges
TABLE ownership
SEQUENCE privileges
function EXECUTE privileges
```

No API-connected role may unintentionally bypass the intended RLS boundary.

## 13.1.12 iBag intelligence-domain terminology

The product may define eight Phase-1 intelligence domains, but the specification MUST NOT imply that Plaid universally defines exactly eight products or that product availability/billing is permanently fixed.

Use the terminology:

> **iBag Phase-1 Intelligence Domains**

and separately maintain the Plaid product/capability mapping as an external-provider compatibility matrix.

## 13.1.13 Sandbox transaction creation

The Sandbox test plan MUST support the current Plaid Sandbox transaction-creation mechanism where appropriate, including `/sandbox/transactions/create`, in addition to any custom-user fixture strategy retained by this specification.

All Sandbox-only routes and credentials MUST remain unreachable from Production execution paths.

## 13.1.14 Intelligence preservation rule

Nothing in this corrective overlay authorizes reducing, flattening, or removing the intelligence layer. The intelligence remains the product. Corrections are intended to increase evidence quality, lineage integrity, Plaid compatibility, reconciliation correctness, and analytical depth.

## 13.1.15 Service-role RLS lockout (found and fixed in v4.2)

`plaid_webhook_events`, `reconciliation_runs`, `data_quality_events`, and `audit_trail` (Section 5.10) are gated on `current_setting('app.is_service_role', true)::boolean = true`. No code anywhere in v4.0 or v4.1 ever set that setting â€” `db.js` only had `withUserContext()`, which sets `app.current_user_id`. Every write to those four tables, including the webhook handler's own insert of an incoming webhook, would have been silently blocked by RLS with no INSERT policy to satisfy it. This is not a style gap; it means the webhook pipeline could not boot.

**v4.2 status: APPLIED.** `src/db.js` (Section 8.3) now exports `withServiceRole()`, which sets `app.is_service_role = true` for the duration of a transaction. `webhook.js` (8.5) and `reconciliation.js` (8.13) now use it for every write to the four gated tables.

## 13.1.16 Self-consistency requirement (process note)

A corrective overlay section that states a MUST-fix without the corresponding DDL/code section actually being edited to match is, from a developer's point of view, indistinguishable from a fix that was never made â€” the document contradicts itself the moment someone copies the code instead of just reading the prose. Every entry in 13.1 that claims "APPLIED" in v4.2 was verified against this document's own numbered code/DDL sections, not just restated here. Any future revision MUST edit both the overlay language and the underlying section in the same pass, or explicitly mark an item as prose-only guidance with no corresponding code change required.

---

# 13.2 v4.2 CHANGELOG â€” EXACTLY WHAT CHANGED FROM v4.1, AND WHY

Nothing below removes content that existed in v4.1; every entry is either a correction to existing DDL/code or a new file filling a previously-named-but-empty gap.

**Schema (Section 5):**
- `transaction_relationships` â€” added `CHECK (transaction_id_a < transaction_id_b)` so the same pair can't be inserted twice in opposite order (5.5).
- `income_signals` â€” replaced `UNIQUE (user_id, source_merchant)` with two partial unique indexes to close the multi-NULL loophole (5.8).
- `users` â€” added an explicit comment stating the no-RLS decision and why, instead of leaving the absence unstated (5.10).

**Code (Section 8):**
- `db.js` â€” added `withServiceRole()`; without it, RLS silently blocked every write to `plaid_webhook_events`, `reconciliation_runs`, `data_quality_events`, `audit_trail` (8.3, 13.1.15).
- `plaidWebhookVerify.js` â€” `iat` check now uses `Math.abs()`, rejecting future-dated timestamps as well as stale ones (8.4, 13.1.6).
- `webhook.js` â€” idempotency is now one atomic `INSERT ... ON CONFLICT DO NOTHING RETURNING id`, and every write now runs under `withServiceRole()` (8.5, 13.1.7 + 13.1.15).
- `roundup/rules.js` â€” added `addToOpenBatch()` and `closeBatch()`; `applyRoundupEvent()` now actually calls the batch writer, so `roundup_batches`/`roundup_line_items` are populated instead of being schema with no writer (8.7).
- **New:** `providers/plaid/adapter.js` implementing the Section 4 interface (8.9).
- **New:** `jobs/sync.js` â€” the actual `/transactions/sync` cursor loop, previously only prose (8.10).
- **New:** `routes/me.js`, `routes/link.js` (8.11, 8.12).
- **New:** `jobs/reconciliation.js` (8.13).

**Intelligence engines (Section 9):**
- 9.1â€“9.5 â€” each now has an actual JS module (`src/intelligence/*`) in addition to the calculation shape; previously SQL-shaped prose only.
- 9.4 â€” net-worth formula and code both now exclude `investment`-type account balances from the asset sum, since `investment_holdings.institution_value_cents` already represents that value (13.1.2).
- **New:** 9.6 transfer detection, implementing a first pass of the Section 13.1.9 contract (amount/date matching only â€” see 9.6 for what's intentionally deferred).

**What v4.2 left genuinely unresolved (see 13.3 for what's still open after v4.3):**
- 13.1.3â€“13.1.5's canonical-field preservation (Plaid field-by-field DDL for transactions/investments/liabilities beyond what Section 5's `CREATE TABLE` statements already carry) is still not fully reflected in the DDL â€” adding every named field as an explicit column is a real, sizeable schema change this pass did not attempt, to avoid guessing at columns without a live schema to check them against.
- 13.1.9's full transfer-detection contract (ACH, P2P, credit-card payments, investment funding, one-sided visibility, ambiguous transfers) is only partially implemented by 9.6's amount/date matcher.
- 13.1.10's full auth lifecycle (refresh, logout/revocation, password reset, email verification, key rotation, rate limiting) is still not implemented as code â€” 8.2 only covers signup/login/middleware.
- 13.1.11's explicit database-role model (API role vs. migration role vs. `PUBLIC` grants) is still not written as DDL.
- ~~The mojibake encoding corruption is a symptom of whatever produced the source document, not something fixable from inside the document's own content.~~ **v4.3 correction:** this claim was wrong. The corruption was a small, fixed set of consistently-mangled sequences (a UTF-8 payload that had been decoded as Latin-1 and re-encoded, at least once) and was mechanically reversible. It has been corrected throughout this document. Worth noting as a lesson: a corrective document should not assert something is unfixable without actually attempting the fix.

---

# 13.3 v4.3 CHANGELOG â€” EXACTLY WHAT CHANGED FROM v4.2, AND WHY

v4.2's own Section 13.1.16 declared a self-consistency requirement â€” an "APPLIED" claim must be checked against the actual code, not just restated in prose. This version is the result of applying that same discipline to v4.2's own claims. All five gaps below were confirmed against v4.2's actual code, not assumed from its changelog language.

**Gap 1 â€” dead classification rules.** `sync.js` (8.10) hardcoded `account_type: null` when calling `classify()`. `classify.js` rules 4â€“6 (LOAN_PAYMENT, CREDIT_CARD_PAYMENT, INVESTMENT_ACTIVITY) all branch on `account_type`, so those rules could never fire against real sync data.
> **v4.3 status: APPLIED.** `sync.js` now looks up the account row (including `type`) before classifying, and passes the real value. Rules 4 and 6 are now live. **Rule 5 is not** â€” see "still unresolved" below.

**Gap 2 â€” two-pass income classification described but not implemented.** Section 8.6's prose and the `sync.js` comment both referenced a `PENDING_INCOME_REVIEW` intermediate status; no code anywhere wrote or read that value. An ambiguous negative-amount transaction just fell through to `UNKNOWN`.
> **v4.3 status: APPLIED.** `classify.js` rule 8 now returns real `PENDING_INCOME_REVIEW`, `INCOME`, or `UNKNOWN` depending on `context.incomePhase` and `context.incomeSignalMatch`. New `jobs/incomeReview.js` (8.14) is pass 2 â€” it recomputes `income_signals` and re-classifies every `PENDING_INCOME_REVIEW` row. `roundup/rules.js`'s `INELIGIBLE_CLASSIFICATIONS` now explicitly includes `PENDING_INCOME_REVIEW`.

**Gap 3 â€” modified transactions didn't correct Round-Up events.** `sync.js` called `applyRoundupEvent()` for both `added` and `modified` transactions, but `roundup_events` has `ON CONFLICT (transaction_id, rule_version) DO NOTHING` â€” a modified transaction's new amount never updated the existing event or accumulator.
> **v4.3 status: APPLIED.** `sync.js` now detects insert-vs-update via the transaction row itself (`xmax = 0`, not Plaid's added/modified partitioning) and routes updates through `applyRoundupCorrection()`. Fixing this exposed a second, deeper problem â€” see "found while fixing" below.

**Gap 4 â€” Sections 9.3 and 9.5 partly prose-only.** 9.3 (recurring streams) had no module, only a description of reusing 9.2's helpers. 9.5 implemented liquidity but not fees.
> **v4.3 status: APPLIED.** `src/intelligence/recurring/index.js` is a real module. `src/intelligence/liquidity/index.js` gained `computeFeeSignal`. The financial-health **composite** (combining liquidity + fees into one score) is deliberately still not built â€” see "still unresolved."

**Gap 5 â€” `merchants`/`merchant_aliases` never populated.** Schema existed; no code wrote to it, so `recurring_streams.merchant_id` had nothing to reference.
> **v4.3 status: APPLIED.** `src/intelligence/merchant/resolve.js` resolves/creates merchant + alias rows, called from the new recurring-streams engine.

**Found while fixing Gap 3 â€” `applyRoundupCorrection` didn't keep `roundup_events` itself consistent.** The original v4.2 function updated the correction log and the accumulator but never the source `roundup_events` row, so `reconciliation.js`'s `SUM(roundup_events.roundup_cents)` would permanently diverge from the accumulator after any correction â€” every future reconciliation run would report a false mismatch for a correctly-corrected account.
> **v4.3 status: APPLIED.** `applyRoundupCorrection` now updates the `roundup_events` row, and keeps `roundup_batches`/`roundup_line_items` consistent for still-`pending` batches. A correction against an already-`closed` batch does not rewrite settled history; it returns a `dataQualityFlag` instead.

**Found while fixing that â€” writing the data-quality flag would have reproduced 13.1.15's bug.** A naive fix would have written `data_quality_events` from inside `applyRoundupCorrection`, which runs on a `withUserContext` connection. `data_quality_events` is service-role-gated (5.10); that write would have silently failed under RLS, the same class of bug already fixed once in v4.2 (13.1.15).
> **v4.3 status: APPLIED.** `applyRoundupCorrection` returns the flag instead of writing it. `sync.js` collects any flags and writes them via a separate `db.withServiceRole()` call after the main sync transaction completes.

**What v4.3 still leaves genuinely unresolved, stated plainly rather than implied fixed:**
- **Rule 5 (CREDIT_CARD_PAYMENT) is still dead code.** Fixing `account_type` (Gap 1) unblocked rules 4 and 6, but rule 5 also requires `context.isPaymentNotPurchase`, which `sync.js` still hardcodes to `false`. Determining whether a credit-account transaction is a payment (paying down the card) versus a purchase needs its own detection logic â€” most plausibly tying into the transfer-detection pass (9.6), since a card payment often has a matching debit on a depository account â€” which does not exist yet and was not guessed at here.
- **`runIncomeReviewForAllPendingUsers()`'s user-enumeration query runs against RLS-protected `transactions` on the plain pool.** It will silently return zero rows rather than error. This needs an actual decision (a new service-role-scoped enumeration path, or iterating `plaid_items` instead) before that convenience wrapper is safe to schedule â€” flagged in 8.14's own notes, not fixed there.
- **The financial-health composite score is still not implemented**, by design â€” see Gap 4's status note. Combining liquidity and fees into one number needs a real methodology decision this pass did not make.
- 13.1.3â€“13.1.5's canonical-field preservation (Plaid field-by-field DDL) â€” unchanged from v4.2, still not attempted.
- 13.1.9's full transfer-detection contract (ACH, P2P, credit-card payments, investment funding, one-sided visibility, ambiguous transfers) â€” unchanged from v4.2, only the amount/date matcher exists.
- 13.1.10's full auth lifecycle (refresh, logout/revocation, password reset, email verification, key rotation, rate limiting) â€” unchanged from v4.2, not implemented as code.
- 13.1.11's explicit database-role model (API role vs. migration role vs. `PUBLIC` grants) â€” unchanged from v4.2, not written as DDL.
- **New test coverage needed, not yet written as fixtures:** the two-pass income resolution end-to-end (pending â†’ resolved), a modified-transaction Round-Up correction (including the closed-batch data-quality-flag path), and the merchant resolver's first-sight vs. repeat-sight behavior. Section 10's testing matrix names these categories but no literal Sandbox fixtures for them exist in this document, consistent with how Section 10 has always worked for the Round-Up matrix (11.3 supplies the pattern, not literal coverage of every case).

---

# 14. FINAL DECLARATION STANDARD

> iBag v4.3 developer specification finished (SPECIFIED). No implementation exists yet against the real repository or database â€” producing this document, however corrected, is not the same as running a migration or a test suite. The next milestone is P0â€“P1: an actual commit and an actual migration run against Supabase.

Relative to v4.1, v4.2 fixed every concretely-verified bug from the prior audit directly in the DDL/code sections themselves and filled in the previously-named-but-bodiless files. Relative to v4.2, this pass (v4.3) found and fixed five gaps between v4.2's own changelog and its actual delivered code â€” dead classification rules from a hardcoded `account_type`, a two-pass income classification that existed only in prose, Round-Up corrections that silently no-op'd on modified transactions, two prose-only intelligence sections, and an unpopulated merchants table â€” plus two more bugs surfaced in the process of fixing gap 3 (a reconciliation-breaking omission in `applyRoundupCorrection`, and a near-repeat of the 13.1.15 RLS lockout bug that was caught before it shipped rather than after). Section 13.3 lists exactly what changed and, separately, what remains genuinely unresolved: one more dead classification rule (credit card payments), an unsafe convenience wrapper flagged rather than silently shipped, the deliberately-undecided financial-health composite, and the same four structural gaps (canonical-field DDL, full transfer-detection contract, auth lifecycle, database role model) v4.2 already named as open. Those are named honestly as still open rather than implied fixed by this pass's overall thoroughness.

This document is as complete as a specification can honestly be made in this pass. It is not evidence that anything has been built, tested, or deployed â€” that evidence only exists once P0 produces a commit SHA, and no amount of further reading of this document substitutes for running it against live Sandbox data and a real concurrent-load test, per Section 11.4's ceiling. "99% ready" is not an authoritative characterization and MUST NOT be used as a certification claim â€” it is not a claim about test coverage, live Sandbox validation, or concurrent-load behavior, none of which this document alone can establish.
````


# 27. v4.4 EXHAUSTIVE AUDIT LEDGER

The following items are intentionally **closed by contract** rather than left as "future work":

| Area | v4.3 state | v4.4 state |
|---|---|---|
| Node runtime | Node 20 floor | Node 24 LTS |
| dependency pinning | caret ranges | exact direct versions + lockfile |
| pgcrypto | implicit | explicit migration requirement |
| app_role | undeclared | explicit database-role model |
| service-role security | custom GUC only | dedicated server-only service connection |
| RLS cross-user child/parent integrity | incomplete | mandatory composite integrity/trigger tests |
| raw observation retention | NOT NULL contradiction | nullable after retention |
| currency | missing default could become USD | no silent currency default |
| account refresh | Link-only | sync on lifecycle/update |
| liabilities persistence | adapter-only | persistence + capability state |
| investments persistence | adapter-only | persistence + pagination |
| identity persistence | adapter-only | persistence + multi-owner storage |
| pending->posted | separate transactions | event lineage migration |
| removed posted transaction | stale Round-Up | live reversal + immutable history |
| roundup correction | incomplete source update | complete atomic correction |
| batch concurrency | race possible | unique open-batch invariant |
| batch historical amount | mutable event reference | immutable line-item snapshot |
| refund matching | disabled placeholder | conservative deterministic matcher |
| transfer matching | same-account possible | different-account requirement |
| transfer ordering | page-order dependent | post-persistence reconciliation pass |
| income training | broad negative population | candidate-only training |
| merchant identity | unused tables | deterministic resolver |
| intelligence orchestration | modules only | explicit ordered pipeline |
| net worth investment value | holdings-only | institution account balance as total |
| Plaid product initialization | optional-products default | current Plaid consent model |
| webhook acknowledgement | ack before durable retry | durable retry worker |
| sync concurrency | race possible | per-Item advisory lock |
| API entrypoint | absent | required literal `src/index.js` |
| CORS | env only | middleware + dependency |
| rate limiting | env only | wired policies |
| auth lifecycle | partial | complete access/refresh/revocation/reset contract |
| dashboard | incomplete | authoritative `/me/dashboard` |
| reconciliation | accumulator-centric | full invariant suite |
| tests | broad | 56 mandatory gates |

## 27.1 Items that remain external by nature

These are not hidden implementation gaps; they are explicit external prerequisites:

1. Plaid Production approval and product access.
2. Final Plaid commercial pricing/billing terms for the specific account.
3. Production institution coverage.
4. Production domain and valid HTTPS certificate.
5. SMTP/email delivery credentials if password reset/email verification is enabled.
6. Supabase database connection credentials for the dedicated API and service roles.
7. Render/runtime configuration.
8. Legal/privacy retention decisions that may require shortening the stated defaults.
9. Actual repository implementation and execution of the test gates.
10. Production security review and penetration testing.

These cannot be honestly "solved" inside a code specification because they depend on external accounts, credentials, infrastructure, or validation.

## 27.2 No knowingly hidden specification gap

At the end of v4.4, any item not yet implemented is explicitly classified as one of:

```text
IMPLEMENTATION TASK
EXTERNAL PREREQUISITE
RUNTIME VALIDATION
INTENTIONALLY OUT OF SCOPE
```

There is no category called "assumed complete."




# 28. v4.4 REQUIRED RUNTIME FILES

The following files were absent or incomplete in v4.3 and are now literal implementation contracts.

## 28.1 `src/index.js`

```javascript
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const db = require('./db');

const authRoutes = require('./routes/auth');
const meRoutes = require('./routes/me');
const linkRoutes = require('./routes/link');
const webhookRouter = require('./routes/webhook');

const app = express();

const required = [
  'DATABASE_URL',
  'SERVICE_DATABASE_URL',
  'PLAID_CLIENT_ID',
  'PLAID_SECRET',
  'ENCRYPTION_KEY',
  'JWT_SECRET',
  'CORS_ORIGIN',
  'API_PUBLIC_URL',
  'WEBHOOK_PUBLIC_URL',
];

for (const key of required) {
  if (!process.env[key]) throw new Error(`Missing required environment variable: ${key}`);
}

app.disable('x-powered-by');

app.use(cors({
  origin: process.env.CORS_ORIGIN,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Authorization', 'Content-Type'],
}));

// The webhook route MUST receive the exact bytes before JSON parsing.
app.use('/plaid/webhook', webhookRouter);

// Ordinary JSON API.
app.use(express.json({ limit: '1mb' }));

const authLimiter = rateLimit({
  windowMs: Number(process.env.RATE_LIMIT_LOGIN_WINDOW_MS || 900000),
  limit: Number(process.env.RATE_LIMIT_LOGIN_MAX || 8),
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  identifier: 'auth',
});

app.get('/health', async (req, res) => {
  try {
    await db.pool.query('SELECT 1');
    res.json({ status: 'ok' });
  } catch {
    res.status(503).json({ status: 'error', code: 'DB_UNAVAILABLE' });
  }
});

app.use('/auth', authLimiter, authRoutes);
app.use(meRoutes);
app.use(linkRoutes);

app.use((err, req, res, next) => {
  console.error(JSON.stringify({
    type: 'api_error',
    path: req.path,
    method: req.method,
    code: err.code || 'INTERNAL_ERROR',
    message: err.message,
  }));

  if (res.headersSent) return next(err);
  res.status(err.statusCode || 500).json({
    status: 'error',
    code: err.code || 'INTERNAL_ERROR',
    message: err.expose ? err.message : 'Internal server error.',
  });
});

const port = Number(process.env.PORT || 3000);
db.pool.query('SELECT 1').then(() => {
  app.listen(port, () => console.log(`iBag API listening on ${port}`));
}).catch((err) => {
  console.error('FATAL: database startup check failed', err);
  process.exit(1);
});

module.exports = app;
```

## 28.2 `src/db.js`

```javascript
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

const servicePool = new Pool({
  connectionString: process.env.SERVICE_DATABASE_URL,
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

pool.on('error', (err) => console.error('Unexpected application DB client error', err));
servicePool.on('error', (err) => console.error('Unexpected service DB client error', err));

async function withUserContext(userId, fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      "SELECT set_config('app.current_user_id', $1, true)",
      [userId]
    );
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function withServiceRole(fn) {
  const client = await servicePool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = {
  pool,
  servicePool,
  query: (...args) => pool.query(...args),
  withUserContext,
  withServiceRole,
};
```

## 28.3 Authentication session schema

```sql
CREATE TABLE auth_refresh_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  family_id UUID NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  issued_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  replaced_by UUID REFERENCES auth_refresh_sessions(id),
  user_agent TEXT,
  ip_hash TEXT
);

CREATE INDEX idx_auth_refresh_user ON auth_refresh_sessions(user_id);
CREATE INDEX idx_auth_refresh_family ON auth_refresh_sessions(family_id);

CREATE TABLE password_reset_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  consumed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_password_reset_user ON password_reset_tokens(user_id);
```

These tables are service-owned and are never exposed to ordinary application reads.

## 28.4 JWT verification contract

The access-token verifier MUST use:

```javascript
jwt.verify(token, JWT_SECRET, {
  algorithms: ['HS256'],
  issuer: 'ibag-api',
  audience: 'ibag-client',
});
```

The token issuer and audience are fixed constants for Phase 1. The verifier MUST reject missing/invalid `sub`.

## 28.5 `src/routes/me.js` dashboard requirement

In addition to the existing `/me`, `/me/accounts`, `/me/net-worth`, and `/me/roundups` routes, this module MUST expose:

```text
GET /me/dashboard
GET /me/transactions
GET /me/intelligence
GET /me/income
GET /me/cash-flow
GET /me/insights
```

All are read-only. They query persisted authoritative tables. None invokes a calculation engine.

The `/me/dashboard` implementation MUST assemble evidence envelopes and source timestamps from stored records. It MUST NOT call `calculateRoundup()` or recreate a Round-Up amount from a transaction amount.

## 28.6 Webhook worker

```javascript
async function processWebhookEvents(limit = 25) {
  return db.withServiceRole(async (client) => {
    const { rows } = await client.query(`
      SELECT id, item_id
      FROM plaid_webhook_events
      WHERE processing_status IN ('received','failed')
        AND (next_attempt_at IS NULL OR next_attempt_at <= now())
        AND attempt_count < max_attempts
      ORDER BY received_at
      FOR UPDATE SKIP LOCKED
      LIMIT $1
    `, [limit]);

    for (const event of rows) {
      await client.query(`
        UPDATE plaid_webhook_events
        SET processing_status = 'processing',
            attempt_count = attempt_count + 1,
            last_attempt_at = now()
        WHERE id = $1
      `, [event.id]);

      try {
        await runSyncForPlaidItemWithAdvisoryLock(event.item_id);
        await client.query(`
          UPDATE plaid_webhook_events
          SET processing_status = 'processed', processed_at = now()
          WHERE id = $1
        `, [event.id]);
      } catch (err) {
        await client.query(`
          UPDATE plaid_webhook_events
          SET processing_status =
                CASE WHEN attempt_count >= max_attempts
                     THEN 'dead_letter' ELSE 'failed' END,
              processing_error = $2,
              next_attempt_at =
                CASE WHEN attempt_count >= max_attempts
                     THEN NULL
                     ELSE now() + LEAST(interval '1 hour',
                                        (interval '1 minute' * power(2, attempt_count)))
                END
          WHERE id = $1
        `, [event.id, String(err.message || err)]);
      }
    }

    return rows.length;
  });
}
```

The webhook event table therefore requires:

```sql
ALTER TABLE plaid_webhook_events
  ADD COLUMN IF NOT EXISTS attempt_count INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_attempts INTEGER NOT NULL DEFAULT 8,
  ADD COLUMN IF NOT EXISTS next_attempt_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS last_attempt_at TIMESTAMPTZ;

ALTER TABLE plaid_webhook_events
  ADD CONSTRAINT plaid_webhook_processing_status_check
  CHECK (processing_status IN
    ('received','processing','processed','failed','dead_letter'));
```

## 28.7 Per-Item sync serialization

Every Item sync begins with:

```sql
SELECT pg_advisory_xact_lock(hashtextextended($1, 0));
```

where `$1` is the immutable Plaid Item ID.

The lock is acquired before reading the current cursor and released only when the sync transaction commits or rolls back.

This prevents concurrent webhook deliveries from applying the same cursor window simultaneously.

## 28.8 Source observation persistence

Every successful provider call that returns financial data creates a `source_observations` row:

```text
provider = 'plaid'
provider_endpoint = exact endpoint
provider_request_id = provider request_id when supplied
provider_item_id = Plaid Item ID
provider_entity_id = relevant provider entity ID where applicable
payload_hash = SHA-256 of the exact serialized response
raw_payload = complete response JSON
schema_version = iBag provider adapter schema version
environment = sandbox|production
retrieved_at = now()
```

The canonical tables are derived from these observations; raw provider payloads are never reconstructed from canonical data.

## 28.9 Closed-account handling

After each successful `/accounts/get`, the sync worker compares the current account IDs with active local accounts for that Item.

Accounts no longer returned by Plaid are marked:

```text
status = 'closed'
closed_at = now()
```

No transaction or intelligence row is deleted merely because an account closed.

## 28.10 Currency rule

The Phase 1 calculation predicate is:

```sql
iso_currency_code = 'USD'
```

A null ISO code or unofficial currency code is not silently treated as USD.

Transactions and balances outside USD remain stored as real provider observations but are excluded from USD financial calculations and produce an evidence limitation where their omission materially affects an intelligence result.



## 28.11 Pending-to-posted Round-Up event migration

The existing `applyRoundupEvent()` is retained for ordinary new transactions. The sync pipeline MUST call this wrapper for added posted transactions:

```javascript
async function applyRoundupForTransaction(
  client,
  userId,
  accountId,
  transaction,
  evalResult
) {
  if (transaction.pending_transaction_id) {
    const prior = await client.query(
      `SELECT re.id, re.roundup_cents, re.source_amount_cents,
              re.eligibility_status
       FROM transactions pt
       LEFT JOIN roundup_events re
         ON re.transaction_id = pt.id
        AND re.rule_version = $2
       WHERE pt.plaid_transaction_id = $1
       FOR UPDATE OF pt`,
      [transaction.pending_transaction_id, evalResult.rule_version]
    );

    if (prior.rows.length > 0 && prior.rows[0].id) {
      const event = prior.rows[0];

      // Move the one economic Round-Up event from the removed pending
      // transaction to its posted replacement.
      await client.query(
        `UPDATE roundup_events
            SET transaction_id = $1,
                source_amount_cents = $2,
                roundup_cents = $3,
                eligibility_status = $4,
                eligibility_reason = $5
          WHERE id = $6`,
        [
          transaction.id,
          evalResult.source_amount_cents,
          evalResult.roundup_cents,
          evalResult.eligibility_status,
          evalResult.eligibility_reason,
          event.id,
        ]
      );

      const delta = evalResult.roundup_cents - event.roundup_cents;

      if (delta !== 0) {
        await client.query(
          `INSERT INTO roundup_accumulators (user_id, account_id, total_cents)
           VALUES ($1,$2,$3)
           ON CONFLICT (account_id)
           DO UPDATE SET total_cents =
             roundup_accumulators.total_cents + EXCLUDED.total_cents,
             updated_at = now()`,
          [userId, accountId, delta]
        );
      }

      // Pending events are normally zero-contribution because pending
      // transactions are ineligible. If the event was already attached to
      // an open batch, the line item remains historical only after posting;
      // recompute the open snapshot when applicable.
      await client.query(
        `UPDATE roundup_line_items
            SET roundup_cents_snapshot = $1
          WHERE roundup_event_id = $2
            AND batch_id IN (
              SELECT id FROM roundup_batches WHERE status = 'pending'
            )`,
        [evalResult.roundup_cents, event.id]
      );

      return event;
    }
  }

  return applyRoundupEvent(
    client,
    userId,
    accountId,
    transaction.id,
    evalResult
  );
}
```

The wrapper MUST be used before the removed-pending transaction is processed as a standalone removal. A pending transaction removed in the same `/transactions/sync` response is therefore recognized as the predecessor of the posted transaction rather than treated as an independent economic purchase.



## 28.12 `/me/dashboard` implementation

The route below is a read model. It performs no financial calculations that are not already represented by authoritative stored rows.

```javascript
router.get('/me/dashboard', async (req, res, next) => {
  try {
    const result = await db.withUserContext(req.userId, async (client) => {
      const [
        accounts,
        roundup,
        recentRoundups,
        income,
        recurring,
        cashFlow,
        netWorth,
        health,
        capabilities,
        quality
      ] = await Promise.all([
        client.query(`
          SELECT id, name, official_name, mask, type, subtype,
                 current_balance_cents, available_balance_cents,
                 iso_currency_code, balance_as_of, status
          FROM accounts
          WHERE user_id = $1
          ORDER BY created_at
        `, [req.userId]),

        client.query(`
          SELECT
            COUNT(*)::int AS event_count,
            COUNT(*) FILTER (
              WHERE eligibility_status = 'eligible' AND roundup_cents > 0
            )::int AS opportunity_count,
            COALESCE(SUM(roundup_cents) FILTER (
              WHERE eligibility_status = 'eligible'
            ), 0)::bigint AS opportunity_cents
          FROM roundup_events
          WHERE user_id = $1
        `, [req.userId]),

        client.query(`
          SELECT re.id, re.transaction_id, re.source_amount_cents,
                 re.roundup_cents, re.eligibility_status,
                 re.eligibility_reason, t.merchant_name,
                 t.posted_date, t.account_id
          FROM roundup_events re
          JOIN transactions t ON t.id = re.transaction_id
          WHERE re.user_id = $1
          ORDER BY re.created_at DESC
          LIMIT 25
        `, [req.userId]),

        client.query(`
          SELECT * FROM income_signals
          WHERE user_id = $1
          ORDER BY average_amount_cents DESC NULLS LAST
        `, [req.userId]),

        client.query(`
          SELECT * FROM recurring_streams
          WHERE user_id = $1
          ORDER BY next_expected_date NULLS LAST
        `, [req.userId]),

        client.query(`
          SELECT * FROM cash_flow_periods
          WHERE user_id = $1
          ORDER BY period_end DESC
          LIMIT 12
        `, [req.userId]),

        client.query(`
          SELECT * FROM net_worth_snapshots
          WHERE user_id = $1
          ORDER BY as_of_date DESC
          LIMIT 1
        `, [req.userId]),

        client.query(`
          SELECT * FROM financial_health_signals
          WHERE user_id = $1
          ORDER BY signal_type
        `, [req.userId]),

        client.query(`
          SELECT pc.domain, pc.requested, pc.consented,
                 pc.product_enabled, pc.observed,
                 pc.last_successful_sync_at,
                 pc.last_failed_sync_at, pc.last_error
          FROM provider_capabilities pc
          JOIN plaid_items pi ON pi.id = pc.plaid_item_id
          WHERE pi.user_id = $1
          ORDER BY pc.domain
        `, [req.userId]),

        client.query(`
          SELECT issue_type, entity_type, entity_id, details, created_at
          FROM data_quality_events
          WHERE user_id = $1 AND resolved_at IS NULL
          ORDER BY created_at DESC
          LIMIT 50
        `, [req.userId]),
      ]);

      const posted = await client.query(`
        SELECT MIN(COALESCE(posted_date, authorized_date)) AS start_date,
               MAX(COALESCE(posted_date, authorized_date)) AS end_date,
               COUNT(*)::int AS transaction_count
        FROM transactions
        WHERE user_id = $1 AND removed_at IS NULL
      `, [req.userId]);

      return {
        accounts: accounts.rows,
        roundUps: {
          eventCount: Number(roundup.rows[0].event_count),
          opportunityCount: Number(roundup.rows[0].opportunity_count),
          opportunityCents: Number(roundup.rows[0].opportunity_cents),
        },
        recentRoundups: recentRoundups.rows,
        income: income.rows,
        recurring: recurring.rows,
        cashFlow: cashFlow.rows,
        netWorth: netWorth.rows[0] || null,
        financialHealth: health.rows,
        capabilities: capabilities.rows,
        dataQuality: quality.rows,
        observationWindow: posted.rows[0],
      };
    });

    res.json({ status: 'ok', dashboard: result });
  } catch (err) {
    next(err);
  }
});
```

The only arithmetic in this endpoint is response serialization of already persisted values; it does not derive Round-Up amounts from transaction amounts.



## 28.13 `src/routes/auth.js` â€” executable access/refresh lifecycle

```javascript
const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const router = express.Router();
const db = require('../db');

const BCRYPT_COST = 12;
const ACCESS_TTL = '15m';
const REFRESH_TTL_DAYS = 30;
const ISSUER = 'ibag-api';
const AUDIENCE = 'ibag-client';
const DUMMY_HASH = bcrypt.hashSync('ibag-dummy-password', BCRYPT_COST);

function normalizeEmail(value) {
  if (typeof value !== 'string') throw new Error('INVALID_EMAIL');
  const email = value.trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('INVALID_EMAIL');
  return email;
}

function assertPassword(password) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 200) {
    const err = new Error('INVALID_PASSWORD');
    err.code = 'INVALID_PASSWORD';
    throw err;
  }
}

function issueAccessToken(userId) {
  return jwt.sign(
    { sub: userId },
    process.env.JWT_SECRET,
    {
      algorithm: 'HS256',
      expiresIn: ACCESS_TTL,
      issuer: ISSUER,
      audience: AUDIENCE,
    }
  );
}

function hashOpaqueToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function createRefreshToken() {
  return crypto.randomBytes(48).toString('base64url');
}

function refreshExpiry() {
  return new Date(Date.now() + REFRESH_TTL_DAYS * 86400000);
}

async function createRefreshSession(client, userId, familyId = crypto.randomUUID()) {
  const token = createRefreshToken();
  const hash = hashOpaqueToken(token);

  const result = await client.query(
    `INSERT INTO auth_refresh_sessions
       (user_id, family_id, token_hash, expires_at)
     VALUES ($1,$2,$3,$4)
     RETURNING id`,
    [userId, familyId, hash, refreshExpiry()]
  );

  return { token, sessionId: result.rows[0].id, familyId };
}

router.post('/signup', async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    assertPassword(req.body.password);

    const passwordHash = await bcrypt.hash(req.body.password, BCRYPT_COST);

    const result = await db.withServiceRole(async (client) => {
      const inserted = await client.query(
        `INSERT INTO users (email, password_hash)
         VALUES ($1,$2)
         ON CONFLICT (email) DO NOTHING
         RETURNING id, email, created_at`,
        [email, passwordHash]
      );

      if (inserted.rows.length === 0) {
        const err = new Error('EMAIL_ALREADY_REGISTERED');
        err.code = 'EMAIL_ALREADY_REGISTERED';
        throw err;
      }

      const user = inserted.rows[0];
      const refresh = await createRefreshSession(client, user.id);
      return {
        user,
        accessToken: issueAccessToken(user.id),
        refreshToken: refresh.token,
      };
    });

    res.status(201).json({ status: 'ok', ...result });
  } catch (err) {
    next(err);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const password = req.body.password;

    const result = await db.withServiceRole(async (client) => {
      const found = await client.query(
        `SELECT id, email, password_hash, created_at
         FROM users WHERE email = $1`,
        [email]
      );

      const user = found.rows[0];
      const valid = await bcrypt.compare(
        typeof password === 'string' ? password : '',
        user ? user.password_hash : DUMMY_HASH
      );

      if (!user || !valid) {
        const err = new Error('INVALID_CREDENTIALS');
        err.code = 'INVALID_CREDENTIALS';
        throw err;
      }

      const refresh = await createRefreshSession(client, user.id);

      return {
        user: {
          id: user.id,
          email: user.email,
          created_at: user.created_at,
        },
        accessToken: issueAccessToken(user.id),
        refreshToken: refresh.token,
      };
    });

    res.json({ status: 'ok', ...result });
  } catch (err) {
    next(err);
  }
});

router.post('/refresh', async (req, res, next) => {
  try {
    const presented = req.body.refreshToken;
    if (typeof presented !== 'string' || presented.length < 32) {
      return res.status(401).json({ status: 'error', code: 'INVALID_REFRESH_TOKEN' });
    }

    const result = await db.withServiceRole(async (client) => {
      const hash = hashOpaqueToken(presented);
      const found = await client.query(
        `SELECT id, user_id, family_id, expires_at, revoked_at
         FROM auth_refresh_sessions
         WHERE token_hash = $1
         FOR UPDATE`,
        [hash]
      );

      if (found.rows.length === 0) {
        const err = new Error('INVALID_REFRESH_TOKEN');
        err.code = 'INVALID_REFRESH_TOKEN';
        throw err;
      }

      const old = found.rows[0];

      if (old.revoked_at || new Date(old.expires_at) <= new Date()) {
        // Reuse of a rotated/revoked token invalidates the whole family.
        await client.query(
          `UPDATE auth_refresh_sessions
           SET revoked_at = COALESCE(revoked_at, now())
           WHERE family_id = $1 AND revoked_at IS NULL`,
          [old.family_id]
        );
        const err = new Error('REFRESH_TOKEN_REVOKED');
        err.code = 'REFRESH_TOKEN_REVOKED';
        throw err;
      }

      const nextRefresh = await createRefreshSession(client, old.user_id, old.family_id);

      await client.query(
        `UPDATE auth_refresh_sessions
         SET revoked_at = now(), replaced_by = $2
         WHERE id = $1`,
        [old.id, nextRefresh.sessionId]
      );

      return {
        accessToken: issueAccessToken(old.user_id),
        refreshToken: nextRefresh.token,
      };
    });

    res.json({ status: 'ok', ...result });
  } catch (err) {
    next(err);
  }
});

router.post('/logout', async (req, res, next) => {
  try {
    const presented = req.body.refreshToken;
    if (typeof presented === 'string') {
      await db.withServiceRole((client) =>
        client.query(
          `UPDATE auth_refresh_sessions
           SET revoked_at = COALESCE(revoked_at, now())
           WHERE token_hash = $1`,
          [hashOpaqueToken(presented)]
        )
      );
    }
    res.json({ status: 'ok' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
```

The auth route uses the service connection only for authentication bootstrap/session mutation; user financial data still uses the ordinary `ibag_app` connection plus RLS.

## 28.14 Password-reset delivery

Password reset request responses are deliberately identical whether the email exists or not. The worker creates a one-time hashed token only for existing users and sends the unhashed token through the configured SMTP transport. A successful reset:

1. consumes the reset token;
2. changes the bcrypt password;
3. revokes all refresh-token families for the user;
4. requires a fresh login.

No reset token is logged.
`````

---

# 29. FINAL PRE-IMPLEMENTATION SPECIFICATION CLOSURE
## v5.0 — Authoritative Closure Addendum
### This section supersedes every earlier statement in this document where the two conflict.

**Status:** SPECIFICATION-CLOSED / IMPLEMENTATION-NOT-YET-EXECUTED  
**Purpose:** Final pre-implementation closure. No known architectural, data-model, provider-compatibility, security, intelligence, failure, concurrency, or testing-design gap may remain unidentified.

This addendum is deliberately not a claim that the system has been implemented or runtime-validated. Those facts can only be established by executing the implementation and the certification gates.

## 29.1 Final authority rule

The following precedence is absolute:

1. This Section 29 and its subsections.
2. Current executable DDL/code requirements explicitly referenced by Section 29.
3. Earlier numbered specification sections.
4. Historical changelogs and audit notes.

Any earlier text saying that a requirement is "still unresolved", "not implemented", "future", "partially applied", or "not attempted" is historical if Section 29 closes the underlying design decision.

A requirement is considered **specification-closed** when:
- the desired behavior is defined;
- the data required to support it is defined;
- the authoritative source is defined;
- failure/uncertainty behavior is defined;
- security boundary is defined;
- idempotency/concurrency behavior is defined;
- reconciliation invariant is defined;
- implementation location is defined;
- executable test requirement is defined.

It is not considered runtime-validated until the corresponding test is actually executed.

---

# 29.2 Final closure classification

Every remaining item is assigned exactly one status:

### A. IMPLEMENTATION TASK
The design is completely decided; code must be written.

### B. RUNTIME VALIDATION
The design is completely decided, but correctness depends on execution against Sandbox, staging, production-like institutions, concurrency, or external behavior.

### C. EXTERNAL PREREQUISITE
Correctness depends on Plaid enablement, credentials, institution coverage, account availability, consent, billing/product approval, infrastructure, or another external condition.

### D. INTENTIONALLY OUT OF SCOPE
The capability is deliberately not part of Phase 1 and must not be represented as an accidental missing implementation.

**No item may remain as "unknown", "assumed", "probably", "future decision", or "not yet decided".**

---

# 29.3 Plaid compatibility is now a capability matrix, not an "eight products" assumption

iBag's product model is:

> **iBag Phase-1 Intelligence Domains**

Plaid's products/capabilities are provider inputs to those domains.

The specification MUST NOT claim that Plaid universally exposes exactly eight free products.

The current Plaid Link model distinguishes:
- `products`
- `required_if_supported_products`
- `optional_products`
- `additional_consented_products`

and additional consent/product initialization affects whether later endpoints can be called. Product initialization can also affect institution filtering, latency, billing, and consent. Therefore iBag MUST persist the provider capability actually observed for each Item rather than assuming availability from Link configuration.

For each Item and capability, persist:

```text
requested
configured
consented
provider_enabled
compatible
observed
last_observation_id
last_successful_sync_at
last_error
```

A capability is **observed** only after the corresponding provider endpoint returns usable data or an authoritative provider response establishing the capability state.

**Provider source:** Plaid current Link initialization guidance and API reference. The current guidance explicitly distinguishes these initialization modes and describes additional-consent/update-mode behavior. 

---

# 29.4 Complete provider field disposition rule

Every provider field relevant to iBag is assigned exactly one disposition:

```text
CANONICAL
STRUCTURED_PROVIDER_DATA
RAW_ONLY
EXPLICITLY_UNSUPPORTED
NOT_APPLICABLE
```

No field may disappear silently.

## 29.4.1 Transactions

The canonical transaction model MUST preserve, where supplied and relevant:

```text
plaid_transaction_id
account_id
amount
iso_currency_code
unofficial_currency_code
date
authorized_date
datetime
authorized_datetime
merchant_name
merchant_entity_id
original_description
personal_finance_category
personal_finance_category_version
payment_channel
transaction_code
pending
pending_transaction_id
location
payment_meta
counterparties
logo_url
website
check_number
removed_at
provider_observed_at
```

Provider fields that are not promoted to dedicated columns remain available in the immutable raw observation.

The current Plaid Transactions contract includes PFC versioning, counterparties, merchant entity identifiers, original descriptions, and transaction synchronization semantics; the exact provider schema remains authoritative at implementation time.

**Closure decision:** the existing `personal_finance_category JSONB`, `location JSONB`, `payment_meta JSONB`, and `counterparties JSONB` columns are authoritative structured representations; fields required for joins, classification, indexing, reconciliation, or display are promoted to scalar canonical columns.

---

# 29.5 Currency correctness

The following rule is absolute:

```text
NULL currency != USD
unknown currency != USD
unofficial currency != USD
non-USD != USD
```

Only transactions explicitly carrying:

```text
iso_currency_code = 'USD'
```

are eligible for the Phase-1 USD Round-Up calculation.

Non-USD and unknown-currency transactions remain observable data but are excluded from USD Round-Up calculations with an explicit evidence/eligibility reason.

No database default, application default, or inference may manufacture USD.

---

# 29.6 Transaction state machine

The authoritative provider update model is:

```text
ADDED
MODIFIED
REMOVED
```

with cursor pagination:

```text
initial cursor
    ↓
page
    ↓
has_more?
 ├── yes → next_cursor → page
 └── no  → atomically persist complete update set + final cursor
```

If Plaid returns `TRANSACTIONS_SYNC_MUTATION_DURING_PAGINATION`, the complete pagination loop MUST restart from the cursor held before the update began.

The application MUST NOT persist a partial page-set as though it were a complete sync cycle.

**Provider source:** Plaid current Transactions Sync documentation.

---

# 29.7 Pending-to-posted economic identity

A pending transaction and its posted replacement represent one economic event when Plaid supplies the linking relationship or the conservative iBag lineage resolver establishes the relationship.

The authoritative rule is:

```text
one economic purchase
    -> at most one live Round-Up event per rule version
```

A pending event MUST NOT become a second independent posted event.

If lineage cannot be established confidently:

```text
evidence_state = limited
```

and iBag MUST prefer under-counting a Round-Up opportunity to creating a duplicate financial event.

---

# 29.8 Classification closure

The classification hierarchy is permanently versioned.

```text
REFUND
FEE
ATM_WITHDRAWAL
LOAN_PAYMENT
CREDIT_CARD_PAYMENT
INVESTMENT_ACTIVITY
TRANSFER
INCOME / PENDING_INCOME_REVIEW
PURCHASE
UNKNOWN
```

The exact signed-direction labels used by the existing schema remain:

```text
TRANSFER_IN
TRANSFER_OUT
```

The classification engine MUST never infer certainty solely from amount sign.

## 29.8.1 Credit-card payment closure

`CREDIT_CARD_PAYMENT` is no longer an unresolved design item.

A credit-account transaction is classified as `CREDIT_CARD_PAYMENT` only when:

1. account type is `credit`;
2. the credit-side transaction represents money entering/reducing the card balance;
3. a high-confidence transfer relationship exists to a compatible funding account OR the provider explicitly identifies the transaction as a payment;
4. the relationship is not merely a same-account match;
5. no stronger refund/fee/investment classification supersedes it.

The matched funding-side transaction is classified as the corresponding transfer/payment leg, not as economic consumer spending.

If evidence is insufficient:

```text
UNKNOWN
```

not `CREDIT_CARD_PAYMENT`.

This closes the previously dead rule without creating false positives.

---

# 29.9 Transfer detection closure

Transfer detection is now a multi-signal, conservative, versioned detector.

### Strong evidence

```text
provider transfer classification
provider payment/transfer code
explicit paired transaction relationship
same-user compatible account pair
opposite signed amounts
tight temporal proximity
```

### Supporting evidence

```text
same institution / Item
merchant or financial-institution counterparty
payment-channel metadata
PFC transfer category
matching amount
matching dates
pending-to-posted lineage
```

### Required candidate restrictions

```text
different accounts
same user
non-removed transactions
opposite economic directions
compatible account types
reasonable temporal window
```

### One-sided visibility

If only one side of a suspected transfer is observed:

```text
do not manufacture the missing side
do not classify as confirmed transfer solely from amount/date
retain evidence as limited/ambiguous
```

### Ambiguous match

If multiple plausible counterparties exist:

```text
do not choose arbitrarily
store relationship candidates/evidence
classification remains UNKNOWN unless stronger provider evidence exists
```

### Credit-card payments

Use the same relationship layer to identify a depository-to-credit payment, subject to the stricter credit-card-payment predicate in Section 29.8.1.

### Investment funding

A depository transaction paired with an investment-account transaction is a transfer/funding relationship and is excluded from consumer spending and Round-Up eligibility unless an explicit provider/economic classification establishes otherwise.

### Relationship uniqueness

The database remains authoritative for:
- canonical transaction pair ordering;
- same-user enforcement;
- duplicate relationship prevention.

---

# 29.10 Income two-pass closure

Pass 1:

```text
ambiguous negative transaction
        ↓
PENDING_INCOME_REVIEW
```

Pass 2:

```text
recompute income signals
        ↓
strong evidence → INCOME
no sufficient evidence → UNKNOWN
```

No unresolved transaction may become income merely because it is negative.

The scheduled "all pending users" wrapper MUST NOT query user-protected transactions through the plain pool.

Authoritative scheduling method:

```text
service-role enumeration of plaid_items/users
        ↓
per-user service-role job
        ↓
withUserContext for user-owned mutation where appropriate
```

The wrapper itself is therefore closed as a design decision.

---

# 29.11 Financial-health composite closure

iBag Phase 1 will **not** invent a single opaque financial-health score.

Instead, the authoritative intelligence model is a multidimensional evidence-backed health vector:

```text
liquidity_buffer_30d
fees_30d
cash_flow_direction
income_stability
recurring_obligations
net_worth
roundup_behavior
evidence_quality
```

Each dimension has:
- value;
- evidence state;
- observation window;
- calculation version;
- freshness;
- supporting source records.

A single scalar "financial health score" is:

```text
INTENTIONALLY_OUT_OF_SCOPE
```

for Phase 1.

This is a closure, not a missing feature.

The intelligence remains richer because the system does not compress multiple independent financial realities into an unsupported number.

---

# 29.12 Authentication lifecycle closure

Custom JWT remains the declared authentication authority.

The final lifecycle is:

```text
SIGNUP
  ↓
normalized identity + password hash
  ↓
ACCESS TOKEN + REFRESH SESSION

LOGIN
  ↓
password verification
  ↓
new refresh session + access token

REFRESH
  ↓
validate active refresh token
  ↓
rotate token
  ↓
revoke predecessor
  ↓
issue replacement

LOGOUT
  ↓
revoke current refresh session

PASSWORD CHANGE
  ↓
change credential
  ↓
revoke all existing refresh-session families

PASSWORD RESET
  ↓
single-use hashed reset token
  ↓
credential change
  ↓
revoke all sessions

COMPROMISE
  ↓
revoke session family
  ↓
optionally revoke all user sessions
```

Required properties:

```text
short-lived access token
rotating refresh token
hashed refresh token storage
hashed reset token storage
single-use reset token
refresh-token replay detection
session-family revocation
algorithm pinning
issuer pinning
audience pinning
subject validation
credential-change invalidation
rate limiting
generic authentication failure responses
```

Email verification is an explicit product policy:

```text
Phase-1 requirement: OPTIONAL / NOT REQUIRED FOR FINANCIAL DATA OBSERVATION
```

If enabled later, it is additive and must not weaken session security.

Key rotation is supported by configuration/versioning rather than hard-coded forever to one secret.

---

# 29.13 Database security-role closure

The database trust model is:

```text
MIGRATION_OWNER
    owns schema / executes migrations

API_LOGIN
    LOGIN
    inherits ibag_app
    NOBYPASSRLS

WORKER_LOGIN
    LOGIN
    inherits ibag_service
    controlled service privileges

ibag_app
    NOLOGIN
    NOBYPASSRLS

ibag_service
    NOLOGIN
    BYPASSRLS

PUBLIC
    receives only explicitly required EXECUTE/USAGE privileges
```

The application role MUST NOT be able to bypass RLS.

The service role is not exposed to user requests.

`app.is_service_role` is defense-in-depth metadata, not the sole security boundary.

The deployment process MUST create LOGIN roles outside source-controlled migrations and inject credentials through infrastructure secrets.

---

# 29.14 Raw observation closure

Every successful provider data observation stores:

```text
provider
provider_endpoint
provider_request_id
provider_item_id
provider_entity_id
payload_hash
raw_payload
schema_version
environment
retrieved_at
```

Retention:

```text
raw_payload retained according to documented retention policy
raw_payload may be nulled after retention deadline
metadata/hash remains for lineage and audit
```

Canonical data is never reconstructed into a fake provider payload.

---

# 29.15 Account lifecycle closure

After every successful `/accounts/get`:

```text
returned account
    → active/upserted

previously active but no longer returned
    → closed
```

Closing an account:

```text
does not delete transactions
does not delete intelligence
does not delete Round-Up history
does not rewrite historical evidence
```

Balance observations remain timestamped.

A closed account can only return to active if a subsequent authoritative provider response proves that it exists again.

---

# 29.16 Investments closure

Investment valuation must not double-count.

Authoritative Phase-1 rule:

```text
investment asset total
=
authoritative institution valuation path

holdings
=
composition/detail of that valuation
```

If the provider's account-level investment balance is the authoritative total, holdings are not added again.

If the provider's response establishes a different authoritative valuation path for a specific capability, that path must be versioned and documented before use.

Investment holdings preserve, where supplied:

```text
security_id
ticker/name/security identity
quantity
institution_price
institution_price_as_of
institution_price_datetime
institution_value
cost_basis
iso_currency_code
unofficial_currency_code
security_type
security_subtype
is_cash_equivalent
position_type
vested_quantity
vested_value
tax_lots
```

The raw observation remains authoritative for fields not normalized.

---

# 29.17 Liabilities closure

Liabilities are not reduced to one balance.

The canonical model MUST preserve domain-specific fields where supplied, including:

```text
credit
mortgage
student loan
payment
due date
past due
interest
principal
fees
terms
escrow
PMI
prepayment
guarantor
property
repayment
```

Unsupported/missing fields remain NULL and retain raw provider evidence.

Current Plaid Liabilities coverage is limited by account type/subtype and institution availability; an unavailable liability domain is represented as `not_observed`/`unsupported` rather than zero.

---

# 29.18 Identity closure

Identity data is evidence, not an assertion about the iBag user.

Preserve provider-returned owner information including, where supplied:

```text
names
emails
phone_numbers
addresses
owner/account association
```

Multiple-owner information must remain representable.

An empty provider array is different from an unobserved product.

---

# 29.19 Dashboard closure

`GET /me/dashboard` is a read model only.

It MUST:

```text
read authoritative persisted records
read stored Round-Up events
read stored intelligence
read evidence metadata
read observation timestamps
```

It MUST NOT:

```text
calculate Round-Ups
reconstruct Round-Ups from transactions
reclassify transactions
call provider APIs
invent missing data
```

Every numeric dashboard claim must have an authoritative source path.

---

# 29.20 Round-Up closure

The authoritative Round-Up path is:

```text
Plaid observation
    ↓
canonical transaction
    ↓
classification
    ↓
eligibility
    ↓
deterministic calculation
    ↓
roundup_event
    ↓
accumulator
    ↓
open batch snapshot
    ↓
reconciliation
```

Rules:

```text
amount <= 0              → ineligible
pending                  → ineligible
amount >= $800.00        → ineligible
non-USD                  → ineligible
unknown currency         → ineligible
refund                   → ineligible
income                   → ineligible
transfer                 → ineligible
loan payment             → ineligible
credit-card payment      → ineligible
investment activity      → ineligible
fee                      → ineligible
unknown                   → ineligible
```

The calculation remains:

```text
roundup_cents = (100 - amount_cents % 100) % 100
```

A whole-dollar purchase produces zero Round-Up.

---

# 29.21 Batch-history closure

Open batches may be corrected.

Closed batches are immutable.

If a later provider correction affects a closed batch:

```text
do not rewrite settled history
record data-quality event
preserve corrected current truth separately
surface historical/current divergence explicitly
```

This distinction is intentional and required for auditability.

---

# 29.22 Reconciliation closure

The reconciliation engine MUST verify all of the following:

```text
live eligible event sum
=
live accumulator contribution

category sum
=
global event sum

merchant sum
=
global event sum

event count
=
eligible economic transaction count

removed transactions
=
no live economic contribution

closed batch
=
immutable line-item snapshot

open batch
=
current eligible event snapshot

duplicate economic lineage
=
zero

cross-user relationships
=
zero

negative accumulator
=
zero

negative batch
=
zero
```

Any violation creates a durable data-quality record.

No dashboard may silently hide a reconciliation failure.

---

# 29.23 Webhook closure

Webhook lifecycle:

```text
receive
→ verify signature
→ verify body hash
→ validate freshness
→ persist durable event
→ acknowledge HTTP
→ worker claims event
→ per-Item advisory lock
→ sync
→ commit
→ mark processed
```

Failures:

```text
retry with bounded exponential backoff
→ max attempts
→ dead_letter
```

Duplicate delivery:

```text
atomic idempotency constraint
→ acknowledge
→ no duplicate sync dispatch
```

Plaid-specific error codes are handled using provider `error_code`/`error_type`, not HTTP status alone.

---

# 29.24 Sync concurrency closure

Per Item:

```text
one active cursor-mutating sync at a time
```

The advisory lock MUST cover:

```text
read current cursor
provider pagination
database application of complete update set
cursor commit
```

If the transaction rolls back:

```text
cursor does not advance
```

If the process crashes before commit:

```text
same cursor remains authoritative
retry is safe
```

If the process crashes after commit:

```text
new cursor is authoritative
replayed webhook is idempotent
```

---

# 29.25 Link/exchange closure

Link exchange must be idempotent with respect to the application request.

The application must never create duplicate local Item records merely because a request is retried.

Provider Item identity remains:

```text
plaid_item_id
```

and access tokens are encrypted at rest.

Product/capability state is established from provider observation, not from the frontend's assumption about what Link requested.

---

# 29.26 Sandbox closure

Sandbox is test infrastructure only.

Sandbox fixture creation code MUST refuse to run when:

```text
NODE_ENV = production
OR
PLAID_ENV != sandbox
```

The database/environment guard must be a real deployment convention, not merely a string in documentation.

Sandbox tests cover:

```text
initial Link/exchange
Transactions sync
pagination
webhooks
duplicate webhooks
Round-Up boundaries
modified transactions
removed transactions
pending→posted
income review
merchant resolution
transfer detection
credit-card payment
liabilities
investments
identity
RLS
concurrency
reconciliation
dashboard
```

---

# 29.27 Runtime-only ceiling

The following cannot be certified by documentation alone:

```text
actual Plaid institution coverage
actual provider field availability
actual OAuth consent behavior at each institution
actual Sandbox/Production response timing
actual concurrent database behavior
actual network failure behavior
actual deployment configuration
actual secrets management
actual performance
actual production webhook delivery
actual financial-data correctness on real institutions
```

These are **RUNTIME VALIDATION** gates, not specification gaps.

This distinction is permanent.

---

# 29.28 Final test expansion

The original 56 gates remain mandatory.

The final closure adds these mandatory explicit cases:

```text
T57  CC payment matched against depository funding transaction
T58  CC payment with no matching funding transaction
T59  ambiguous transfer with multiple candidates
T60  one-sided transfer visibility
T61  investment funding transfer
T62  pending→posted Round-Up economic identity
T63  sync pagination mutation restart
T64  refresh-token rotation
T65  refresh-token replay
T66  password change invalidates sessions
T67  password reset single use
T68  password reset invalidates sessions
T69  service role cannot be invoked through user endpoint
T70  API role cannot bypass RLS
T71  cross-user composite-FK rejection
T72  null currency never enters USD Round-Up
T73  non-USD currency never enters USD Round-Up
T74  closed-account historical transactions retained
T75  duplicate Link/exchange request
T76  duplicate provider observation
T77  closed-batch correction creates data-quality event
T78  open-batch correction updates snapshot
T79  dashboard never invokes calculation engine
T80  every dashboard number has source lineage
T81  investment valuation is not double counted
T82  identity multi-owner preservation
T83  liability domain-specific field preservation
T84  raw observation retention/expiration
T85  provider error-type/error-code handling
T86  dead-letter webhook recovery
T87  process crash before cursor commit
T88  process crash after cursor commit
T89  concurrent same-Item sync
T90  concurrent duplicate webhook
```

The system is not "fully validated" until these gates have executable tests.

---

# 29.29 Final implementation traceability requirement

Before implementation begins, create a machine-readable traceability artifact with:

```text
requirement_id
domain
spec_section
database_table
database_constraint
runtime_module
function
API_route
provider_endpoint
failure_path
security_boundary
reconciliation_invariant
test_id
status
```

Every requirement must map to at least one test.

Every test must map to at least one requirement.

Any orphan requirement or orphan test is a closure failure.

---

# 29.30 Final status of formerly open v4.3 items

| Former gap | Final status |
|---|---|
| Credit-card payment detection | **SPECIFICATION-CLOSED / IMPLEMENTATION TASK** |
| Income-review user enumeration | **SPECIFICATION-CLOSED / IMPLEMENTATION TASK** |
| Financial-health scalar composite | **INTENTIONALLY OUT OF SCOPE for Phase 1** |
| Plaid canonical-field preservation | **SPECIFICATION-CLOSED / IMPLEMENTATION TASK** |
| Full transfer detection | **SPECIFICATION-CLOSED / IMPLEMENTATION TASK** |
| Authentication lifecycle | **SPECIFICATION-CLOSED / IMPLEMENTATION TASK** |
| Database-role model | **SPECIFICATION-CLOSED / IMPLEMENTATION TASK** |
| Modified Round-Up fixture | **SPECIFICATION-CLOSED / TEST IMPLEMENTATION TASK** |
| Pending→posted fixture | **SPECIFICATION-CLOSED / TEST IMPLEMENTATION TASK** |
| Merchant first/repeat fixture | **SPECIFICATION-CLOSED / TEST IMPLEMENTATION TASK** |
| Sandbox validation | **RUNTIME VALIDATION** |
| Production institution behavior | **RUNTIME VALIDATION / EXTERNAL PREREQUISITE** |

There are **no remaining undecided design questions** in these categories.

---

# 29.31 Final pre-implementation gate

Implementation may begin only when the following checklist is accepted:

```text
[ ] Final specification version committed
[ ] All conflicting historical text marked non-authoritative
[ ] Database DDL copied from authoritative sections
[ ] Provider field ledger committed
[ ] Plaid capability matrix committed
[ ] Authentication contract committed
[ ] Security-role contract committed
[ ] Classification contract committed
[ ] Transfer contract committed
[ ] Round-Up state machine committed
[ ] Intelligence evidence contract committed
[ ] Reconciliation invariants committed
[ ] API contract committed
[ ] Webhook contract committed
[ ] Failure/retry contract committed
[ ] Concurrency/idempotency contract committed
[ ] Test traceability matrix committed
[ ] Sandbox gates committed
[ ] Runtime-only uncertainties explicitly classified
[ ] No unresolved design decisions remain
```

If all boxes are checked:

> **STOP SPECIFICATION DESIGN. BEGIN IMPLEMENTATION.**

---

# 29.32 Final declaration

This specification is now intended to be the **final pre-implementation build contract**.

It does **not** claim:
- that source code has been executed;
- that migrations have succeeded;
- that Plaid Sandbox has validated the system;
- that concurrency tests have passed;
- that production institutions have been validated;
- that the system is production-ready.

It does claim:

- every known architectural decision has an explicit disposition;
- every formerly identified design gap has been closed, implemented as a defined task, moved to runtime validation, assigned an external prerequisite, or intentionally excluded;
- provider capability is distinguished from observed provider data;
- raw provider evidence is distinguished from canonical intelligence;
- uncertainty is preserved rather than fabricated;
- financial calculations are deterministic and versioned;
- Round-Up lineage is economic rather than merely transaction-ID based;
- intelligence remains the product;
- the dashboard is a read model rather than a second calculation engine;
- security, RLS, role separation, concurrency, retry, idempotency, and reconciliation are contractual requirements;
- all implementation requirements are intended to be traceable to executable tests.

## FINAL CERTIFICATION STATE

```text
SPECIFICATION: CLOSED
IMPLEMENTATION: NOT YET EXECUTED
REPO AUDIT: PENDING IMPLEMENTATION
SANDBOX VALIDATION: PENDING IMPLEMENTATION
STAGING VALIDATION: PENDING IMPLEMENTATION
CANARY VALIDATION: PENDING IMPLEMENTATION
PRODUCTION VALIDATION: PENDING IMPLEMENTATION
```

**No percentage is assigned.**

The next legitimate state transition is:

```text
FINAL SPECIFICATION
        ↓
IMPLEMENTATION
```

Not another architectural rewrite.
