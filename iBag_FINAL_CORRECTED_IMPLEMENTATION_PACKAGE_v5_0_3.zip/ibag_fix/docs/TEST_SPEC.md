# 10. TESTING (matrices unchanged in substance, now backed by the code above)

**Webhook:** valid ES256; wrong alg; missing/unknown kid; stale iat (>5min); missing/wrong body hash; duplicate (idempotency_key blocks reprocessing); malformed JWT. Test directly against `verifyPlaidWebhook()` (8.4) with hand-constructed JWTs, not just live Sandbox traffic.

**Round-Up:** `$0.00, $0.01, $0.99, $1.00, $1.01, $1.99, $799.99, $800.00, $800.01`; every `INELIGIBLE_CLASSIFICATIONS` entry; duplicate processing (DB `UNIQUE` catches it via `ON CONFLICT DO NOTHING`, verify accumulator doesn't move); correction from $0.37â†’$0.42 moves accumulator by exactly +$0.05 (test `applyRoundupCorrection` directly).

**RLS:** for every table in Section 5.10, create two users, insert rows for each, and assert user A's `withUserContext` connection cannot see/modify user B's rows â€” including the join-based indirect policies (`roundup_line_items`, `provider_capabilities`, `transaction_classifications`, `transaction_relationships`, `roundup_corrections`), which are exactly where a missed policy is easy to miss in review.

**Classification:** the two-pass income resolution (8.6) specifically â€” construct a fixture with an ambiguous negative-amount transaction, verify it's `UNKNOWN`/pending after pass 1 and correctly resolved after pass 2, not silently misclassified in a single pass.
